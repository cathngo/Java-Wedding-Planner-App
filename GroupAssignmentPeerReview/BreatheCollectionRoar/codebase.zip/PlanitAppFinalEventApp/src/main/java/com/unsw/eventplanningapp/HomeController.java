/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.unsw.eventplanningapp;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.input.MouseEvent;

public class HomeController implements Initializable {

    @FXML
    void switchToEvent(MouseEvent event) throws IOException {
        App.setRoot("Event");
    }

    @FXML
    void switchToGuest(MouseEvent event) throws IOException {
        App.setRoot("Guest");
    }

    @FXML
    void switchToInvitation(MouseEvent event) throws IOException {
        App.setRoot("Invitation");
    }

    @FXML
    void logout(MouseEvent event) throws IOException {
        App.setRoot("Login");
    }

    @FXML
    void switchToAbout(MouseEvent event) throws IOException {
        App.setRoot("About");
    }

    @FXML
    void switchToRunsheet(MouseEvent event) throws IOException {
        App.setRoot("Runsheet");
    }

    @FXML
    void switchToHelp(MouseEvent event) throws IOException {
        App.setRoot("HelpPage");
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }
}

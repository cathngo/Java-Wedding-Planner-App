package com.unsw.eventplanningapp;

import javafx.beans.property.SimpleStringProperty;

/**
 *
 *
 */
public class RunsheetModel {

    private final SimpleStringProperty eventName;
    private final SimpleStringProperty itemTime;
    private final SimpleStringProperty itemDesc;
    private final SimpleStringProperty itemId;

    public RunsheetModel(String Event_Name, String Runsheet_ItemTime, String Runsheet_ItemDesc, String Runsheet_ItemId) {
        this.eventName = new SimpleStringProperty(Event_Name);
        this.itemTime = new SimpleStringProperty(Runsheet_ItemTime);
        this.itemDesc = new SimpleStringProperty(Runsheet_ItemDesc);
        this.itemId = new SimpleStringProperty(Runsheet_ItemId);

    }

    //Getters
    public String getEventName() {
        return eventName.get();
    }

    public String getItemTime() {
        return itemTime.get();
    }

    public String getItemDesc() {
        return itemDesc.get();
    }

    public String getItemId() {
        return itemId.get();
    }

    //Setters
    public void setEventName(String Event_Name) {
        this.eventName.set(Event_Name);
    }

    public void setItemTime(String Runsheet_ItemTime) {
        this.itemTime.set(Runsheet_ItemTime);
    }

    public void setItemDesc(String Runsheet_ItemDesc) {
        this.itemDesc.set(Runsheet_ItemDesc);
    }

    public void setItemId(String Runsheet_ItemId) {
        this.itemId.set(Runsheet_ItemId);
    }

}

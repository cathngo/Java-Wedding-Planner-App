package com.unsw.eventplanningapp;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 *
 */
public class EventController implements Initializable {

    private final ObservableList<EventModel> masterData = FXCollections.observableArrayList(); //ArrayList to store data for table.

    @FXML
    private TableView<EventModel> EventTable; //Table

    // Table Columns
    @FXML
    private TableColumn<EventModel, String> eventID_col;

    @FXML
    private TableColumn<EventModel, String> eventName_col;

    @FXML
    private TableColumn<EventModel, String> eventDate_col;

    @FXML
    private TableColumn<EventModel, String> eventDesc_col;

    @FXML
    private TableColumn<EventModel, String> eventLocation_col;

    @FXML
    private TableColumn<EventModel, String> eventTime_col;

    //TextFields
    @FXML
    private TextField eventId;

    @FXML
    private TextField eventName;

    @FXML
    private TextField eventDesc;

    @FXML
    private DatePicker eventDate;

    @FXML
    private TextField eventLocation;

    @FXML
    private TextField eventTime;

    @FXML
    private PieChart pieChart;

    @FXML
    private Button setData;

    //Method to add a new Event.
    @FXML
    void addEvent(MouseEvent event) {

        Connection conn;
        PreparedStatement stmt;
        LocalDate date = eventDate.getValue(); //converting date to LocalDate
        try {

            conn = DatabaseManager.openConnection(); //creating a database connection.
            String sql = "INSERT INTO EVENT(event_name,event_description,event_date, event_location, event_time) VALUES(?,?,?,?,?);"; //SQL query to Insert data into database
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, eventName.getText());
            stmt.setString(2, eventDesc.getText());
            stmt.setString(3, date.toString());
            stmt.setString(4, eventLocation.getText());
            stmt.setString(5, eventTime.getText());
            stmt.execute();
            EventTable.getItems().clear();
            fetchEvents(); //Refreshing Table
            conn.close();

        } catch (SQLException e) {
            System.out.println(e);
        }

    }

    //This method will get value from selected row of table and set the values in text fields, so user can edit them.
    @FXML
    void setTextFields(MouseEvent event) {
        ObservableList<EventModel> list = EventTable.getSelectionModel().getSelectedItems();
        eventId.setText(list.get(0).getEventId());
        eventName.setText(list.get(0).getEventName());
        eventDate.setValue(LocalDate.parse(list.get(0).getEventDate()));
        eventDesc.setText(list.get(0).getEventDesc());
        eventLocation.setText(list.get(0).getEventLocation());
        eventTime.setText(list.get(0).getEventTime());
    }

    @FXML
    void switchToHome(MouseEvent event) throws IOException {
        App.setRoot("Home");
    }

    @FXML
    void switchToGuest(MouseEvent event) throws IOException {
        App.setRoot("Guest");
    }

    @FXML
    void switchToInvitation(MouseEvent event) throws IOException {
        App.setRoot("Invitation");
    }

    @FXML
    void logout(MouseEvent event) throws IOException {
        App.setRoot("Login");
    }

    @FXML
    void switchToAbout(MouseEvent event) throws IOException {
        App.setRoot("About");
    }

    @FXML
    void switchToRunsheet(MouseEvent event) throws IOException {
        App.setRoot("Runsheet");
    }

    //Method to update event.
    @FXML
    void updateEvent(MouseEvent event) {

        String date = eventDate.getValue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        try {
            Connection conn = DatabaseManager.openConnection();
            Statement stmt;
            stmt = conn.createStatement();
            String query = "UPDATE EVENT SET event_name='" + eventName.getText() + "',event_description='" + eventDesc.getText() + "',"
                    + "event_date='" + date + "', event_location='" + eventLocation.getText() + "', event_time='" + eventTime.getText() + "' WHERE event_id='" + eventId.getText() + "';";
            System.out.println(query);
            stmt.executeUpdate(query);
            EventTable.getItems().clear();
            fetchEvents();
            conn.close();

        } catch (SQLException | UnsupportedOperationException e) {
            System.out.println(e);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initializeColumns();
        fetchEvents();
        eventId.setVisible(false);

    }

    // Method to initialize table columns.
    public void initializeColumns() {
        eventID_col.setCellValueFactory(new PropertyValueFactory<EventModel, String>("eventId"));
        eventName_col.setCellValueFactory(new PropertyValueFactory<EventModel, String>("eventName"));
        eventDate_col.setCellValueFactory(new PropertyValueFactory<EventModel, String>("eventDate"));
        eventDesc_col.setCellValueFactory(new PropertyValueFactory<EventModel, String>("eventDesc"));
        eventLocation_col.setCellValueFactory(new PropertyValueFactory<EventModel, String>("eventLocation"));
        eventTime_col.setCellValueFactory(new PropertyValueFactory<EventModel, String>("eventTime"));

    }

    void fetchEvents() {
        try {
            String eventname, eventdate, eventdesc, eventlocation, eventtime;
            int eventid;
            Connection conn = DatabaseManager.openConnection();
            Statement stmt;
            ResultSet rs;
            stmt = conn.createStatement();
            String query = "SELECT * FROM EVENT";
            stmt.execute(query);
            rs = stmt.getResultSet();
            while (rs.next()) {
                eventid = rs.getInt("event_id");
                eventname = rs.getString("event_name");
                eventdate = rs.getString("event_description");
                eventdesc = rs.getString("event_date");
                eventlocation = rs.getString("event_location");
                eventtime = rs.getString("event_time");

                masterData.add(new EventModel(String.valueOf(eventid), eventname, eventdesc, eventdate, eventlocation, eventtime));
            }
            EventTable.setItems(masterData);
            conn.close();

        } catch (SQLException e) {
            System.out.println(e);
        }

    }

    @FXML
    void setDataIntoPieChart(MouseEvent event) {

        try {
            int yes = 0, no = 0, notConfirmed = 0;
            String rsvp;
            Connection conn = DatabaseManager.openConnection();
            Statement stmt;
            ResultSet rs;
            stmt = conn.createStatement();
            String query = "SELECT RSVP.decision FROM EVENT INNER JOIN INVITATION ON EVENT.event_id = INVITATION.event_id INNER JOIN RSVP ON INVITATION.invitation_id = RSVP.invitation_id WHERE EVENT.event_id = '" + eventId.getText() + "'";

            stmt.execute(query);
            rs = stmt.getResultSet();
            while (rs.next()) {

                rsvp = rs.getString("decision");
                if (rsvp.equalsIgnoreCase("Yes")) {
                    yes += 1;
                } else if (rsvp.equalsIgnoreCase("No")) {
                    no += 1;
                } else if (rsvp.equalsIgnoreCase("Not Confirmed")) {
                    notConfirmed += 1;
                }

            }

            ObservableList<PieChart.Data> pieChartData
                    = FXCollections.observableArrayList(
                            new PieChart.Data("Yes", yes),
                            new PieChart.Data("No", no),
                            new PieChart.Data("Not Confirmed", notConfirmed));
            pieChart.setData(pieChartData);
            pieChart.setTitle("Event RSVP Breakdown");

            pieChart.setLabelsVisible(true);
            pieChartData.forEach(data
                    -> data.nameProperty().bind(
                            Bindings.concat(
                                    data.getName(), " ", (data.pieValueProperty())
                            )
                    )
            );
            conn.close();

        } catch (SQLException e) {
            System.out.println(e);
        }

    }

}

package com.unsw.eventplanningapp;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;

/**
 * FXML Controller class
 *
 * @
 */
public class GuestUploadController implements Initializable {

    @FXML
    private Button addGuest;

    @FXML
    private TextField guestName;

    @FXML
    private TextField guestName1;
    @FXML
    private TextField guestName11;
    @FXML
    private TextField guestName111;
    @FXML
    private TextField guestName1111;
    @FXML
    private TextField guestName11111;
    @FXML
    private TextField guestName111111;
    @FXML
    private TextField guestName1111111;
    @FXML
    private TextField guestName11111111;
    @FXML
    private TextField guestName111111111;

    @FXML
    private TextField username;
    @FXML
    private TextField username1;
    @FXML
    private TextField username11;
    @FXML
    private TextField username111;
    @FXML
    private TextField username1111;
    @FXML
    private TextField username11111;
    @FXML
    private TextField username111111;
    @FXML
    private TextField username1111111;
    @FXML
    private TextField username11111111;
    @FXML
    private TextField username111111111;

    @FXML
    private TextField phoneNumber;
    @FXML
    private TextField phoneNumber1;
    @FXML
    private TextField phoneNumber11;
    @FXML
    private TextField phoneNumber111;
    @FXML
    private TextField phoneNumber1111;
    @FXML
    private TextField phoneNumber11111;
    @FXML
    private TextField phoneNumber111111;
    @FXML
    private TextField phoneNumber1111111;
    @FXML
    private TextField phoneNumber11111111;
    @FXML
    private TextField phoneNumber111111111;

    @FXML
    private TextField emailAddress;
    @FXML
    private TextField emailAddress1;
    @FXML
    private TextField emailAddress11;
    @FXML
    private TextField emailAddress111;
    @FXML
    private TextField emailAddress1111;
    @FXML
    private TextField emailAddress11111;
    @FXML
    private TextField emailAddress111111;
    @FXML
    private TextField emailAddress1111111;
    @FXML
    private TextField emailAddress11111111;
    @FXML
    private TextField emailAddress111111111;

    @FXML
    private Text successfulInvite;

    //This method will be called when admin click on guest's access code.
    @FXML
    void generateAccessCode(MouseEvent event) {

        if (!(guestName.getText().equals(""))) {
            Random rand = new Random();
            // Generates random integers in range 0 to 9999 
            int rand_num = rand.nextInt(10000);
            String name = guestName.getText();
            name = name.replaceAll("[^a-zA-Z]", ""); //Removing white spaces and non alphabets from guest name.
            name = name.concat(String.valueOf(rand_num));
            username.setText(name);
        }

        if (!(guestName1.getText().equals(""))) {
            Random rand = new Random();
            int rand_num1 = rand.nextInt(10000);
            String name1 = guestName1.getText();
            name1 = name1.replaceAll("[^a-zA-Z]", ""); //Removing white spaces and non alphabets from guest name.
            name1 = name1.concat(String.valueOf(rand_num1));
            username1.setText(name1);
        }

        if (!(guestName11.getText().equals(""))) {
            Random rand = new Random();
            int rand_num11 = rand.nextInt(10000);
            String name11 = guestName11.getText();
            name11 = name11.replaceAll("[^a-zA-Z]", ""); //Removing white spaces and non alphabets from guest name.
            name11 = name11.concat(String.valueOf(rand_num11));
            username11.setText(name11);
        }

        if (!(guestName111.getText().equals(""))) {
            Random rand = new Random();
            int rand_num111 = rand.nextInt(10000);
            String name111 = guestName111.getText();
            name111 = name111.replaceAll("[^a-zA-Z]", ""); //Removing white spaces and non alphabets from guest name.
            name111 = name111.concat(String.valueOf(rand_num111));
            username111.setText(name111);
        }

        if (!(guestName1111.getText().equals(""))) {
            Random rand = new Random();
            int rand_num1111 = rand.nextInt(10000);
            String name1111 = guestName1111.getText();
            name1111 = name1111.replaceAll("[^a-zA-Z]", ""); //Removing white spaces and non alphabets from guest name.
            name1111 = name1111.concat(String.valueOf(rand_num1111));
            username1111.setText(name1111);
        }

        if (!(guestName11111.getText().equals(""))) {
            Random rand = new Random();
            int rand_num11111 = rand.nextInt(10000);
            String name11111 = guestName11111.getText();
            name11111 = name11111.replaceAll("[^a-zA-Z]", ""); //Removing white spaces and non alphabets from guest name.
            name11111 = name11111.concat(String.valueOf(rand_num11111));
            username11111.setText(name11111);
        }

        if (!(guestName111111.getText().equals(""))) {
            Random rand = new Random();
            int rand_num111111 = rand.nextInt(10000);
            String name111111 = guestName111111.getText();
            name111111 = name111111.replaceAll("[^a-zA-Z]", ""); //Removing white spaces and non alphabets from guest name.
            name111111 = name111111.concat(String.valueOf(rand_num111111));
            username111111.setText(name111111);
        }

        if (!(guestName1111111.getText().equals(""))) {
            Random rand = new Random();
            int rand_num1111111 = rand.nextInt(10000);
            String name1111111 = guestName1111111.getText();
            name1111111 = name1111111.replaceAll("[^a-zA-Z]", ""); //Removing white spaces and non alphabets from guest name.
            name1111111 = name1111111.concat(String.valueOf(rand_num1111111));
            username1111111.setText(name1111111);
        }

        if (!(guestName11111111.getText().equals(""))) {
            Random rand = new Random();
            int rand_num11111111 = rand.nextInt(10000);
            String name11111111 = guestName11111111.getText();
            name11111111 = name11111111.replaceAll("[^a-zA-Z]", ""); //Removing white spaces and non alphabets from guest name.
            name11111111 = name11111111.concat(String.valueOf(rand_num11111111));
            username11111111.setText(name11111111);
        }

        if (!(guestName111111111.getText().equals(""))) {
            Random rand = new Random();
            int rand_num111111111 = rand.nextInt(10000);
            String name111111111 = guestName111111111.getText();
            name111111111 = name111111111.replaceAll("[^a-zA-Z]", ""); //Removing white spaces and non alphabets from guest name.
            name111111111 = name111111111.concat(String.valueOf(rand_num111111111));
            username111111111.setText(name111111111);
        }
    }

    //Method to add new Guest.
    @FXML
    void addGuest(MouseEvent event) {

        Connection conn;
        PreparedStatement stmt;

        ArrayList<GuestModel> guestList = new ArrayList();

        try {
            conn = DatabaseManager.openConnection();
            if (!(guestName.getText().equals("")) && !(username.getText().equals(""))) {
                String sql = "INSERT INTO GUEST(guest_name,access_code,phone_number,email_address) VALUES(?,?,?,?)";
                stmt = conn.prepareStatement(sql);
                stmt.setString(1, guestName.getText());
                stmt.setString(2, username.getText());
                stmt.setString(3, phoneNumber.getText());
                stmt.setString(4, emailAddress.getText());

                stmt.execute();
            }
            if (!(guestName1.getText().equals("")) && !(username1.getText().equals(""))) {
                String sql = "INSERT INTO GUEST(guest_name,access_code,phone_number,email_address) VALUES(?,?,?,?)";
                stmt = conn.prepareStatement(sql);
                stmt.setString(1, guestName1.getText());
                stmt.setString(2, username1.getText());
                stmt.setString(3, phoneNumber1.getText());
                stmt.setString(4, emailAddress1.getText());

                stmt.execute();
            }
            if (!(guestName11.getText().equals("")) && !(username11.getText().equals(""))) {
                String sql = "INSERT INTO GUEST(guest_name,access_code,phone_number,email_address) VALUES(?,?,?,?)";
                stmt = conn.prepareStatement(sql);
                stmt.setString(1, guestName11.getText());
                stmt.setString(2, username11.getText());
                stmt.setString(3, phoneNumber11.getText());
                stmt.setString(4, emailAddress11.getText());

                stmt.execute();
            }

            if (!(guestName111.getText().equals("")) && !(username111.getText().equals(""))) {
                String sql = "INSERT INTO GUEST(guest_name,access_code,phone_number,email_address) VALUES(?,?,?,?)";
                stmt = conn.prepareStatement(sql);
                stmt.setString(1, guestName111.getText());
                stmt.setString(2, username111.getText());
                stmt.setString(3, phoneNumber111.getText());
                stmt.setString(4, emailAddress111.getText());

                stmt.execute();
            }

            if (!(guestName1111.getText().equals("")) && !(username1111.getText().equals(""))) {
                String sql = "INSERT INTO GUEST(guest_name,access_code,phone_number,email_address) VALUES(?,?,?,?)";
                stmt = conn.prepareStatement(sql);
                stmt.setString(1, guestName1111.getText());
                stmt.setString(2, username1111.getText());
                stmt.setString(3, phoneNumber1111.getText());
                stmt.setString(4, emailAddress1111.getText());

                stmt.execute();
            }

            if (!(guestName11111.getText().equals("")) && !(username11111.getText().equals(""))) {
                String sql = "INSERT INTO GUEST(guest_name,access_code,phone_number,email_address) VALUES(?,?,?,?)";
                stmt = conn.prepareStatement(sql);
                stmt.setString(1, guestName11111.getText());
                stmt.setString(2, username11111.getText());
                stmt.setString(3, phoneNumber11111.getText());
                stmt.setString(4, emailAddress11111.getText());

                stmt.execute();
            }

            if (!(guestName111111.getText().equals("")) && !(username111111.getText().equals(""))) {
                String sql = "INSERT INTO GUEST(guest_name,access_code,phone_number,email_address) VALUES(?,?,?,?)";
                stmt = conn.prepareStatement(sql);
                stmt.setString(1, guestName111111.getText());
                stmt.setString(2, username111111.getText());
                stmt.setString(3, phoneNumber111111.getText());
                stmt.setString(4, emailAddress111111.getText());

                stmt.execute();
            }

            if (!(guestName1111111.getText().equals("")) && !(username1111111.getText().equals(""))) {
                String sql = "INSERT INTO GUEST(guest_name,access_code,phone_number,email_address) VALUES(?,?,?,?)";
                stmt = conn.prepareStatement(sql);
                stmt.setString(1, guestName1111111.getText());
                stmt.setString(2, username1111111.getText());
                stmt.setString(3, phoneNumber1111111.getText());
                stmt.setString(4, emailAddress1111111.getText());

                stmt.execute();
            }

            if (!(guestName11111111.getText().equals("")) && !(username11111111.getText().equals(""))) {
                String sql = "INSERT INTO GUEST(guest_name,access_code,phone_number,email_address) VALUES(?,?,?,?)";
                stmt = conn.prepareStatement(sql);
                stmt.setString(1, guestName11111111.getText());
                stmt.setString(2, username11111111.getText());
                stmt.setString(3, phoneNumber11111111.getText());
                stmt.setString(4, emailAddress11111111.getText());

                stmt.execute();
            }

            if (!(guestName111111111.getText().equals("")) && !(username111111111.getText().equals(""))) {
                String sql = "INSERT INTO GUEST(guest_name,access_code,phone_number,email_address) VALUES(?,?,?,?)";
                stmt = conn.prepareStatement(sql);
                stmt.setString(1, guestName111111111.getText());
                stmt.setString(2, username111111111.getText());
                stmt.setString(3, phoneNumber111111111.getText());
                stmt.setString(4, emailAddress111111111.getText());

                stmt.execute();

            }

            conn.close();
            successfulInvite.setVisible(true);

        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    @FXML
    void switchToGuest(MouseEvent event) throws IOException {
        App.setRoot("Guest");
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        successfulInvite.setVisible(false);

    }

}

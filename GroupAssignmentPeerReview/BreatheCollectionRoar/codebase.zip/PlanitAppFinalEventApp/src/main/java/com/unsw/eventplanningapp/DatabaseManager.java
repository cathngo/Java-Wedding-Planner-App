package com.unsw.eventplanningapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import javafx.scene.input.MouseEvent;

public class DatabaseManager {

//Method to create a database connection.
    public static Connection openConnection() {
        Connection conn;
        try {
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection("jdbc:sqlite:datastore.db");
            return conn;
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e);
        }

        return null;

    }

}

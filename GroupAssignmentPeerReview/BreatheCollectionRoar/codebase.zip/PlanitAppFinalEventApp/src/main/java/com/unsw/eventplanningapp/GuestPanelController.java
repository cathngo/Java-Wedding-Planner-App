package com.unsw.eventplanningapp;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 *
 */
public class GuestPanelController implements Initializable {

    ObservableList<String> list = FXCollections.observableArrayList("Yes", "No", "Not Confirmed"); //RSVP Decision
    private final ObservableList<InvitedGuestModel> masterData = FXCollections.observableArrayList();
    @FXML
    private TableView<InvitedGuestModel> InvitationTable;

    @FXML
    private TableColumn<InvitedGuestModel, String> invitationID_col;

    @FXML
    private TableColumn<InvitedGuestModel, String> eventName_col;

    @FXML
    private TableColumn<InvitedGuestModel, String> eventDesc_col;

    @FXML
    private TableColumn<InvitedGuestModel, String> eventLocation_col;

    @FXML
    private TableColumn<InvitedGuestModel, String> eventTime_col;

    @FXML
    private TableColumn<InvitedGuestModel, String> guestName_col;

    @FXML
    private TableColumn<InvitedGuestModel, String> RSVPID_col;

    @FXML
    private TableColumn<InvitedGuestModel, String> RSVPDecision_col;

    @FXML
    private TableColumn<InvitedGuestModel, String> dietaryReq_col;

    @FXML
    private ComboBox<String> comboBox;

    @FXML
    private TextField dietReq;

    @FXML
    private Label user;

    //Method to respond an event with either yes or no.
    @FXML
    void sendResponse(MouseEvent event) {
        ObservableList<InvitedGuestModel> selectedItems = InvitationTable.getSelectionModel().getSelectedItems();

        try {
            Connection conn = DatabaseManager.openConnection();
            Statement stmt;
            stmt = conn.createStatement();
            String query = "UPDATE RSVP SET decision='" + comboBox.getValue() + "',dietary_requirements='" + dietReq.getText() + "'"
                    + " WHERE rsvp_id=" + selectedItems.get(0).getRSVPId()+"";
            System.out.println(query);
            stmt.executeUpdate(query);
            InvitationTable.getItems().clear();
            fetchInvitation();
            conn.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
    
    @FXML
    void switchToGuestHelp(MouseEvent event) throws IOException {
        App.setRoot("GuestHelpPage");
    }


    //Guest Logout.
    @FXML
    void logout(MouseEvent event) throws IOException {

        try {

            Connection conn = DatabaseManager.openConnection();
            Statement stmt;
            stmt = conn.createStatement();
            String updateStatus = "UPDATE GUEST SET status=0 WHERE access_code='" + user.getText() + "'";
            stmt.executeUpdate(updateStatus);
            conn.close();
            App.setRoot("Login");
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        getLoggedUser();
        initializeColumns();
        fetchInvitation();
        comboBox.setItems(list);
    }

    public void initializeColumns() {
        invitationID_col.setCellValueFactory(new PropertyValueFactory<InvitedGuestModel, String>("invitationId"));
        eventName_col.setCellValueFactory(new PropertyValueFactory<InvitedGuestModel, String>("eventName"));
        eventDesc_col.setCellValueFactory(new PropertyValueFactory<InvitedGuestModel, String>("eventDesc"));
        eventLocation_col.setCellValueFactory(new PropertyValueFactory<InvitedGuestModel, String>("eventLocation"));
        eventTime_col.setCellValueFactory(new PropertyValueFactory<InvitedGuestModel, String>("eventTime"));
        guestName_col.setCellValueFactory(new PropertyValueFactory<InvitedGuestModel, String>("guestName"));
        RSVPID_col.setCellValueFactory(new PropertyValueFactory<InvitedGuestModel, String>("RSVPId"));
        RSVPDecision_col.setCellValueFactory(new PropertyValueFactory<InvitedGuestModel, String>("RSVP"));
        dietaryReq_col.setCellValueFactory(new PropertyValueFactory<InvitedGuestModel, String>("diet"));
    }

    //Method to fetch invitations for a particular guest.
    void fetchInvitation() {
        try {
            String eventname, eventdesc, eventlocation, eventtime, guestname, rsvpid, rsvp, diet;
            int invtationid;
            Connection conn = DatabaseManager.openConnection();
            Statement stmt;
            ResultSet rs;
            stmt = conn.createStatement();
            String query = "SELECT INVITATION.invitation_id ,EVENT.event_name,EVENT.event_description,EVENT.event_location,EVENT.event_time,GUEST.access_code,RSVP.rsvp_id,RSVP.decision, RSVP.dietary_requirements\n"
                    + "FROM INVITATION\n"
                    + "join EVENT on INVITATION.event_id=EVENT.event_id\n"
                    + "join GUEST on INVITATION.guest_id=GUEST.guest_id\n"
                    + "join RSVP on INVITATION.invitation_id=RSVP.invitation_id\n"
                    + "WHERE GUEST.access_code='" + user.getText() + "'";

            stmt.execute(query);
            rs = stmt.getResultSet();
            while (rs.next()) {
                invtationid = rs.getInt("invitation_id");
                eventname = rs.getString("event_name");
                eventdesc = rs.getString("event_description");
                eventlocation = rs.getString("event_location");
                eventtime = rs.getString("event_time");
                guestname = rs.getString("access_code");
                rsvp = rs.getString("decision");
                rsvpid = rs.getString("rsvp_id");
                diet = rs.getString("dietary_requirements");

                masterData.add(new InvitedGuestModel(String.valueOf(invtationid), eventname, eventdesc, eventlocation, eventtime, guestname, rsvpid, rsvp, diet));

            }
            InvitationTable.setItems(masterData);
            conn.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    //Method to check which user is logged In so system can fetch his invitations.
    void getLoggedUser() {

        try {

            Connection conn = DatabaseManager.openConnection();
            Statement stmt;
            ResultSet rs;
            stmt = conn.createStatement();
            String query = "SELECT access_code FROM GUEST WHERE status=1";
            stmt.execute(query);
            rs = stmt.getResultSet();
            if (rs.next()) {
                user.setText(rs.getString("access_code"));

            }

            conn.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
        
        
    }
}

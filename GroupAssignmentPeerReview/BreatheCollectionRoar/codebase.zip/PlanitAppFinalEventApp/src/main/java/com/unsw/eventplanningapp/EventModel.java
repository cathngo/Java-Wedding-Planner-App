package com.unsw.eventplanningapp;

import javafx.beans.property.SimpleStringProperty;

/**
 *
 *
 */
public class EventModel {

    private final SimpleStringProperty eventId;
    private final SimpleStringProperty eventName;
    private final SimpleStringProperty eventDate;
    private final SimpleStringProperty eventDesc;
    private final SimpleStringProperty eventLocation;
    private final SimpleStringProperty eventTime;

    public EventModel(String Event_ID, String Event_Name, String Event_Date, String Event_Desc, String Event_Location, String Event_Time) {
        this.eventId = new SimpleStringProperty(Event_ID);
        this.eventName = new SimpleStringProperty(Event_Name);
        this.eventDate = new SimpleStringProperty(Event_Date);
        this.eventDesc = new SimpleStringProperty(Event_Desc);
        this.eventLocation = new SimpleStringProperty(Event_Location);
        this.eventTime = new SimpleStringProperty(Event_Time);
    }

    //Getters
    public String getEventId() {
        return eventId.get();
    }

    public String getEventName() {
        return eventName.get();
    }

    public String getEventDate() {
        return eventDate.get();
    }

    public String getEventDesc() {
        return eventDesc.get();
    }

    public String getEventLocation() {
        return eventLocation.get();
    }

    public String getEventTime() {
        return eventTime.get();
    }

    //Setters
    public void setEventID(String Event_ID) {
        this.eventId.set(Event_ID);
    }

    public void setEventName(String Event_Name) {
        this.eventName.set(Event_Name);
    }

    public void setEventDate(String Event_Date) {
        this.eventDate.set(Event_Date);
    }

    public void setEventDesc(String Event_Desc) {
        this.eventDesc.set(Event_Desc);
    }

    public void setEventLocation(String Event_Location) {
        this.eventLocation.set(Event_Location);
    }

    public void setEventTime(String Event_Time) {
        this.eventDesc.set(Event_Time);
    }
}

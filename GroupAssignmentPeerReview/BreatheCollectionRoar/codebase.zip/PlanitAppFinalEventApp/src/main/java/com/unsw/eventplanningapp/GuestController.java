package com.unsw.eventplanningapp;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;

/**
 * FXML Controller class
 *
 * @
 */
public class GuestController implements Initializable {

    @FXML
    private final ObservableList<GuestModel> masterData = FXCollections.observableArrayList();
    @FXML
    private TableView<GuestModel> GuestTable;

    @FXML
    private TableColumn<GuestModel, String> guestID_col;

    @FXML
    private TableColumn<GuestModel, String> guestName_col;

    @FXML
    private TableColumn<GuestModel, String> username_col;

    @FXML
    private TableColumn<GuestModel, String> phoneNumber_col;

    @FXML
    private TableColumn<GuestModel, String> emailAddress_col;

    @FXML
    private TextField guestId;

    @FXML
    private TextField guestName;

    @FXML
    private TextField username;

    @FXML
    private TextField phoneNumber;

    @FXML
    private TextField emailAddress;

    @FXML
    private ComboBox<String> comboBox;

    @FXML
    private Text successfulInvite;

    @FXML
    void switchToHelp(MouseEvent event) throws IOException {
        App.setRoot("HelpPage");
    }

    //This method will be called when admin click on guest's access code.
    @FXML
    void generateAccessCode(MouseEvent event) {

        if (!(guestName.getText().equals(""))) {
            Random rand = new Random();
            // Generates random integers in range 0 to 9999 
            int rand_num = rand.nextInt(10000);
            String name = guestName.getText();
            name = name.replaceAll("[^a-zA-Z]", ""); //Removing white spaces and non alphabets from guest name.
            name = name.concat(String.valueOf(rand_num));
            username.setText(name);
        } else {
            Alert alert = new Alert(AlertType.ERROR, "Enter Guest Name First");
            alert.show();
        }

    }

    @FXML
    void switchToEvent(MouseEvent event) throws IOException {
        App.setRoot("Event");
    }

    @FXML
    void switchToHome(MouseEvent event) throws IOException {
        App.setRoot("Home");
    }

    @FXML
    void switchToInvitation(MouseEvent event) throws IOException {
        App.setRoot("Invitation");
    }

    @FXML
    void logout(MouseEvent event) throws IOException {
        App.setRoot("Login");
    }

    @FXML
    void switchToAbout(MouseEvent event) throws IOException {
        App.setRoot("About");
    }

    @FXML
    void switchToRunsheet(MouseEvent event) throws IOException {
        App.setRoot("Runsheet");
    }

    @FXML
    void switchToGuestUpload(MouseEvent event) throws IOException {
        App.setRoot("GuestUpload");
    }

    //Method to add new Guest.
    @FXML
    void addGuest(MouseEvent event) {

        Connection conn;
        PreparedStatement stmt;

        try {
            conn = DatabaseManager.openConnection();
            String sql = "INSERT INTO GUEST(guest_name,access_code,phone_number,email_address) VALUES(?,?,?,?)";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, guestName.getText());
            stmt.setString(2, username.getText());
            stmt.setString(3, phoneNumber.getText());
            stmt.setString(4, emailAddress.getText());
            stmt.execute();
            GuestTable.getItems().clear();
            fetchGuest();// Refreshing Table to get latest records.
            conn.close();

        } catch (SQLException e) {
            System.out.println(e);
        }

    }

    //This method will get values from selected row of table and set to text fields.
    @FXML
    void setTextFields(MouseEvent event) {

        ObservableList<GuestModel> list = GuestTable.getSelectionModel().getSelectedItems();
        guestId.setText(list.get(0).getGuestId());
        guestName.setText(list.get(0).getGuestName());
        username.setText(list.get(0).getUsername());
        phoneNumber.setText(list.get(0).getPhoneNumber());
        emailAddress.setText(list.get(0).getEmailAddress());

    }

    //Method to update guest.
    @FXML
    void updateGuest(MouseEvent event) {

        try {
            Connection conn = DatabaseManager.openConnection();
            Statement stmt;
            stmt = conn.createStatement();
            String query = "UPDATE GUEST SET guest_name='" + guestName.getText() + "',phone_number='" + phoneNumber.getText() + "',"
                    + "email_address='" + emailAddress.getText() + "' WHERE guest_id=" + guestId.getText() + "";
            stmt.executeUpdate(query);
            GuestTable.getItems().clear();
            fetchGuest();
            conn.close();

        } catch (SQLException | UnsupportedOperationException e) {
            System.out.println(e);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initializeColumns();
        fetchGuest();//getting guest on window load.
        guestId.setVisible(false);
        GuestTable.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        fetchEvents();
        successfulInvite.setVisible(false);

    }

    //Initializing columns
    public void initializeColumns() {
        guestID_col.setCellValueFactory(new PropertyValueFactory<GuestModel, String>("guestId"));
        guestName_col.setCellValueFactory(new PropertyValueFactory<GuestModel, String>("guestName"));
        username_col.setCellValueFactory(new PropertyValueFactory<GuestModel, String>("username"));
        phoneNumber_col.setCellValueFactory(new PropertyValueFactory<GuestModel, String>("phoneNumber"));
        emailAddress_col.setCellValueFactory(new PropertyValueFactory<GuestModel, String>("emailAddress"));
    }

    @FXML
    //Fetching guests.
    void fetchGuest() {
        try {
            String guestname, user_name, email, phone;
            int guestid;
            Connection conn = DatabaseManager.openConnection();
            Statement stmt;
            ResultSet rs;
            stmt = conn.createStatement();
            String query = "SELECT * FROM GUEST";
            stmt.execute(query);
            rs = stmt.getResultSet();
            while (rs.next()) {
                guestid = rs.getInt("guest_id");
                guestname = rs.getString("guest_name");
                user_name = rs.getString("access_code");
                phone = rs.getString("phone_number");
                email = rs.getString("email_address");

                masterData.add(new GuestModel(String.valueOf(guestid), guestname, user_name, phone, email));
            }
            GuestTable.setItems(masterData);
            conn.close();

        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    @FXML
    void inviteGuests(MouseEvent event) throws SQLException {

        ObservableList<GuestModel> selectedItems = GuestTable.getSelectionModel().getSelectedItems();

        String eventname = (comboBox.getValue());
        Connection conn1;
        PreparedStatement stmt3;
        ResultSet rs1;
        conn1 = DatabaseManager.openConnection();
        String sql = "SELECT event_id FROM EVENT WHERE event_name = '" + (comboBox.getValue()) + "';";
        stmt3 = conn1.prepareStatement(sql);
        stmt3.execute();
        rs1 = stmt3.getResultSet();
        int eventid = rs1.getInt("event_id");
        conn1.close();

        for (int i = 0; i <= selectedItems.size(); i++) {

            Connection conn;
            PreparedStatement stmt;
            PreparedStatement stmt2;

            try {
                conn = DatabaseManager.openConnection();
                String sql1 = "INSERT INTO INVITATION(event_id,guest_id,admin_id) VALUES(?,?,?)";
                String sql2 = "INSERT INTO RSVP(invitation_id,decision) VALUES(?,?)";
                stmt = conn.prepareStatement(sql1);
                stmt.setInt(1, eventid);
                stmt.setInt(2, Integer.parseInt(selectedItems.get(i).getGuestId()));
                stmt.setInt(3, 1);
                stmt.execute();

                stmt2 = conn.prepareStatement(sql2);
                stmt2.setInt(1, fetchInvitationId());
                stmt2.setString(2, "Not Confirmed");
                stmt2.execute();
                successfulInvite.setVisible(true);
                conn.close();

            } catch (SQLException e) {
                System.out.println(e);
            }

        }

    }

    void fetchEvents() {
        ObservableList<String> list = FXCollections.observableArrayList();
        try {
            Connection conn = DatabaseManager.openConnection();
            Statement stmt;
            ResultSet rs;
            stmt = conn.createStatement();
            String query = "SELECT event_name FROM EVENT";
            stmt.execute(query);
            rs = stmt.getResultSet();
            while (rs.next()) {
                list.addAll(rs.getString("event_name"));

            }
            comboBox.setItems(list);
            conn.close();

        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    public int fetchInvitationId() {
        int invitation_id = 0;
        try {
            Connection conn = DatabaseManager.openConnection();
            Statement stmt;
            ResultSet rs;
            stmt = conn.createStatement();
            String query = "SELECT invitation_id FROM INVITATION";
            stmt.execute(query);
            rs = stmt.getResultSet();
            while (rs.next()) {

                invitation_id = rs.getInt("invitation_id");

            }
            conn.close();

        } catch (SQLException e) {
            System.out.println(e);
        }
        System.out.println(invitation_id);
        return invitation_id;
    }

}

package com.unsw.eventplanningapp;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;

/**
 * FXML Controller class
 *
 *
 */
public class RunsheetController implements Initializable {

    private final ObservableList<RunsheetModel> masterData = FXCollections.observableArrayList(); //ArrayList to store data for table.

    @FXML
    private TableView<RunsheetModel> RunsheetTable; //Table

    // Table Columns
    @FXML
    private TableColumn<RunsheetModel, String> eventName_col;

    @FXML
    private TableColumn<RunsheetModel, String> itemTime_col;

    @FXML
    private TableColumn<RunsheetModel, String> itemDesc_col;

    @FXML
    private TableColumn<RunsheetModel, String> itemId_col;

    //TextFields
    @FXML
    private ComboBox<String> comboBox2;

    @FXML
    private TextField itemTime;

    @FXML
    private TextField itemDesc;

    @FXML
    private TextField itemId;

    @FXML
    private ComboBox<String> comboBox;

    @FXML
    private TextField searchEvent;

    @FXML
    private Text successfulRunsheet;

    //Method to add a new Event.
    @FXML
    void addItem(MouseEvent event) {

        Connection conn;
        PreparedStatement stmt;
        String eventName = (comboBox2.getValue());
        try {
            conn = DatabaseManager.openConnection(); //creating a database connection.
            String sql = "INSERT INTO RUNSHEET(event_name,item_time,item_desc) VALUES(?,?,?)"; //SQL query to Insert data into database
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, eventName);
            stmt.setString(2, itemTime.getText());
            stmt.setString(3, itemDesc.getText());
            stmt.execute();
            RunsheetTable.getItems().clear();
            fetchItems(); //Refreshing Table

            conn.close();

        } catch (SQLException e) {
            System.out.println(e);
        }

    }

    @FXML
    void printRunsheet(MouseEvent event) throws SQLException, FileNotFoundException, DocumentException {

        ArrayList<String> timesList = new ArrayList<String>();

        String chosenEventName = (comboBox.getValue());
        Connection conn = DatabaseManager.openConnection();
        Statement stmt;
        ResultSet rs;
        stmt = conn.createStatement();
        String query = "SELECT item_time, item_desc FROM RUNSHEET WHERE event_name='" + chosenEventName + "' ORDER BY item_time ASC;";
        stmt.execute(query);
        rs = stmt.getResultSet();
        while (rs.next()) {
            timesList.add(rs.getString("item_time"));
            timesList.add(rs.getString("item_desc"));

        }

        conn.close();

        Document document = new Document();
        String fileName = String.format("%s%s", "Runsheet ", (comboBox.getValue()));
        @SuppressWarnings("unused")
        PdfWriter pdfWriter = PdfWriter.getInstance(document, new FileOutputStream(fileName + ".pdf"));
        document.open();
        Paragraph paragraph = new Paragraph();
        Paragraph paragraph1 = new Paragraph();

        paragraph.add("Runsheet for " + (comboBox.getValue()));
        paragraph.setSpacingBefore(40);
        paragraph.setSpacingAfter(30);
        document.add(paragraph);

        for (int i = 0; i < timesList.size(); i = i + 2) {

            paragraph1.add(
                    timesList.get(i));

            paragraph1.add(
                    "            " + timesList.get(i + 1) + "\n");

        }
        paragraph1.setSpacingAfter(100);

        document.add(paragraph1);

        document.close();
        successfulRunsheet.setVisible(true);

    }

    //This method will get value from selected row of table and set the values in text fields, so user can edit them.
    @FXML
    void setTextFields(MouseEvent event) {
        ObservableList<RunsheetModel> list = RunsheetTable.getSelectionModel().getSelectedItems();
        itemTime.setText(list.get(0).getItemTime());
        itemDesc.setText(list.get(0).getItemDesc());
        itemId.setText(list.get(0).getItemId());

    }

    @FXML
    void switchToEvent(MouseEvent event) throws IOException {
        App.setRoot("Event");
    }

    @FXML
    void switchToGuest(MouseEvent event) throws IOException {
        App.setRoot("Guest");
    }

    @FXML
    void switchToInvitation(MouseEvent event) throws IOException {
        App.setRoot("Invitation");
    }

    @FXML
    void logout(MouseEvent event) throws IOException {
        App.setRoot("Login");
    }

    @FXML
    void switchToAbout(MouseEvent event) throws IOException {
        App.setRoot("About");
    }

    @FXML
    void switchToHome(MouseEvent event) throws IOException {
        App.setRoot("Home");
    }

    //Method to update event.
    @FXML
    void updateItem(MouseEvent event) {

        try {
            Connection conn = DatabaseManager.openConnection();
            Statement stmt;
            stmt = conn.createStatement();
            String query = "UPDATE RUNSHEET SET item_time='" + itemTime.getText() + "',item_desc='" + itemDesc.getText() + "' WHERE item_id = '" + itemId.getText() + "';";
            System.out.println(query);
            stmt.executeUpdate(query);
            RunsheetTable.getItems().clear();
            fetchItems();
            conn.close();

        } catch (SQLException | UnsupportedOperationException e) {
            System.out.println(e);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initializeColumns();
        fetchItems();
        fetchEventIds();
        fetchEventIds2();
        itemId.setVisible(false);
        itemId_col.setVisible(false);
        successfulRunsheet.setVisible(false);
    }

    // Method to initialize table columns.
    public void initializeColumns() {
        eventName_col.setCellValueFactory(new PropertyValueFactory<RunsheetModel, String>("eventName"));
        itemTime_col.setCellValueFactory(new PropertyValueFactory<RunsheetModel, String>("itemTime"));
        itemDesc_col.setCellValueFactory(new PropertyValueFactory<RunsheetModel, String>("itemDesc"));
        itemId_col.setCellValueFactory(new PropertyValueFactory<RunsheetModel, String>("itemId"));
    }

    void fetchItems() {
        try {
            String eventName, itemTime, itemDesc, itemId;
            Connection conn = DatabaseManager.openConnection();
            Statement stmt;
            ResultSet rs;
            stmt = conn.createStatement();
            String query = "SELECT RUNSHEET.event_name, RUNSHEET.item_time, RUNSHEET.item_desc, RUNSHEET.item_id FROM RUNSHEET, EVENT WHERE RUNSHEET.event_name = EVENT.event_name;";
            stmt.execute(query);
            rs = stmt.getResultSet();
            while (rs.next()) {
                eventName = rs.getString("event_name");
                itemTime = rs.getString("item_time");
                itemDesc = rs.getString("item_desc");
                itemId = rs.getString("item_id");

                masterData.add(new RunsheetModel(eventName, itemTime, itemDesc, itemId));
            }
            RunsheetTable.setItems(masterData);
            conn.close();

        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    void fetchEventIds() {
        ObservableList<String> list = FXCollections.observableArrayList();
        try {
            Connection conn = DatabaseManager.openConnection();
            Statement stmt;
            ResultSet rs;
            stmt = conn.createStatement();
            String query = "SELECT DISTINCT event_name FROM RUNSHEET";
            stmt.execute(query);
            rs = stmt.getResultSet();
            while (rs.next()) {
                list.addAll(rs.getString("event_name"));

            }
            comboBox.setItems(list);

            conn.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    void fetchEventIds2() {
        ObservableList<String> list = FXCollections.observableArrayList();
        try {
            Connection conn = DatabaseManager.openConnection();
            Statement stmt;
            ResultSet rs;
            stmt = conn.createStatement();
            String query = "SELECT event_name FROM EVENT";
            stmt.execute(query);
            rs = stmt.getResultSet();
            while (rs.next()) {
                list.addAll(rs.getString("event_name"));

            }
            comboBox2.setItems(list);

            conn.close();

        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    @FXML
    void searchEventDetails(KeyEvent event) {

        FilteredList<RunsheetModel> filteredData = new FilteredList<>(masterData, p -> true);

        searchEvent.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(data -> {

                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }

                String lowerCaseFilter = newValue.toLowerCase();

                if (data.getEventName().contains(lowerCaseFilter)) {
                    return true;
                }

                return false;
            });
        });

        SortedList<RunsheetModel> sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(RunsheetTable.comparatorProperty());
        RunsheetTable.setItems(sortedData);
    }

}

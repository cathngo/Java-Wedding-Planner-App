package com.unsw.eventplanningapp;

import javafx.beans.property.SimpleStringProperty;

/**
 *
 *
 */
public class InvitedGuestModel {

    private final SimpleStringProperty invitationId;
    private SimpleStringProperty guestName = null;
    private final SimpleStringProperty eventName;
    private final SimpleStringProperty eventDesc;
    private final SimpleStringProperty eventLocation;
    private final SimpleStringProperty eventTime;
    private SimpleStringProperty eventId = null;
    private final SimpleStringProperty RSVP;
    private SimpleStringProperty RSVPId = null;
    private SimpleStringProperty diet = null;
    private SimpleStringProperty createdBy = null;

  /*  public InvitedGuestModel(String invitationId, String guestName, String eventName, String eventDesc, String eventLocation, String eventTime, String RSVP, String diet, String createdBy) {
        this.invitationId = new SimpleStringProperty(invitationId);
        this.guestName = new SimpleStringProperty(guestName);
        this.eventName = new SimpleStringProperty(eventName);
        this.eventDesc = new SimpleStringProperty(eventDesc);
        this.eventLocation = new SimpleStringProperty(eventLocation);
        this.eventTime = new SimpleStringProperty(eventTime);
        this.RSVP = new SimpleStringProperty(RSVP);
        this.diet = new SimpleStringProperty(diet);
        this.createdBy = new SimpleStringProperty(createdBy);

    }
    */
    
    public InvitedGuestModel(String invitationId,String eventName,String eventDesc, String eventLocation, String eventTime,String guestName, String RSVPId, String RSVP, String diet){
         this.invitationId =new SimpleStringProperty (invitationId);
         this.guestName =new SimpleStringProperty (guestName);
         this.eventName =new SimpleStringProperty (eventName);
         this.eventDesc =new SimpleStringProperty (eventDesc);
         this.eventLocation =new SimpleStringProperty (eventLocation);
         this.eventTime =new SimpleStringProperty (eventTime);
         this.RSVP =new SimpleStringProperty (RSVP);
         this.RSVPId =new SimpleStringProperty (RSVPId);
         this.diet =new SimpleStringProperty (diet);
    }



    public String getEventId() {
        return eventId.get();
    }

    public String getRSVPId() {
        return RSVPId.get();
    }

    public String getDiet() {
        return diet.get();
    }

    public String getInvitationId() {
        return invitationId.get();
    }

    public String getGuestName() {
        return guestName.get();
    }

    public String getEventName() {
        return eventName.get();
    }

    public String getEventDesc() {
        return eventDesc.get();
    }

    public String getEventLocation() {
        return eventLocation.get();
    }

    public String getEventTime() {
        return eventTime.get();
    }

    public String getRSVP() {
        return RSVP.get();
    }

    public String getCreatedBy() {
        return createdBy.get();
    }

    public void setInvitationId(String invitationId) {
        this.invitationId.set(invitationId);
    }

    public void setGuestName(String guestName) {
        this.guestName.set(guestName);
    }

    public void setEventName(String eventName) {
        this.eventName.set(eventName);
    }

    public void setEventDesc(String eventDesc) {
        this.eventDesc.set(eventDesc);
    }

    public void setEventLocation(String eventLocation) {
        this.eventLocation.set(eventLocation);
    }

    public void setEventTime(String eventTime) {
        this.eventTime.set(eventTime);
    }

    public void setRSVP(String RSVP) {
        this.RSVP.set(RSVP);
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy.set(createdBy);
    }

    public void setEventId(String eventId) {
        this.eventId.set(eventId);
    }

    public void setRSVPId(String RSVPId) {
        this.RSVPId.set(RSVPId);
    }

    public void setDiet(String diet) {
        this.diet.set(diet);
    }
}

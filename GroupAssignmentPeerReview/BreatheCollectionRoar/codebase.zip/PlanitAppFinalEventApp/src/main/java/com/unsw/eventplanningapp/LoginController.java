package com.unsw.eventplanningapp;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 *
 */
public class LoginController implements Initializable {

    @FXML
    private TextField username;

    @FXML
    private PasswordField password;

    @FXML
    void adminLogin(MouseEvent event) throws IOException {

        try {

            Connection conn = DatabaseManager.openConnection();
            Statement stmt;
            ResultSet rs;
            stmt = conn.createStatement();
            String query = "SELECT admin_id FROM ADMIN WHERE username='" + username.getText() + "' AND password='" + password.getText() + "'";
            stmt.execute(query);
            rs = stmt.getResultSet();
            if (rs.next()) {
                App.setRoot("Home");

            } else {
                Alert alert = new Alert(AlertType.ERROR, "Invalid username/password");
                alert.show();
                 
            }
            conn.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
       
    }

    @FXML
    void guestLogin(MouseEvent event) throws IOException {
        try {

            Connection conn = DatabaseManager.openConnection();
            Statement stmt;
            ResultSet rs;
            stmt = conn.createStatement();
            String query = "SELECT guest_id FROM GUEST WHERE access_code='" + username.getText() + "'";
            String updateStatus = "UPDATE GUEST SET status=1 WHERE access_code='" + username.getText() + "'";//Updating login status of guest.
            stmt.execute(query);
            rs = stmt.getResultSet();
            if (rs.next()) {
                stmt.executeUpdate(updateStatus);
                App.setRoot("GuestPanel");

            } else {
                Alert alert = new Alert(AlertType.ERROR, "Invalid access code");
                alert.show();
            }
            conn.close();
        } catch (SQLException e) {
            System.out.println(e);
        }

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

}

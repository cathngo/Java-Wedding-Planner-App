package com.unsw.eventplanningapp;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 *
 */
public class GuestHelpPageController implements Initializable {

    @FXML
    void switchToHome(MouseEvent event) throws IOException {

        App.setRoot("GuestPanel");
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

}

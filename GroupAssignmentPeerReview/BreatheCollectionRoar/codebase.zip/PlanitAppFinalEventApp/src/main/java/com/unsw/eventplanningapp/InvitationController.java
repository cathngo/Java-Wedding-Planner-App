package com.unsw.eventplanningapp;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.Initializable;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;

/**
 * FXML Controller class
 *
 *
 */
public class InvitationController implements Initializable {

    private final ObservableList<InvitedGuestModel> masterData = FXCollections.observableArrayList();
    @FXML
    private TableView<InvitedGuestModel> InvitedGuestTable;

    @FXML
    private TableColumn<InvitedGuestModel, String> invitationID_col;

    @FXML
    private TableColumn<InvitedGuestModel, String> eventName_col;

    @FXML
    private TableColumn<InvitedGuestModel, String> eventDesc_col;

    @FXML
    private TableColumn<InvitedGuestModel, String> eventLocation_col;

    @FXML
    private TableColumn<InvitedGuestModel, String> eventTime_col;

    @FXML
    private TableColumn<InvitedGuestModel, String> guestName_col;

    @FXML
    private TableColumn<InvitedGuestModel, String> RSVP_col;

    @FXML
    private TableColumn<InvitedGuestModel, String> diet_col;

    @FXML
    private TableColumn<InvitedGuestModel, String> createdBy_col;

    @FXML
    private Button createPDF;

    @FXML
    private TextField searchEvent;

    @FXML
    private Text successfulInvite;

    @FXML
    void switchToEvent(MouseEvent event) throws IOException {
        App.setRoot("Event");
    }

    @FXML
    void switchToGuest(MouseEvent event) throws IOException {
        App.setRoot("Guest");
    }

    @FXML
    void switchToHome(MouseEvent event) throws IOException {
        App.setRoot("Home");
    }

    @FXML
    void logout(MouseEvent event) throws IOException {
        App.setRoot("Login");
    }

    @FXML
    void switchToAbout(MouseEvent event) throws IOException {
        App.setRoot("About");
    }

    @FXML
    void switchToRunsheet(MouseEvent event) throws IOException {
        App.setRoot("Runsheet");
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initializeColumns();
        fetchInvitedGuest();
        successfulInvite.setVisible(false);

    }

    public void initializeColumns() {
        invitationID_col.setCellValueFactory(new PropertyValueFactory<InvitedGuestModel, String>("invitationId"));
        eventName_col.setCellValueFactory(new PropertyValueFactory<InvitedGuestModel, String>("eventName"));
        eventDesc_col.setCellValueFactory(new PropertyValueFactory<InvitedGuestModel, String>("eventDesc"));
        eventLocation_col.setCellValueFactory(new PropertyValueFactory<InvitedGuestModel, String>("eventLocation"));
        eventTime_col.setCellValueFactory(new PropertyValueFactory<InvitedGuestModel, String>("eventTime"));
        guestName_col.setCellValueFactory(new PropertyValueFactory<InvitedGuestModel, String>("guestName"));
        RSVP_col.setCellValueFactory(new PropertyValueFactory<InvitedGuestModel, String>("RSVP"));
        diet_col.setCellValueFactory(new PropertyValueFactory<InvitedGuestModel, String>("diet"));
        createdBy_col.setCellValueFactory(new PropertyValueFactory<InvitedGuestModel, String>("createdBy"));
    }

    //Method to fetch invited guests from the database.
    void fetchInvitedGuest() {
        try {
            String eventname, eventdesc, eventlocation, eventtime, guestname, rsvp, diet, createdby;
            int invtationid;
            Connection conn = DatabaseManager.openConnection();
            Statement stmt;
            ResultSet rs;
            stmt = conn.createStatement();
            String query = "SELECT INVITATION.invitation_id, EVENT.event_name, EVENT.event_description, EVENT.event_location, EVENT.event_time, GUEST.guest_name,RSVP.decision,RSVP.dietary_requirements,ADMIN.username\n"
                    + "FROM INVITATION\n"
                    + "join EVENT on INVITATION.event_id=EVENT.event_id\n"
                    + "join GUEST on INVITATION.guest_id=GUEST.guest_id\n"
                    + "join RSVP on INVITATION.invitation_id=RSVP.invitation_id\n"
                    + "join ADMIN on INVITATION.admin_id=ADMIN.admin_id";

            stmt.execute(query);
            rs = stmt.getResultSet();
            while (rs.next()) {
                invtationid = rs.getInt("invitation_id");
                eventname = rs.getString("event_name");
                eventdesc = rs.getString("event_description");
                eventlocation = rs.getString("event_location");
                eventtime = rs.getString("event_time");
                guestname = rs.getString("guest_name");
                rsvp = rs.getString("decision");
                diet = rs.getString("dietary_requirements");
                createdby = rs.getString("username");

                masterData.add(new InvitedGuestModel(String.valueOf(invtationid), eventname, eventdesc, eventlocation, eventtime, guestname, rsvp, diet, createdby));
            }
            InvitedGuestTable.setItems(masterData);
            conn.close();

        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    @FXML
    void searchEventDetails(KeyEvent event) {

        FilteredList<InvitedGuestModel> filteredData = new FilteredList<>(masterData, p -> true);

        searchEvent.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(data -> {

                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }

                String lowerCaseFilter = newValue.toLowerCase();

                if (data.getEventName().contains(lowerCaseFilter)) {
                    return true;
                }

                return false;
            });
        });

        SortedList<InvitedGuestModel> sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(InvitedGuestTable.comparatorProperty());
        InvitedGuestTable.setItems(sortedData);
    }

    @FXML
    void createPDF(MouseEvent event) throws FileNotFoundException, DocumentException, MalformedURLException, BadElementException, IOException {

        InvitedGuestModel p = InvitedGuestTable.getSelectionModel().getSelectedItem();
        String eventName = (p.getEventName());
        String eventDesc = (p.getEventDesc());
        String eventLocation = (p.getEventLocation());
        String eventTime = (p.getEventTime());
        String guestName = (p.getGuestName());
        String createdBy = (p.getCreatedBy());

        Document document = new Document();
        String fileName = String.format("%s%s", "Invitation", p.getInvitationId());
        @SuppressWarnings("unused")
        PdfWriter pdfWriter = PdfWriter.getInstance(document, new FileOutputStream(fileName + ".pdf"));
        document.open();

        Font font = FontFactory.getFont(FontFactory.TIMES_ROMAN, 20, Font.ITALIC);
        font.setColor(new BaseColor(0, 194, 203));
        Font font1 = FontFactory.getFont(FontFactory.HELVETICA, 20, Font.BOLD);
        font1.setColor(38, 34, 98);
        String filename = "PlanitLogo.png";
        Image image = Image.getInstance(filename);

        image.scaleToFit(150, 150);
        document.add(image);

        Paragraph paragraph = new Paragraph();
        Paragraph paragraph1 = new Paragraph();
        Paragraph paragraph2 = new Paragraph();
        Paragraph paragraph3 = new Paragraph();
        Paragraph paragraph4 = new Paragraph();
        paragraph.setFont(font);
        paragraph1.setFont(font1);
        paragraph2.setFont(font1);
        paragraph3.setFont(font1);
        paragraph4.setFont(font);
        paragraph.add("Dear " + guestName + ",");
        paragraph1.add("You are invited to the event: " + eventName);

        paragraph2.add("Time: " + eventTime);

        paragraph3.add("Location: " + eventLocation);

        paragraph4.add("Warm Regards, " + createdBy);

        paragraph.setSpacingBefore(80);
        paragraph.setSpacingAfter(50);
        paragraph1.setSpacingBefore(50);
        paragraph2.setSpacingBefore(50);
        paragraph3.setSpacingBefore(50);
        paragraph4.setSpacingBefore(50);
        document.add(paragraph);
        document.add(paragraph1);
        document.add(paragraph2);
        document.add(paragraph3);
        document.add(paragraph4);
        document.close();
        successfulInvite.setVisible(true);

    }
}

package com.unsw.eventplanningapp;

import javafx.beans.property.SimpleStringProperty;

public class GuestModel {

    private final SimpleStringProperty guestId;
    private final SimpleStringProperty guestName;
    private final SimpleStringProperty username;
    private final SimpleStringProperty phoneNumber;
    private final SimpleStringProperty emailAddress;

    public GuestModel(String guestId, String guestName, String username, String phoneNumber, String emailAddress) {
        this.guestId = new SimpleStringProperty(guestId);
        this.guestName = new SimpleStringProperty(guestName);
        this.username = new SimpleStringProperty(username);
        this.phoneNumber = new SimpleStringProperty(phoneNumber);
        this.emailAddress = new SimpleStringProperty(emailAddress);

    }

    public String getGuestId() {
        return guestId.get();
    }

    public String getGuestName() {
        return guestName.get();
    }

    public String getUsername() {
        return username.get();
    }

    public String getPhoneNumber() {
        return phoneNumber.get();
    }

    public String getEmailAddress() {
        return emailAddress.get();
    }

    public void setGuestId(String guestId) {
        this.guestId.set(guestId);
    }

    public void setGuestName(String guestName) {
        this.guestName.set(guestName);
    }

    public void setUsername(String username) {
        this.username.set(username);
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber.set(phoneNumber);
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress.set(emailAddress);
    }

}

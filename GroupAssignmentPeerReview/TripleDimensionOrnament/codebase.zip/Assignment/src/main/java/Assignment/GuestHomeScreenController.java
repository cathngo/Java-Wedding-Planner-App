/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleLongProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author luluZ
 */
public class GuestHomeScreenController implements Initializable {

    
    
    @FXML
    Button btnHome;
    @FXML
    Button btnInvitation;
    @FXML
    Button btnAboutUs;
    @FXML
    Button btnLogout;
    @FXML
    Button btnProfile;

    @FXML
    Text greetingField;


    @FXML
    Button btnManageInvitation;

    @FXML
    private TableView<InvitationInformation> upcomingDataDisplay;
    @FXML
    private TableColumn upcomingId;
    @FXML
    private TableColumn upcomingName;
    @FXML
    private TableColumn upcomingDate;

    @FXML
    private TableView<InvitationInformation> expiredDataDisplay;
    @FXML
    private TableColumn expiredId;
    @FXML
    private TableColumn expiredName;
    @FXML
    private TableColumn expiredDate;

    Database d = new Database();
    
    @FXML
    private void handleHomeButtonAction(ActionEvent event) throws IOException {
        App.setRoot("GuestHomeScreen");
    }

    @FXML
    private void handleInvitationButtonAction(ActionEvent event) throws IOException {
        App.setRoot("GuestManageInvitationScreen");
    }

    @FXML
    private void handleAboutUsButtonAction(ActionEvent event) throws IOException {
        App.setRoot("AboutUsScreen");
    }

    @FXML
    private void handleProfileButtonAction(ActionEvent event) throws IOException {
        App.setRoot("ProfileScreen");
    }

    @FXML
    private void handleLogoutButtonAction(ActionEvent event) throws IOException {
        int logoutConfirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
        if (logoutConfirm == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(null, StaticResource.logoutMessage, "Logout Successful", JOptionPane.INFORMATION_MESSAGE);
            StaticResource.logoutClear();
            App.setRoot("LoginScreen");
        }
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btnProfile.setText(StaticResource.currentUsername);
        StaticResource.currentPage = "GuestHomeScreen";

        Date currentDate = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyy-MM");
        String date = sdf.format(currentDate);

        getUpcomingInvitationData();
        getExpiredInvitationData();

        greetingField.setText("Hi " + StaticResource.currentUsername + ", Welcome to TLEvent.");

        btnHome.setStyle("-fx-text-fill: #FFFFFF;");
        
        upcomingDataDisplay.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                long eventSelected = -1;
                if (event.isPrimaryButtonDown() && event.getClickCount() == 2) {
                    if (!upcomingDataDisplay.getSelectionModel().isEmpty()) {
                        RSVPScreenController.expiredDate = LocalDate.parse(upcomingDataDisplay.getSelectionModel().getSelectedItem().getExpiredDate());
                        RSVPScreenController.selectedEventId = upcomingDataDisplay.getSelectionModel().getSelectedItem().getEventId();
                        RSVPScreenController.selectedInvitationId = upcomingDataDisplay.getSelectionModel().getSelectedItem().getId();
                        try {
                            App.setRoot("RSVPScreen");
                        } catch (IOException ex) {
                            Logger.getLogger(GuestManageInvitationScreenController.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
            }
        });
        
        expiredDataDisplay.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                long guestSelected = -1;
                if (event.isPrimaryButtonDown() && event.getClickCount() == 2) {
                    if (!expiredDataDisplay.getSelectionModel().isEmpty()) {
                        RSVPScreenController.expiredDate = LocalDate.parse(expiredDataDisplay.getSelectionModel().getSelectedItem().getExpiredDate());
                        RSVPScreenController.selectedEventId = expiredDataDisplay.getSelectionModel().getSelectedItem().getEventId();
                        RSVPScreenController.selectedInvitationId = expiredDataDisplay.getSelectionModel().getSelectedItem().getId();
                        try {
                            App.setRoot("RSVPScreen");
                        } catch (IOException ex) {
                            Logger.getLogger(GuestManageInvitationScreenController.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
            }
        });
    }

    public void getUpcomingInvitationData() {
        ObservableList<InvitationInformation> dataList = FXCollections.observableArrayList();

        upcomingId.setCellValueFactory(new PropertyValueFactory<InvitationInformation, String>("Id"));
        upcomingName.setCellValueFactory(new PropertyValueFactory<InvitationInformation, String>("name"));
        upcomingDate.setCellValueFactory(new PropertyValueFactory<InvitationInformation, String>("expiredDate"));

        try {
            ResultSet rs = d.getResultSet("SELECT * FROM INVITATION WHERE GUESTID = '" + StaticResource.currentUserId + "';");
            while (rs.next()) {
                InvitationInformation ii = new InvitationInformation();
                LocalDate expiredDate =  LocalDate.parse(rs.getString(6));
                if(!expiredDate.isBefore(LocalDate.now())){
                    ii.setId(rs.getLong(1));
                    ii.setEventId(Long.parseLong(rs.getString(2)));
                    ResultSet rs1 = d.getResultSet("SELECT * FROM EVENT WHERE EVENTID = '" + rs.getString(2) + "';");
                    while(rs1.next()){
                        ii.setName(rs1.getString(2));
                    }
                    ii.setExpiredDate(rs.getString(6));
                    dataList.add(ii);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        upcomingDate.setSortType(TableColumn.SortType.DESCENDING);
        upcomingDataDisplay.setItems(dataList);
        upcomingDataDisplay.getSortOrder().add(upcomingDate);
    }
    
    public void getExpiredInvitationData() {
        ObservableList<InvitationInformation> dataList = FXCollections.observableArrayList();

        expiredId.setCellValueFactory(new PropertyValueFactory<InvitationInformation, String>("Id"));
        expiredName.setCellValueFactory(new PropertyValueFactory<InvitationInformation, String>("name"));
        expiredDate.setCellValueFactory(new PropertyValueFactory<InvitationInformation, String>("expiredDate"));

        try {
            ResultSet rs = d.getResultSet("SELECT * FROM INVITATION WHERE GUESTID = '" + StaticResource.currentUserId + "';");
            while (rs.next()) {
                InvitationInformation ii = new InvitationInformation();
                LocalDate expiredDate =  LocalDate.parse(rs.getString(6));
                if(expiredDate.isBefore(LocalDate.now())){
                    ii.setId(rs.getLong(1));
                    ii.setEventId(Long.parseLong(rs.getString(2)));
                    ResultSet rs1 = d.getResultSet("SELECT * FROM EVENT WHERE EVENTID = '" + rs.getString(2) + "';");
                    while(rs1.next()){
                        ii.setName(rs1.getString(2));
                    }
                    ii.setExpiredDate(rs.getString(6));
                    dataList.add(ii);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        expiredDate.setSortType(TableColumn.SortType.DESCENDING);
        expiredDataDisplay.setItems(dataList);
        expiredDataDisplay.getSortOrder().add(expiredDate);
    }

    public class InvitationInformation {

        public SimpleLongProperty Id = new SimpleLongProperty();
        public SimpleStringProperty name = new SimpleStringProperty();
        public SimpleStringProperty expiredDate = new SimpleStringProperty();
        public SimpleLongProperty eventId = new SimpleLongProperty();

        public long getId() {
            return Id.get();
        }

        public void setId(long newId) {
            Id.set(newId);
        }

        public String getName() {
            return name.get();
        }

        public void setName(String newName) {
           name.set(newName);
        }

        public String getExpiredDate() {
            return expiredDate.get();
        }

        public void setExpiredDate(String newExpiredDate) {
            expiredDate.set(newExpiredDate);
        }

        public long getEventId() {
            return eventId.get();
        }

        public void setEventId(long newEventId) {
            eventId.set(newEventId);
        }
    }
}

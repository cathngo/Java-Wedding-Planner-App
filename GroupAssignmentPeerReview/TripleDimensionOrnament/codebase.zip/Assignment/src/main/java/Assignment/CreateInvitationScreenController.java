/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleLongProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author luluZ
 */
public class CreateInvitationScreenController implements Initializable {

        
    private String creatorId = StaticResource.currentUserId;
    private String creatorName = StaticResource.currentUsername;
    
    @FXML private Text creatorIdField;
    @FXML private Text creatorNameField;
    @FXML private Text eventIdField;
    @FXML private Text eventNameField;
    @FXML private Text guestIdField;
    @FXML private Text guestNameField;
    @FXML private Text expiredDateField;
    @FXML private Button btnSubmit;
    @FXML private Button btnCancel;
    
    @FXML private TextArea invitationNoteField;
    
    @FXML private ComboBox eventComboBox;
    @FXML private ComboBox guestComboBox;
    
    @FXML private TextField eventSearchField;
    @FXML private TextField guestSearchField;
    
    @FXML private Button btnEventSearch; 
    @FXML private Button btnEventReset;
    @FXML private Button btnGuestSearch;
    @FXML private Button btnGuestReset;
    
    @FXML private TableView<EventInformation> eventDataDisplay;
    @FXML private TableColumn eventId;
    @FXML private TableColumn eventName;
    @FXML private TableColumn eventDate;
    
    @FXML private TableView<GuestInformation> guestDataDisplay;
    @FXML private TableColumn guestId;
    @FXML private TableColumn guestName;
    @FXML private TableColumn accessCode;
    
    Database d = new Database();
    
    @FXML
    private void handleCancelButtonAction(ActionEvent event) throws SQLException, IOException {
        App.setRoot(StaticResource.currentPage);
    }
    
    @FXML
    private void handleSubmitButtonAction(ActionEvent event) throws SQLException, IOException {
        String inputEventId = eventIdField.getText();
        String inputGuestId = guestIdField.getText();
        String inputCreatorId = StaticResource.currentUserId;
        
        Boolean inputCheck = true;
        String errorMessage = "";
        if(inputEventId == null || inputEventId.equals("")){
            errorMessage += "*Please search and select Event from table on right!!\n";
            inputCheck = false;
            eventDataDisplay.setStyle("-fx-border-color: red; -fx-border-width: 2px;");
        }
        
        if(inputGuestId == null || inputGuestId.equals("")){
            errorMessage += "*Please search and select Guest from table on right!!\n";
            inputCheck = false;
            guestDataDisplay.setStyle("-fx-border-color: red; -fx-border-width: 2px;");
        }
        
        if(inputCheck){
            ResultSet rs = d.getResultSet("SELECT * FROM INVITATION WHERE "
                    + "EVENTID = '" + inputEventId + "' AND GUESTID = '" + inputGuestId + "';");
            if (!rs.next()) {
                int click = JOptionPane.showConfirmDialog(null, "Comfirm to send Invitation?", "Invitation", JOptionPane.YES_NO_OPTION);

                if (click == JOptionPane.YES_OPTION) {
                    String insert = "INSERT INTO INVITATION(EVENTID, ADMINID, GUESTID, NOTE, INVITATION_EXPIRED_DATE) "
                            + "VALUES (" + inputEventId + "," + inputCreatorId + ", " + inputGuestId + ", '" + invitationNoteField.getText().trim() +  "', DATE('" + expiredDateField.getText() + "'));";
                    JOptionPane.showMessageDialog(null, "Invitation Created!!", "Invitation Created Successful", JOptionPane.INFORMATION_MESSAGE);
                    Database.insertStatement(insert);
                    resetEventSearch();
                    resetGuestSearch();
                    clearForm();
                    
                }
            } else {
                JOptionPane.showMessageDialog(null, "Duplicated Invitation Found.\nInvitation Id: " + rs.getString(1), "Invitation Found", JOptionPane.INFORMATION_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, errorMessage, "Missing Input", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    @FXML
    private void handleEventSearchButtonAction(ActionEvent event) throws SQLException, IOException {
        String searchType = eventComboBox.getValue().toString();
        String query = "";
        String keyword = eventSearchField.getText().trim();
        
        if(keyword != null && !keyword.equals("")){
            if(searchType.equals("Event Id")){
                query = "SELECT * FROM EVENT WHERE EVENTID LIKE '%" + keyword + "%';";
            } else if(searchType.equals("Event Name")){
                query = "SELECT * FROM EVENT WHERE EVENT_NAME LIKE '%" + keyword + "%';";
            }    
        } else {
            query = "SELECT * FROM EVENT;";
        }
        getEventData(query);

    }
    
    @FXML
    private void handleEventResetButtonAction(ActionEvent event) throws SQLException, IOException {
        resetEventSearch();
        getEventData("SELECT * FROM EVENT;");
        eventIdField.setText("");
        eventNameField.setText("");
        expiredDateField.setText("");
    }
    
    @FXML
    private void handleGuestSearchButtonAction(ActionEvent event) throws SQLException, IOException {
        String searchType = guestComboBox.getValue().toString();
        String query = "";
        String keyword = guestSearchField.getText().trim();
        
        if(keyword != null && !keyword.equals("")){
            if(searchType.equals("Guest Id")){
                query = "SELECT * FROM GUEST_USER WHERE GUESTID LIKE '%" + keyword + "%';";
            } else if(searchType.equals("Guest Name")){
                query = "SELECT * FROM GUEST_USER WHERE FIRSTNAME LIKE '%" + keyword + "%' OR LASTNAME LIKE '%" + keyword + "%';";
            } else if(searchType.equals("Access Code")){
                query = "SELECT * FROM GUEST_USER WHERE ACCESS_CODE LIKE '%" + keyword + "%';";
            }
        } else {
            query = "SELECT * FROM GUEST_USER;";
        }
        getGuestData(query);
    }
    
    @FXML
    private void handleGuestResetButtonAction(ActionEvent event) throws SQLException, IOException {
        resetGuestSearch();
        getGuestData("SELECT * FROM GUEST_USER;");
        guestIdField.setText("");
        guestNameField.setText("");
    }
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        creatorIdField.setText(creatorId);
        creatorNameField.setText(creatorName);
        getGuestData("SELECT * FROM GUEST_USER;");
        getEventData("SELECT * FROM EVENT;");
        
        if(StaticResource.currentPage.equals("EventScreen")){
            eventIdField.setText(String.valueOf(EventScreenController.selectedEventId));
            eventNameField.setText(EventScreenController.selectedEventName);
            expiredDateField.setText(EventScreenController.selectedEventDate);
            EventScreenController.selectedEventId = -1;
            EventScreenController.selectedEventName = null;
            EventScreenController.selectedEventDate = null;
        }
        
        eventComboBox.getItems().addAll(
                "Event Id",
                "Event Name"
        );
        eventComboBox.setValue("Event Id");
        
        guestComboBox.getItems().addAll(
                "Guest Id",
                "Access Code",
                "Guest Name"
        );
        guestComboBox.setValue("Guest Id");
        
        eventDataDisplay.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                long eventSelected = -1;
                if (event.isPrimaryButtonDown() && event.getClickCount() == 1) {
                    if (!eventDataDisplay.getSelectionModel().isEmpty()) {
                        eventSelected = eventDataDisplay.getSelectionModel().getSelectedItem().getEventId();

                        try {
                            ResultSet rs = d.getResultSet("SELECT * FROM EVENT  "
                                    + "WHERE EVENTID = " + eventSelected + ";");
                            eventIdField.setText(rs.getString(1));
                            eventNameField.setText(rs.getString(2));
                            expiredDateField.setText(rs.getString(6));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });

        guestDataDisplay.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                long guestSelected = -1;
                if (event.isPrimaryButtonDown() && event.getClickCount() == 1) {
                    if (!guestDataDisplay.getSelectionModel().isEmpty()) {
                        guestSelected = guestDataDisplay.getSelectionModel().getSelectedItem().getGuestId();

                        try {
                            ResultSet rs = d.getResultSet("SELECT * FROM GUEST_USER  "
                                    + "WHERE GUESTID = " + guestSelected + ";");
                            guestIdField.setText(rs.getString(1));
                            guestNameField.setText(rs.getString(2));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });
    }    
    
    public void getEventData(String query) {
        ObservableList<EventInformation> dataList = FXCollections.observableArrayList();

        eventId.setCellValueFactory(new PropertyValueFactory<EventInformation, String>("EventId"));
        eventName.setCellValueFactory(new PropertyValueFactory<EventInformation, String>("EventName"));
        eventDate.setCellValueFactory(new PropertyValueFactory<EventInformation, String>("EventDate"));

        try {
            ResultSet rs = d.getResultSet(query);
            while (rs.next()) {
                EventInformation ei = new EventInformation();
                ei.setEventId(rs.getLong(1));
                ei.setEventName(rs.getString(2));
                ei.setEventDate(rs.getString(6));

                LocalDate getEventDate = LocalDate.parse(rs.getString(6));
                if (!getEventDate.isBefore(LocalDate.now())) {
                    dataList.add(ei);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        if(dataList.isEmpty()){
            JOptionPane.showMessageDialog(null, "No Event Found!", "Event Search", JOptionPane.INFORMATION_MESSAGE);
        } else {
            eventId.setSortType(TableColumn.SortType.ASCENDING);
            eventDataDisplay.setItems(dataList);
            eventDataDisplay.getSortOrder().add(eventId);
        }
    }
    
    public void getGuestData(String query) {
        ObservableList<GuestInformation> dataList = FXCollections.observableArrayList();

        guestId.setCellValueFactory(new PropertyValueFactory<GuestInformation, String>("GuestId"));
        guestName.setCellValueFactory(new PropertyValueFactory<GuestInformation, String>("GuestName"));
        accessCode.setCellValueFactory(new PropertyValueFactory<GuestInformation, String>("AccessCode"));

        try {
            ResultSet rs = d.getResultSet(query);
            while (rs.next()) {
                GuestInformation gi = new GuestInformation();
                gi.setGuestId(rs.getLong(1));
                gi.setGuestName(rs.getString(4) + " " + rs.getString(5));
                gi.setAccessCode(rs.getString(2));
                
                dataList.add(gi);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if(dataList.isEmpty()){
            JOptionPane.showMessageDialog(null, "No Guest Found!", "Guest Search", JOptionPane.INFORMATION_MESSAGE);
        } else {
            guestId.setSortType(TableColumn.SortType.DESCENDING);
            guestDataDisplay.setItems(dataList);
            guestDataDisplay.getSortOrder().add(guestId);
        }
    }
    
    public void clearForm(){
        eventIdField.setText("");
        eventNameField.setText("");
        guestIdField.setText("");
        guestNameField.setText("");
        expiredDateField.setText("");
        invitationNoteField.clear();
    }
    
    public void resetEventSearch(){
        eventDataDisplay.getItems().clear();
        eventSearchField.clear();
    }
    
    public void resetGuestSearch(){
        guestDataDisplay.getItems().clear();
        guestSearchField.clear();
    }
    
    public class EventInformation {

        public SimpleLongProperty eventId = new SimpleLongProperty();
        public SimpleStringProperty eventName = new SimpleStringProperty();
        public SimpleStringProperty eventDate = new SimpleStringProperty();

        public Long getEventId() {
            return eventId.get();
        }

        public void setEventId(Long newEventId) {
            eventId.set(newEventId);
        }

        public String getEventName() {
            return eventName.get();
        }

        public void setEventName(String newEventName) {
            eventName.set(newEventName);
        }

        public String getEventDate() {
            return eventDate.get();
        }

        public void setEventDate(String newEventDate) {
            eventDate.set(newEventDate);
        }
    }
    
    public class GuestInformation {
        public SimpleLongProperty guestId = new SimpleLongProperty();
        public SimpleStringProperty guestName = new SimpleStringProperty();
        public SimpleStringProperty accessCode = new SimpleStringProperty();
        
        public Long getGuestId() {
            return guestId.get();
        }

        public void setGuestId(Long newGuestId) {
            guestId.set(newGuestId);
        }

        public String getGuestName() {
            return guestName.get();
        }

        public void setGuestName(String newGuestName) {
            guestName.set(newGuestName);
        }

        public String getAccessCode() {
            return accessCode.get();
        }

        public void setAccessCode(String newAccessCode) {
            accessCode.set(newAccessCode);
        }
    }
    
}

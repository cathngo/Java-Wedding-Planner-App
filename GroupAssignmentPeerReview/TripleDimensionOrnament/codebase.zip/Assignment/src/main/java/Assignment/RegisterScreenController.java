/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.regex.Pattern;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javax.swing.JOptionPane;
/**
 * FXML Controller class
 *
 * @author luluZ
 */
public class RegisterScreenController implements Initializable {

    
    @FXML
    DatePicker dateOfBirthField;
    @FXML
    TextField accessCodeField;
    @FXML
    TextField userTypeField;
    @FXML
    TextField emailField;
    @FXML
    TextField firstNameField;
    @FXML
    TextField lastNameField;
    @FXML
    TextField mobileNumberField;
    @FXML
    PasswordField passwordField;
    @FXML
    PasswordField reEnterPasswordField;
    @FXML
    ComboBox genderField;
    @FXML
    Button btnSubmit;
    @FXML
    Button btnCancel;

    @FXML
    Button btnLogin;
    @FXML
    Text reminderText;
    @FXML
    Text reminderText2;

    Database d = new Database();

    String datePattern = "yyyy-MM-dd";
    DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern(datePattern);

    String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."
            + "[a-zA-Z0-9_+&*-]+)*@"
            + "(?:[a-zA-Z0-9-]+\\.)+[a-z"
            + "A-Z]{2,7}$";

    Pattern pat = Pattern.compile(emailRegex);

    @FXML
    private void handleSubmitButtonAction(ActionEvent event) throws IOException {
        passwordField.setStyle("-fx-border-color: transparent;");
        firstNameField.setStyle("-fx-border-color: transparent;");
        lastNameField.setStyle("-fx-border-color: transparent;");
        genderField.setStyle("-fx-border-color: transparent;");
        reEnterPasswordField.setStyle("-fx-border-color: transparent;");
        emailField.setStyle("-fx-border-color: transparent;");
        mobileNumberField.setStyle("-fx-border-color: transparent;");
        dateOfBirthField.setStyle("-fx-border-color: transparent;");

        if (passwordField.getText().trim().isEmpty() || firstNameField.getText().trim().isEmpty()
                || lastNameField.getText().trim().isEmpty() || genderField.getValue() == null || reEnterPasswordField.getText().trim().isEmpty()
                || emailField.getText().trim().isEmpty() || mobileNumberField.getText().trim().isEmpty()
                || dateOfBirthField.getValue() == null) {
            JOptionPane.showMessageDialog(null, "Please fill in all the field to register!", "Information Missing", JOptionPane.INFORMATION_MESSAGE);

            if (passwordField.getText().trim().isEmpty()) {
                passwordField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
            }

            if (firstNameField.getText().trim().isEmpty()) {
                firstNameField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
            }

            if (lastNameField.getText().trim().isEmpty()) {
                lastNameField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
            }

            if (genderField.getValue() == null) {
                genderField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
            }

            if (reEnterPasswordField.getText().trim().isEmpty()) {
                reEnterPasswordField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
            }

            if (emailField.getText().trim().isEmpty()) {
                emailField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
            }

            if (mobileNumberField.getText().trim().isEmpty()) {
                mobileNumberField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
            }

            if (dateOfBirthField.getValue() == null) {
                dateOfBirthField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
            }
        } else {

            String pword = passwordField.getText();
            String fname = firstNameField.getText();
            String lname = lastNameField.getText();
            String gder = genderField.getValue().toString();
            String mobile = mobileNumberField.getText().trim();
            String email = emailField.getText().trim();
            LocalDate dateob = dateOfBirthField.getValue();
            String dob = dateFormat.format(dateOfBirthField.getValue());

            Random random = new Random();
            String randomNumber = String.format("%04d", random.nextInt(10000));

            String accessCode = fname.replaceAll("[^a-zA-Z0-9]", "") + lname.replaceAll("[^a-zA-Z0-9]", "") + randomNumber;
            String errorMessage = "";

            if (!StaticResource.passwordCheck(pword, reEnterPasswordField.getText()).equals("")) {
                errorMessage += StaticResource.passwordCheck(pword, reEnterPasswordField.getText()) + "\n";
                passwordField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
                reEnterPasswordField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
            }

            if (!pat.matcher(email).matches()) {
                errorMessage += "*Invalid Email! Check your email format!\n\n";
                emailField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
            }
            
            if(fname.length() > 20){
                errorMessage += "*Maximum 20 characters for First Name!!\n\n";
                firstNameField.setStyle("-fx-border-color: red; -fx-border-width:2px;");;
            }
            
            if(lname.length() > 20){
                errorMessage += "*Maximum 20 characters for Last Name!!\n\n";
                lastNameField.setStyle("-fx-border-color: red; -fx-border-width:2px;");;
            }

            if (!mobile.matches("[0-9]+") || mobile.length() < 10 || mobile.length() > 10 || !mobile.substring(0, 2).equals("04")) {
                errorMessage += "*Invalid mobile number! Please insert Australia mobile number!!\n\n";
                mobileNumberField.setStyle("-fx-border-color: red; -fx-border-width:2px;");;
            }

            LocalDate today = LocalDate.now();
            if (dateob.isAfter(today)) {
                errorMessage += "*Invalid Date of Birth.Don't lie to me, you are not from future.\n\n";
                dateOfBirthField.setStyle("-fx-border-color: red;");
            }

            if (errorMessage.equals("")) {
                try {
                    ResultSet rs = d.getResultSet("SELECT * FROM GUEST_USER WHERE "
                            + "ACCESS_CODE = '" + accessCode + "';");

                    while (rs.next()) {
                        randomNumber = String.format("%04d", random.nextInt(10000));

                        accessCode = fname.replaceAll("[^a-zA-Z0-9]", "") + lname.replaceAll("[^a-zA-Z0-9]", "") + randomNumber;

                        rs = d.getResultSet("SELECT * FROM GUEST_USER WHERE "
                                + "ACCESS_CODE = '" + accessCode + "';");
                    }

                    if (!rs.next()) {
                        rs = d.getResultSet("SELECT * FROM GUEST_USER WHERE "
                                + "EMAIL = '" + email + "';");
                        if (!rs.next()) {
                            rs = d.getResultSet("SELECT * FROM GUEST_USER WHERE "
                                    + "MOBILENUMBER = '" + mobile + "';");
                            if (!rs.next()) {
                                int click = JOptionPane.showConfirmDialog(null, "Comfirm to create new account?", "Create new account", JOptionPane.YES_NO_OPTION);

                                DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                Date date = new Date();
                                String currentDateTime = dateFormat.format(date);
                                
                                if (click == JOptionPane.YES_OPTION) {
                                    String insertAccount = "INSERT INTO GUEST_USER(ACCESS_CODE, PASSWORD, FIRSTNAME, LASTNAME, GENDER, DATEOFBIRTH, MOBILENUMBER, EMAIL, CREATED_DATE, CREATED_BY) "
                                            + "VALUES ('" + accessCode + "','" + pword + "', '" + fname + "', '" + lname + "', '" + gder + "', DATE('" + dob + "'), '" + mobile + "', '" + email + "', DATE('" + currentDateTime + "'), " + -1 +");";
                                    accessCodeField.setText(accessCode);
                                    JOptionPane.showMessageDialog(null, "Account created! Your Access Code is \"" + accessCode + "\"", "Account Created Successful", JOptionPane.INFORMATION_MESSAGE);
                                    Database.insertStatement(insertAccount);

                                    btnSubmit.setVisible(false);
                                    btnCancel.setVisible(false);

                                    accessCodeField.setStyle("-fx-border-color: #AB8431; -fx-border-width:2px;");
                                    btnLogin.setVisible(true);
                                    reminderText.setVisible(true);
                                    reminderText2.setVisible(true);
                                }
                            } else {
                                JOptionPane.showMessageDialog(null, "*Mobile Number used! Please use other Mobile Number!", "Invalid Mobile Number", JOptionPane.INFORMATION_MESSAGE);
                                mobileNumberField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "*Email used! Please use other email!", "Invalid Email", JOptionPane.INFORMATION_MESSAGE);
                            emailField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                JOptionPane.showMessageDialog(null, errorMessage, "Input Error", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }

    @FXML
    private void handleCancelButtonAction(ActionEvent event) throws IOException {
        App.setRoot("LoginScreen");
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        accessCodeField.setEditable(false);
        accessCodeField.setFocusTraversable(false);
        accessCodeField.setMouseTransparent(true);
        userTypeField.setEditable(false);
        userTypeField.setFocusTraversable(false);
        userTypeField.setMouseTransparent(true);

        genderField.getItems().addAll(
                "Male",
                "Female",
                "Not Specified"
        );
        genderField.setValue("Male");
        
        dateOfBirthField.setValue(LocalDate.now());
    }
}

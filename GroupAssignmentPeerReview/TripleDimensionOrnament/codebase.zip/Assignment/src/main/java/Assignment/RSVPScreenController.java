/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment;

import static Assignment.EventDetailScreenController.selectedEventId;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.List;
import com.itextpdf.text.ListItem;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.ZapfDingbatsList;
import com.itextpdf.text.pdf.CMYKColor;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author luluZ
 */
public class RSVPScreenController implements Initializable {

    
    @FXML private Text eventIdField;
    @FXML private Text eventNameField;
    @FXML private Text eventDateField;
    @FXML private Text startTimeField;
    @FXML private Text endTimeField;
    @FXML private TextArea eventIntroductionField;
    @FXML private Text createdAtField;
    @FXML private Text updatedAtField;
    
    @FXML private Text invitationId;
    @FXML private ComboBox decision;
    @FXML private TextArea dietaryRequirement;
    @FXML private Text expiredNotice;
    

    @FXML private Button btnBack;
    @FXML private Button btnPDF;
    @FXML private Button btnSubmit;

    @FXML
    private TableView<EventDetail> dataDisplay;
    @FXML private TableColumn timeSlot;
    @FXML private TableColumn timeSlotDetail;
    
    public static long selectedEventId = -1;
    public static long selectedInvitationId = -1;
    private ArrayList<String> tempEventDetailData = new ArrayList<String>();
    private String selectedTimeSlot = "";
    private int eventStartTime = -1;
    private int eventEndTime = -1;
    public static LocalDate expiredDate = null;
    
    Database d = new Database();
    
    @FXML
    private void handleBackButtonAction(ActionEvent event) throws IOException {
        App.setRoot(StaticResource.currentPage);
    }
    
    public class Background extends PdfPageEventHelper {
        @Override
        public void onEndPage(PdfWriter writer, Document document) {
            int pagenumber = writer.getPageNumber();
            if (pagenumber % 2 == 1 && pagenumber != 1) {
                return;
            }
            PdfContentByte canvas = writer.getDirectContentUnder();
            Rectangle rect = document.getPageSize();
            canvas.setColorFill(pagenumber < 3 ? BaseColor.BLACK : BaseColor.BLACK);
            canvas.rectangle(rect.getLeft(), rect.getBottom(), rect.getWidth(), rect.getHeight());
            canvas.fill();
        }
    }
    
    @FXML
    private void handlePDFButtonAction(ActionEvent event) throws IOException, SQLException {
        String pdfName = "Invitation_" + StaticResource.currentUsername;
        int versionTracker = 0;

        Document document = new Document();
        try{
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Select Folder");
            fileChooser.setCurrentDirectory(new File(System.getProperty("user.home") + "Documents"));
            fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            fileChooser.setAcceptAllFileFilterUsed(false);

            int userSelection = fileChooser.showSaveDialog(null);

            if (userSelection == JFileChooser.APPROVE_OPTION) {
                File fileToSave = fileChooser.getSelectedFile();
                String path = fileToSave.getAbsolutePath() + "/" + pdfName + ".pdf";
                System.out.println(path);
                for(int i = 1; ; i++){
                    File tmpDir = new File(path);
                    if(!tmpDir.exists()) {
                        break;
                    } else {
                        path = fileToSave.getAbsolutePath() + "/" + pdfName + "(" + i + ").pdf";
                        versionTracker = i;
                    }
                }

                PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(path));
                Background bg = new Background();
                writer.setPageEvent(bg);
                document.open();
                
                Image logo = Image.getInstance(getClass().getResource("/image/tlevent_logo.png").toExternalForm());
                logo.scaleAbsolute(150, 150);
                logo.setAlignment(Image.ALIGN_CENTER);
                
                document.add(logo);
                Font whiteFont = FontFactory.getFont(FontFactory.HELVETICA, 15, Font.NORMAL, new CMYKColor(0, 0, 0, 0));
                Font whiteFontBig = FontFactory.getFont(FontFactory.HELVETICA, 32, Font.BOLD, new CMYKColor(0, 0, 0, 0));
                Font whiteFontBig2 = FontFactory.getFont(FontFactory.HELVETICA, 22, Font.BOLD, new CMYKColor(0, 0, 0, 0));
                ZapfDingbatsList zapfDingbatsList = new ZapfDingbatsList(43, 30, BaseColor.WHITE);
                
                Paragraph p = new Paragraph();
                p = new Paragraph("\n", whiteFont);
                document.add(p);
                p = new Paragraph("\n", whiteFont);
                document.add(p);
                p = new Paragraph("This is the invitation from TLEvent to", whiteFont);
                p.setAlignment(Paragraph.ALIGN_CENTER);
                document.add(p);
                
                p = new Paragraph("\n", whiteFont);
                document.add(p);
                p = new Paragraph(StaticResource.currentUsername, whiteFontBig);
                p.setAlignment(Paragraph.ALIGN_CENTER);
                document.add(p);
                p = new Paragraph("\n", whiteFont);
                document.add(p);

                p = new Paragraph("for the event", whiteFont);
                p.setAlignment(Paragraph.ALIGN_CENTER);
                document.add(p);
                
                p = new Paragraph("\n", whiteFont);
                p.setAlignment(Paragraph.ALIGN_CENTER);
                document.add(p);
                
                ResultSet rs = d.getResultSet("SELECT * FROM EVENT  "
                        + "WHERE EVENTID = " + selectedEventId + ";");
                p = new Paragraph("\"" + rs.getString(2) + "\"", whiteFontBig2);
                p.setAlignment(Paragraph.ALIGN_CENTER);
                document.add(p);
                
                p = new Paragraph("\n", whiteFont);
                document.add(p);
                
                p = new Paragraph(rs.getString(6), whiteFont);
                p.setAlignment(Paragraph.ALIGN_CENTER);
                document.add(p);
                
                p = new Paragraph("\n", whiteFont);
                document.add(p);
                
                p = new Paragraph("Start from " 
                        + String.valueOf(eventStartTime).substring(0,2)
                        + ":"
                        + String.valueOf(eventStartTime).substring(2) + " to " 
                        + String.valueOf(eventEndTime).substring(0,2)
                        + ":"
                        + String.valueOf(eventEndTime).substring(2), whiteFont);
                p.setAlignment(Paragraph.ALIGN_CENTER);
                document.add(p);

                p = new Paragraph("\n", whiteFont);
                document.add(p);
                
                p = new Paragraph("Event RunSheet: ", whiteFont);
                p.setAlignment(Paragraph.ALIGN_CENTER);
                document.add(p);
                if(tempEventDetailData.size() < 1){
                    p = new Paragraph("No Runsheet Found", whiteFont);
                    zapfDingbatsList.add(new ListItem(p));
                } else {
                    for (String s : tempEventDetailData) {
                        String time = s.substring(0, 2) + ":" + s.substring(2, 4);
                        String detail = "\t" + s.substring(4);
                        p = new Paragraph(time + "       " + detail, whiteFont);
                        p.setAlignment(Paragraph.ALIGN_CENTER);
                        zapfDingbatsList.add(new ListItem(p));
                    }
                }
                zapfDingbatsList.setDingbatColor(BaseColor.WHITE);
                
                document.add(zapfDingbatsList);

                document.addAuthor(StaticResource.currentUsername);
                document.addCreationDate();
                document.addCreator("TLEvent - First Class Planner");
                document.addSubject("BLablabla");
                document.close();
                writer.close();
                
                
                
                if(versionTracker != 0){
                    pdfName += "(" + versionTracker + ").pdf";
                } else {
                    pdfName += ".pdf";
                }
                
                JOptionPane.showMessageDialog(null, "PDF Generated.\nFile Name: " + pdfName, "PDF Generated", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (DocumentException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    
    @FXML
    private void handleSubmitButtonAction(ActionEvent event) throws IOException, SQLException {
        if(dietaryRequirement.getText() != null){
            Database.insertStatement("UPDATE RSVP SET "
                            + "DECISION = '" + decision.getValue().toString() + "', "
                            + "DIETARY_REQUIREMENTS = '" + dietaryRequirement.getText().trim() + "' "
                            + "WHERE INVITATIONID = '" + selectedInvitationId + "';");
        } else {
            Database.insertStatement("UPDATE RSVP SET "
                            + "DECISION = '" + decision.getValue().toString() + "' "
                            + "WHERE INVITATIONID = '" + selectedInvitationId + "';");
        }
        JOptionPane.showMessageDialog(null, "Response updated!", "Successful Updated", JOptionPane.INFORMATION_MESSAGE);
    }
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        eventIntroductionField.setEditable(false);
        decision.getItems().addAll(
                "Accept", "Decline"
        );
        decision.setValue("Accept");
        
        try {
            ResultSet rs = d.getResultSet("SELECT * FROM EVENT  "
                    + "WHERE EVENTID = '" + selectedEventId + "';");

            System.out.println("selectedEventId:" + selectedEventId);
            while (rs.next()) {
                eventIdField.setText(rs.getString(1));
                eventNameField.setText(rs.getString(2));
                eventIntroductionField.setText(rs.getString(3));
                eventDateField.setText(rs.getString(6));
                startTimeField.setText(rs.getString(7).substring(0, 2) + ":" + rs.getString(7).substring(2));
                endTimeField.setText(rs.getString(8).substring(0, 2) + ":" + rs.getString(8).substring(2));
                createdAtField.setText(rs.getString(4));
                eventStartTime = Integer.parseInt(rs.getString(7));
                eventEndTime = Integer.parseInt(rs.getString(8));

                if (rs.getString(5) != null && !rs.getString(5).equals("")) {
                    updatedAtField.setText(rs.getString(5));
                } else {
                    updatedAtField.setText("");
                }
            }

            ResultSet rs2 = d.getResultSet("SELECT * FROM RSVP  "
                    + "WHERE INVITATIONID = '" + selectedInvitationId + "';");
            if (rs2.next()) {
                invitationId.setText(rs2.getString(2));
                decision.setValue(rs2.getString(3));
                dietaryRequirement.setText(rs2.getString(4));
            } else {
                Database.insertStatement("INSERT INTO RSVP(INVITATIONID, RSVP_DATE, DECISION) VALUES ('" + selectedInvitationId + "', DATE('" + LocalDate.now() + "'), 'No Response');");
                rs2 = d.getResultSet("SELECT * FROM RSVP  "
                        + "WHERE INVITATIONID = '" + selectedInvitationId + "';");
                if (rs2.next()) {
                    invitationId.setText(rs2.getString(2));
                    decision.setValue(rs2.getString(3));
                    dietaryRequirement.setText(rs2.getString(4));
                }
            }
            
            if (expiredDate.isBefore(LocalDate.now())) {
                decision.setMouseTransparent(true);
                dietaryRequirement.setMouseTransparent(true);
                dietaryRequirement.setEditable(false);
                btnSubmit.setVisible(false);
                expiredNotice.setVisible(true);
                expiredNotice.setText("This invitation has expired on " + expiredDate + ".");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        getData();
    }    
    
    public void getData(){
        ObservableList<EventDetail> dataList = FXCollections.observableArrayList();

        timeSlot.setCellValueFactory(new PropertyValueFactory<EventDetail, String>("timeSlot"));
        timeSlotDetail.setCellValueFactory(new PropertyValueFactory<EventDetail, String>("timeSlotDetail"));
        
        try {
            ResultSet rs = d.getResultSet("SELECT EVENTDETAIL FROM EVENT_TIMELINE  "
                    + "WHERE EVENTID = '" + selectedEventId + "';");
            if(rs.next()){
                if (rs.getString(1) != null && !rs.getString(1).equals("")) {
                    String rawDetail = rs.getString(1);
                    String[] detailArray = rawDetail.split(";;;");

                    for (String s : detailArray) {
                        EventDetail ed = new EventDetail();
                        ed.setTimeSlot(s.substring(0, 2) + ":" + s.substring(2, 4));
                        ed.setTimeSlotDetail(s.substring(4));
                        dataList.add(ed);
                    }
                    
                    if(tempEventDetailData.size() != detailArray.length){
                        tempEventDetailData.clear();
                        for (String s : detailArray) {
                            tempEventDetailData.add(s);
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        if (dataList.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No Runsheet Found on this Event!", "Runsheet Search", JOptionPane.INFORMATION_MESSAGE);
        } else {
            timeSlot.setSortType(TableColumn.SortType.ASCENDING);
            dataDisplay.setItems(dataList);
            dataDisplay.getSortOrder().add(timeSlot);
        }
    }
    
    public class EventDetail{
        public SimpleStringProperty timeSlot = new SimpleStringProperty();
        public SimpleStringProperty timeSlotDetail = new SimpleStringProperty();

        public String getTimeSlot() {
            return timeSlot.get();
        }

        public void setTimeSlot(String newTimeSlot) {
            timeSlot.set(newTimeSlot);
        }

        public String getTimeSlotDetail() {
            return timeSlotDetail.get();
        }

        public void setTimeSlotDetail(String newTimeSlotDetail) {
            timeSlotDetail.set(newTimeSlotDetail);
        }
    }
}

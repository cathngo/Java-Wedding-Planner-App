/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleLongProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author luluZ
 */
public class AdminHomeScreenController implements Initializable {

    
    @FXML
    Button btnHome;
    @FXML
    Button btnEvent;
    @FXML
    Button btnInvitation;
    @FXML
    Button btnAboutUs;
    @FXML
    Button btnLogout;
    @FXML
    Button btnProfile;

    @FXML
    Text greetingField;

    @FXML
    Button btnManageEvent;
    @FXML
    Button btnManageInvitation;
    @FXML
    Button btnManageGuest;
    @FXML
    Button btnManageAdmin;

    @FXML
    private TableView<EventInformation> eventDataDisplay;
    @FXML
    private TableColumn eventId;
    @FXML
    private TableColumn eventName;
    @FXML
    private TableColumn eventDate;

    @FXML
    private TableView<GuestInformation> guestDataDisplay;
    @FXML
    private TableColumn guestId;
    @FXML
    private TableColumn guestName;
    @FXML
    private TableColumn createdDate;

    Database d = new Database();

    @FXML
    private void handleManageGuestButtonAction(ActionEvent event) throws IOException {
        try{
        App.setRoot("ManageGuestScreen");
        } catch (Exception e){
            e.printStackTrace();
        }
    }
    
    @FXML
    private void handleManageAdminButtonAction(ActionEvent event) throws IOException {
        App.setRoot("ManageAdminScreen");
    }
    
    @FXML
    private void handleHomeButtonAction(ActionEvent event) throws IOException {
        App.setRoot("AdminHomeScreen");
    }

    @FXML
    private void handleEventButtonAction(ActionEvent event) throws IOException {
        App.setRoot("EventScreen");
    }

    @FXML
    private void handleInvitationButtonAction(ActionEvent event) throws IOException {
        App.setRoot("InvitationScreen");
    }

    @FXML
    private void handleAboutUsButtonAction(ActionEvent event) throws IOException {
        App.setRoot("AboutUsScreen");
    }

    @FXML
    private void handleProfileButtonAction(ActionEvent event) throws IOException {
        App.setRoot("ProfileScreen");
    }

    @FXML
    private void handleLogoutButtonAction(ActionEvent event) throws IOException {
        int logoutConfirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
        if (logoutConfirm == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(null, StaticResource.logoutMessage, "Logout Successful", JOptionPane.INFORMATION_MESSAGE);
            StaticResource.logoutClear();
            App.setRoot("LoginScreen");
        }
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btnProfile.setText(StaticResource.currentUsername);
        StaticResource.currentPage = "AdminHomeScreen";

        Date currentDate = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyy-MM");
        String date = sdf.format(currentDate);

        getEventData(date);
        getGuestData(date);

        greetingField.setText("Hi " + StaticResource.currentUsername + ", Welcome to TLEvent.");

        btnHome.setStyle("-fx-text-fill: #FFFFFF;");
        
        eventDataDisplay.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                long eventSelected = -1;
                if (event.isPrimaryButtonDown() && event.getClickCount() == 2) {
                    if (!eventDataDisplay.getSelectionModel().isEmpty()){
                        eventSelected = eventDataDisplay.getSelectionModel().getSelectedItem().getEventId();
                        EventDetailScreenController.selectedEventId = eventSelected;
                        try {
                            App.setRoot("EventDetailScreen");
                        } catch (IOException ex) {
                            Logger.getLogger(AdminHomeScreenController.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
            }
        });
        
        guestDataDisplay.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                long guestSelected = -1;
                if (event.isPrimaryButtonDown() && event.getClickCount() == 2) {
                    if (!guestDataDisplay.getSelectionModel().isEmpty()){
                        guestSelected = guestDataDisplay.getSelectionModel().getSelectedItem().getGuestId();
                        ManageGuestScreenController.adminHomeSelected = guestSelected;
                        try {
                            App.setRoot("ManageGuestScreen");
                        } catch (IOException ex) {
                            Logger.getLogger(AdminHomeScreenController.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
            }
        });
    }

    public void getEventData(String dateSearch) {
        ObservableList<EventInformation> dataList = FXCollections.observableArrayList();

        eventId.setCellValueFactory(new PropertyValueFactory<EventInformation, String>("EventId"));
        eventName.setCellValueFactory(new PropertyValueFactory<EventInformation, String>("EventName"));
        eventDate.setCellValueFactory(new PropertyValueFactory<EventInformation, String>("EventDate"));

        try {
            ResultSet rs = d.getResultSet("SELECT * FROM EVENT WHERE EVENT_DATE LIKE '" + dateSearch + "%' "
                    + "AND EVENT_DATE ;");
            while (rs.next()) {
                EventInformation ei = new EventInformation();
                ei.setEventId(rs.getLong(1));
                ei.setEventName(rs.getString(2));
                ei.setEventDate(rs.getString(6));

                LocalDate getEventDate = LocalDate.parse(rs.getString(6));
                if (!getEventDate.isBefore(LocalDate.now())) {
                    dataList.add(ei);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        eventDate.setSortType(TableColumn.SortType.ASCENDING);
        eventDataDisplay.setItems(dataList);
        eventDataDisplay.getSortOrder().add(eventDate);
    }
    
    public void getGuestData(String dateSearch) {
        ObservableList<GuestInformation> dataList = FXCollections.observableArrayList();

        guestId.setCellValueFactory(new PropertyValueFactory<GuestInformation, String>("GuestId"));
        guestName.setCellValueFactory(new PropertyValueFactory<GuestInformation, String>("GuestName"));
        createdDate.setCellValueFactory(new PropertyValueFactory<GuestInformation, String>("CreatedDate"));

        try {
            ResultSet rs = d.getResultSet("SELECT * FROM GUEST_USER WHERE CREATED_DATE LIKE '" + dateSearch + "%';");
            while (rs.next()) {
                GuestInformation gi = new GuestInformation();
                gi.setGuestId(rs.getLong(1));
                gi.setGuestName(rs.getString(4) + " " + rs.getString(5));
                gi.setCreatedDate(rs.getString(10));
                
                dataList.add(gi);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        createdDate.setSortType(TableColumn.SortType.DESCENDING);
        guestDataDisplay.setItems(dataList);
        guestDataDisplay.getSortOrder().add(createdDate);
    }

    public class EventInformation {

        public SimpleLongProperty eventId = new SimpleLongProperty();
        public SimpleStringProperty eventName = new SimpleStringProperty();
        public SimpleStringProperty eventDate = new SimpleStringProperty();

        public long getEventId() {
            return eventId.get();
        }

        public void setEventId(long newEventId) {
            eventId.set(newEventId);
        }

        public String getEventName() {
            return eventName.get();
        }

        public void setEventName(String newEventName) {
            eventName.set(newEventName);
        }

        public String getEventDate() {
            return eventDate.get();
        }

        public void setEventDate(String newEventDate) {
            eventDate.set(newEventDate);
        }
    }
    
    public class GuestInformation {
        public SimpleLongProperty guestId = new SimpleLongProperty();
        public SimpleStringProperty guestName = new SimpleStringProperty();
        public SimpleStringProperty createdDate = new SimpleStringProperty();
        
        public long getGuestId() {
            return guestId.get();
        }

        public void setGuestId(long newGuestId) {
            guestId.set(newGuestId);
        }

        public String getGuestName() {
            return guestName.get();
        }

        public void setGuestName(String newGuestName) {
            guestName.set(newGuestName);
        }

        public String getCreatedDate() {
            return createdDate.get();
        }

        public void setCreatedDate(String newCreatedDate) {
            createdDate.set(newCreatedDate);
        }
    }   
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Database class
 * References: UNSW Business School 2020/T1 INFS2605 Tutorial Work Indiefy Project
 * @author luluZ
 */


public class Database {
    
    public static Connection conn;

    public static void openConnection() {
        if (conn == null) {
            try {
                conn = DriverManager.getConnection("jdbc:sqlite:TLEvent.db");
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    
    public ResultSet getResultSet(String sqlstatement) throws SQLException {
        openConnection();
        java.sql.Statement statement = conn.createStatement();
        ResultSet RS = statement.executeQuery(sqlstatement);
        return RS;
    }
    
    public static void insertStatement(String insert_query) throws SQLException {
        java.sql.Statement stmt = null;
        openConnection();
        try {
            stmt = conn.createStatement();
            stmt.executeUpdate(insert_query);
            stmt.close();
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
        stmt.close();
    }
    
    public static void removeDatabase(){
        PreparedStatement createBodyConditionTable = null;
        ResultSet rs = null;
        openConnection();
        try {
            createBodyConditionTable = conn.prepareStatement("DROP TABLE ADMIN_USER;");
            createBodyConditionTable.execute();
            System.out.println("ADMIN_USER table removed.");
            createBodyConditionTable = conn.prepareStatement("DROP TABLE GUEST_USER;");
            createBodyConditionTable.execute();
            System.out.println("GUEST_USER table removed.");
            createBodyConditionTable = conn.prepareStatement("DROP TABLE EVENT;");
            createBodyConditionTable.execute();
            System.out.println("EVENT table removed.");
            createBodyConditionTable = conn.prepareStatement("DROP TABLE INVITATION;");
            createBodyConditionTable.execute();
            System.out.println("INVITATION table removed.");
            createBodyConditionTable = conn.prepareStatement("DROP TABLE RSVP;");
            createBodyConditionTable.execute();
            System.out.println("RSPV table removed.");
            createBodyConditionTable = conn.prepareStatement("DROP TABLE EVENT_TIMELINE;");
            createBodyConditionTable.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static void loadDatabase(){
        Database.createAdminUserTable();
        Database.createGuestUserTable();
        Database.createEventTable();
        Database.createInvitationTable();
        Database.createRSVPTable();
        Database.createEventTimelineTable();
    }
    
    public static void createAdminUserTable(){
        PreparedStatement createTable = null;
        PreparedStatement insertData = null;
        ResultSet rs = null;
        openConnection();
        try {
            System.out.println("Checking ADMIN_USER table ");
            DatabaseMetaData dbmd = conn.getMetaData();
            rs = dbmd.getTables(null, null, "ADMIN_USER", null);
            if (!rs.next()) {
                createTable = conn.prepareStatement("CREATE TABLE ADMIN_USER ("
                        + "ADMINID INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + "USERNAME VARCHAR(100) UNIQUE NOT NULL, "
                        + "PASSWORD VARCHAR(100) NOT NULL, "
                        + "FIRSTNAME VARCHAR(100) NOT NULL, "
                        + "LASTNAME VARCHAR(100) NOT NULL, "
                        + "GENDER VARCHAR(6) NOT NULL, "
                        + "DATEOFBIRTH TEXT NOT NULL,"
                        + "MOBILENUMBER VARCHAR(10) NOT NULL,"
                        + "EMAIL VARCHAR(255) NOT NULL,"
                        + "CREATED_DATE TEXT NOT NULL,"
                        + "CREATED_BY INTEGER NOT NULL);"
                );
                createTable.execute();
                System.out.println("ADMIN_USER table created");
                insertData = conn.prepareStatement("INSERT INTO ADMIN_USER(ADMINID, USERNAME, PASSWORD, FIRSTNAME, LASTNAME, GENDER, DATEOFBIRTH, MOBILENUMBER, EMAIL, CREATED_DATE, CREATED_BY) "
                        + "VALUES (90000001-1, 'test','test', 'test', 'test', 'Male', DATE('2020-04-08'), '0412345678', 'admin@admin.com', DATE('2020-01-01'), 90000001);");
                insertData.execute();
                insertData = conn.prepareStatement("DELETE FROM ADMIN_USER WHERE ADMINID = 90000000;");
                insertData.execute();
                insertData = conn.prepareStatement("INSERT INTO ADMIN_USER(USERNAME, PASSWORD, FIRSTNAME, LASTNAME, GENDER, DATEOFBIRTH, MOBILENUMBER, EMAIL, CREATED_DATE, CREATED_BY) "
                        + "VALUES ( 'admin','admin', 'System', 'Admin', 'Male', DATE('2020-04-08'), '0412345678', 'admin@admin.com', DATE('2020-01-01'), 90000001);");
                insertData.execute();
            } else {
                System.out.println("ADMIN_USER table exists");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static void createGuestUserTable() {
        PreparedStatement createTable = null;
        PreparedStatement insertData = null;
        ResultSet rs = null;
        openConnection();
        try {
            System.out.println("Checking GUEST_USER table ");
            DatabaseMetaData dbmd = conn.getMetaData();
            rs = dbmd.getTables(null, null, "GUEST_USER", null);
            if (!rs.next()) {
                createTable = conn.prepareStatement("CREATE TABLE GUEST_USER ("
                        + "GUESTID INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + "ACCESS_CODE VARCHAR(100) UNIQUE NOT NULL, "
                        + "PASSWORD VARCHAR(100) NOT NULL, "
                        + "FIRSTNAME VARCHAR(100) NOT NULL, "
                        + "LASTNAME VARCHAR(100) NOT NULL, "
                        + "GENDER VARCHAR(6) NOT NULL, "
                        + "DATEOFBIRTH TEXT NOT NULL,"
                        + "MOBILENUMBER VARCHAR(10) NOT NULL,"
                        + "EMAIL VARCHAR(255) NOT NULL,"
                        + "CREATED_DATE TEXT NOT NULL,"
                        + "CREATED_BY INTEGER NOT NULL);"
                );
                createTable.execute();
                System.out.println("GUEST_USER table created");
                insertData = conn.prepareStatement("INSERT INTO GUEST_USER(GUESTID, ACCESS_CODE, PASSWORD, FIRSTNAME, LASTNAME, GENDER, DATEOFBIRTH, MOBILENUMBER, EMAIL, CREATED_DATE, CREATED_BY) "
                        + "VALUES (10000001-1, 'test','test', 'test', 'test', 'Male', DATE('2020-01-01'), '0412345678', 'guest1@sample.com', DATE('2020-01-01'), 90000001);");
                insertData.execute();
                insertData = conn.prepareStatement("DELETE FROM GUEST_USER WHERE GUESTID = 10000000;");
                insertData.execute();
                insertData = conn.prepareStatement("INSERT INTO GUEST_USER(ACCESS_CODE, PASSWORD, FIRSTNAME, LASTNAME, GENDER, DATEOFBIRTH, MOBILENUMBER, EMAIL, CREATED_DATE, CREATED_BY) "
                        + "VALUES ('guest1234','password', 'sample', 'guest', 'Male', DATE('1990-01-01'), '0412345678', 'guest1@sample.com', DATE('2020-01-01'), 90000001), "
                        + "('guest5678','password', 'sample', 'guest', 'Female', DATE('2000-01-01'), '0412345678', 'guest1@sample.com', DATE('2020-02-02'), 90000001);");
                insertData.execute();
            } else {
                System.out.println("GUEST_USER table exists");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static void createEventTable() {
        PreparedStatement createTable = null;
        PreparedStatement insertData = null;
        ResultSet rs = null;
        openConnection();
        try {
            System.out.println("Checking EVENT table ");
            DatabaseMetaData dbmd = conn.getMetaData();
            rs = dbmd.getTables(null, null, "EVENT", null);
            if (!rs.next()) {
                createTable = conn.prepareStatement("CREATE TABLE EVENT ("
                        + "EVENTID INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + "EVENT_NAME VARCHAR(255) NOT NULL, "
                        + "INTRODUCTION TEXT NOT NULL, "
                        + "CREATED_DATE TEXT NOT NULL, "
                        + "UPDATED_DATE TEXT, "
                        + "EVENT_DATE TEXT NOT NULL, "
                        + "START_TIME TEXT NOT NULL,"
                        + "END_TIME TEXT NOT NULL, "
                        + "CREATED_BY INTEGER NOT NULL, "
                        + "UPDATED_BY INTEGER);"
                );
                createTable.execute();
                System.out.println("EVENT table created");
                insertData = conn.prepareStatement("INSERT INTO EVENT(EVENT_NAME, INTRODUCTION, CREATED_DATE, CREATED_BY, START_TIME, END_TIME, EVENT_DATE) "
                        + "VALUES ('Sample Event 1','Sample Data Event 1', DATETIME('2020-01-01 01:11:00'), 90000001, '1200', '1500', DATE('2020-05-01')),"
                        + "('Sample Event 2','Sample Data Event 2', DATETIME('2020-02-01 14:02:00'), 90000001, '1200', '1500', DATE('2020-06-01')), "
                        + "('Sample Event 3','Sample Data Event 3', DATETIME('2020-02-01 14:02:00'), 90000001, '1200', '1500', DATE('2020-01-01')), "
                        + "('Sample Event 4','Sample Data Event 4', DATETIME('2020-03-01 03:33:00'), 90000001, '1200', '1500', DATE('2020-07-01'));");
                insertData.execute();
            } else {
                System.out.println("EVENT table exists");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static void createInvitationTable() {
        PreparedStatement createTable = null;
        PreparedStatement insertData = null;
        ResultSet rs = null;
        openConnection();
        try {
            System.out.println("Checking INVITATION table ");
            DatabaseMetaData dbmd = conn.getMetaData();
            rs = dbmd.getTables(null, null, "INVITATION", null);
            if (!rs.next()) {
                createTable = conn.prepareStatement("CREATE TABLE INVITATION ("
                        + "INVITATIONID INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + "EVENTID VARCHAR(255) NOT NULL, "
                        + "ADMINID INTEGER NOT NULL, "
                        + "GUESTID INTEGER NOT NULL, "
                        + "NOTE TEXT, "
                        + "INVITATION_EXPIRED_DATE TEXT NOT NULL, "
                        + "FOREIGN KEY(ADMINID) REFERENCES ADMIN_USER(ADMINID), "
                        + "FOREIGN KEY(GUESTID) REFERENCES GUEST_USER(GUESTID), "
                        + "FOREIGN KEY(EVENTID) REFERENCES EVENT(EVENTID));"
                );
                createTable.execute();
                System.out.println("INVITATION table created");
                insertData = conn.prepareStatement("INSERT INTO INVITATION(EVENTID, ADMINID, GUESTID, NOTE, INVITATION_EXPIRED_DATE) "
                        + "VALUES (1, 90000001, 10000001, 'Sample Note', DATE('2020-05-01')),"
                        + "(2, 90000001, 10000001, 'Sample Note2', DATE('2020-06-01')), "
                        + "(2, 90000001, 10000002, 'Invitation to Guest5678', DATE('2020-06-01')),"
                        + "(3, 90000001, 10000001, '', DATE('2020-01-01'));");
                insertData.execute();
            } else {
                System.out.println("INVITATION table exists");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static void createRSVPTable() {
        PreparedStatement createTable = null;
        PreparedStatement insertData = null;
        ResultSet rs = null;
        openConnection();
        try {
            System.out.println("Checking RSVP table ");
            DatabaseMetaData dbmd = conn.getMetaData();
            rs = dbmd.getTables(null, null, "RSVP", null);
            if (!rs.next()) {
                createTable = conn.prepareStatement("CREATE TABLE RSVP ("
                        + "RSVPID INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + "INVITATIONID INTEGER NOT NULL, "
                        + "DECISION TEXT, "
                        + "DIETARY_REQUIREMENTS TEXT, "
                        + "RSVP_DATE TEXT NOT NULL, "
                        + "FOREIGN KEY(INVITATIONID) REFERENCES INVITATION(INVITATIONID));"
                );
                createTable.execute();
                System.out.println("RSVP  table created");
                insertData = conn.prepareStatement("INSERT INTO RSVP(INVITATIONID, DECISION, DIETARY_REQUIREMENTS, RSVP_DATE) "
                        + "VALUES (1, 'Accept', 'Sample text', DATE('2020-05-31')), "
                        + "(2, 'Decline', 'Sample text', DATE('2020-05-31')), "
                        + "(3, 'Decline', NULL, DATE('2020-05-31'));");
                insertData.execute();
            } else {
                System.out.println("RSVP table exists");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    
    public static void createEventTimelineTable() {
        PreparedStatement createTable = null;
        PreparedStatement insertData = null;
        ResultSet rs = null;
        openConnection();
        try {
            System.out.println("Checking EVENT_TIMELINE table ");
            DatabaseMetaData dbmd = conn.getMetaData();
            rs = dbmd.getTables(null, null, "EVENT_TIMELINE", null);
            if (!rs.next()) {
                createTable = conn.prepareStatement("CREATE TABLE EVENT_TIMELINE ("
                        + "EVENT_TIMELINE_ID INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + "EVENTID INTEGER NOT NULL, "
                        + "EVENTDETAIL TEXT, "
                        + "FOREIGN KEY(EVENTID) REFERENCES EVENT(EVENTID));"
                );
                createTable.execute();
                System.out.println("EVENT_TIMELINE table created");
                insertData = conn.prepareStatement("INSERT INTO EVENT_TIMELINE(EVENTID, EVENTDETAIL) "
                        + "VALUES (1, '0000Testing;;;0015Testing2;;;'),"
                        + "(2, '0000Testing;;;0015Testing2;;;'), "
                        + "(3, '0000Testing;;;0015Testing2;;;');");
                insertData.execute();
            } else {
                System.out.println("EVENT_TIMELINE table exists");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}

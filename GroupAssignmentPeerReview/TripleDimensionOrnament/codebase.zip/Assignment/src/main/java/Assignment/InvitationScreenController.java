/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleLongProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author luluZ
 */
public class InvitationScreenController implements Initializable {

    @FXML
    private Button btnHome;
    @FXML
    private Button btnEvent;
    @FXML
    private Button btnInvitation;
    @FXML
    private Button btnAboutUs;
    @FXML
    private Button btnLogout;
    @FXML
    private Button btnProfile;

    @FXML
    private Button btnSearch;
    @FXML
    private Button btnReset;
    @FXML
    private Button btnNew;
    @FXML
    private Button btnUpdate;
    @FXML
    private Button btnDelete;

    @FXML
    private ComboBox searchType;

    @FXML
    private TextField searchText;

    @FXML
    private Text invitationIdField;
    @FXML
    private Text eventIdField;
    @FXML
    private Text eventNameField;
    @FXML
    private Text guestAccessCodeField;
    @FXML
    private Text guestNameField;
    @FXML
    private Text expiredDateField;
    @FXML
    private Text creatorIdField;
    @FXML
    private Text creatorNameField;
    @FXML
    private TextArea invitationNoteField;

    @FXML
    private TableView<InvitationInformation> invitationDataDisplay;
    @FXML
    private TableColumn invitationId;
    @FXML
    private TableColumn guestName;
    @FXML
    private TableColumn eventName;

    Database d = new Database();
    private String selectedId = "";
    private String getAllDataQuery = "SELECT INVITATIONID, EVENTID, GUESTID FROM INVITATION;";
    
    @FXML
    private void handleHomeButtonAction(ActionEvent event) throws IOException {
        App.setRoot("AdminHomeScreen");
    }

    @FXML
    private void handleEventButtonAction(ActionEvent event) throws IOException {
        App.setRoot("EventScreen");
    }

    @FXML
    private void handleInvitationButtonAction(ActionEvent event) throws IOException {
        App.setRoot("InvitationScreen");
    }

    @FXML
    private void handleAboutUsButtonAction(ActionEvent event) throws IOException {
        App.setRoot("AboutUsScreen");
    }

    @FXML
    private void handleProfileButtonAction(ActionEvent event) throws IOException {
        App.setRoot("ProfileScreen");
    }

    @FXML
    private void handleLogoutButtonAction(ActionEvent event) throws IOException {
        int logoutConfirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
        if (logoutConfirm == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(null, StaticResource.logoutMessage, "Logout Successful", JOptionPane.INFORMATION_MESSAGE);
            StaticResource.logoutClear();
            App.setRoot("LoginScreen");
        }
    }

    @FXML
    private void handleNewButtonAction(ActionEvent event) throws IOException {
        App.setRoot("CreateInvitationScreen");
    }

    @FXML
    private void handleDeleteButtonAction(ActionEvent event) throws IOException {
        int confirmDelete = JOptionPane.showConfirmDialog(null, "Comfirm to delete Invitation?", "Delete Invitation", JOptionPane.YES_NO_OPTION);

        if (confirmDelete == JOptionPane.YES_OPTION) {
            try {
                String deleteRecord = "DELETE FROM INVITATION WHERE INVITATIONID = '" + selectedId + "';";
                JOptionPane.showMessageDialog(null, "Invitation deleted!", "Successful Deleted", JOptionPane.INFORMATION_MESSAGE);
                Database.insertStatement(deleteRecord);
                getInvitationData(getAllDataQuery);
                clearSelected();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    private void handleUpdateButtonAction(ActionEvent event) throws IOException {
        int click = JOptionPane.showConfirmDialog(null, "Comfirm to update this Invitation?",
                "Update Event", JOptionPane.YES_NO_OPTION);
        if (click == JOptionPane.YES_OPTION) {
            try {
                String query = "UPDATE INVITATION SET "
                        + "NOTE = '" + invitationNoteField.getText().trim() + "' "
                        + "WHERE INVITATIONID = '" + selectedId + "';";
                JOptionPane.showMessageDialog(null, "Invitation updated!", "Successful Updated", JOptionPane.INFORMATION_MESSAGE);
                Database.insertStatement(query);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    private void handleSearchButtonAction(ActionEvent event) throws IOException {
        String searchTypeInput = searchType.getValue().toString();
        String query = "SELECT INVITATIONID, EVENTID, GUESTID FROM INVITATION WHERE ";
        String keyword = searchText.getText();
        boolean checker = false;

        if (keyword != null && !keyword.equals("")) {
            if (searchTypeInput.equals("Invitation Id")) {
                query += "INVITATIONID LIKE '%" + keyword + "%';";
                checker = true;
            } else if (searchTypeInput.equals("Event Id")) {
                query += "EVENTID LIKE '%" + keyword + "%';";
                checker = true;
            } else if (searchTypeInput.equals("Event Name")) {
                try {
                    ResultSet rs = d.getResultSet("SELECT EVENTID FROM EVENT WHERE EVENT_NAME LIKE '%" + keyword + "%';");
                    while (rs.next()) {
                        query += "EVENTID LIKE '%" + rs.getString(1) + "%' OR ";
                        checker = true;
                    }
                    query = query.substring(0, query.length() - 3) + ";";
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (searchTypeInput.equals("Guest Id")) {
                query += "GUESTID LIKE '%" + keyword + "%';";
                checker = true;
            } else if (searchTypeInput.equals("Guest Name")) {
                try {
                    ResultSet rs = d.getResultSet("SELECT GUESTID FROM GUEST_USER WHERE FIRSTNAME LIKE '%" + keyword + "%' OR LASTNAME LIKE '%" + keyword + "%';");
                    while (rs.next()) {
                        query += "GUESTID LIKE '%" + rs.getString(1) + "%' OR ";
                        checker = true;
                    }
                    query = query.substring(0, query.length() - 3) + ";";
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (searchTypeInput.equals("Creator Id")) {
                query += "ADMINID LIKE '%" + keyword + "%';";
                checker = true;
            } else if (searchTypeInput.equals("Creator Name")) {
                try {
                    ResultSet rs = d.getResultSet("SELECT ADMINID FROM ADMIN_USER WHERE FIRSTNAME LIKE '%" + keyword + "%' OR LASTNAME LIKE '%" + keyword + "%';");
                    while (rs.next()) {
                        query += "ADMINID LIKE '%" + rs.getString(1) + "%' OR ";
                        checker = true;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } else {
            checker = true;
            query = getAllDataQuery;
        }

        if(checker){
            getInvitationData(query);
        } else {
            JOptionPane.showMessageDialog(null, "No Invitation Found!", "Invitation Search", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    @FXML
    private void handleResetButtonAction(ActionEvent event) throws IOException {
        invitationDataDisplay.getItems().clear();
        getInvitationData(getAllDataQuery);
        searchText.clear();
        clearSelected();
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btnProfile.setText(StaticResource.currentUsername);
        StaticResource.currentPage = "InvitationScreen";
        btnInvitation.setStyle("-fx-text-fill: #FFFFFF;");

        clearSelected();

        searchType.getItems().addAll(
                "Invitation Id",
                "Event Id",
                "Event Name",
                "Guest Id",
                "Guest Name",
                "Creator Id",
                "Creator Name"
        );
        searchType.setValue("Invitation Id");

        invitationDataDisplay.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {

                if (event.isPrimaryButtonDown() && event.getClickCount() == 1) {
                    if (!invitationDataDisplay.getSelectionModel().isEmpty()) {
                        btnDelete.setVisible(true);
                        btnUpdate.setVisible(true);
                        invitationNoteField.setDisable(false);

                        selectedId = String.valueOf(invitationDataDisplay.getSelectionModel().getSelectedItem().getInvitationId());

                        try {
                            ResultSet rs = d.getResultSet("SELECT * FROM INVITATION WHERE INVITATIONID = '" + selectedId + "';");

                            invitationIdField.setText(rs.getString(1));
                            eventIdField.setText(rs.getString(2));
                            creatorIdField.setText(rs.getString(3));
                            invitationNoteField.setText(rs.getString(5));
                            expiredDateField.setText(rs.getString(6));
                            ResultSet tempRS = d.getResultSet("SELECT FIRSTNAME, LASTNAME, ACCESS_CODE FROM GUEST_USER WHERE GUESTID = '" + rs.getString(4) + "';");
                            while (tempRS.next()) {
                                guestAccessCodeField.setText(rs.getString(4) + ", " + tempRS.getString(3));
                                guestNameField.setText(tempRS.getString(1) + " " + tempRS.getString(2));
                            }

                            tempRS = d.getResultSet("SELECT FIRSTNAME, LASTNAME FROM ADMIN_USER WHERE ADMINID = '" + rs.getString(3) + "';");
                            while (tempRS.next()) {
                                creatorNameField.setText(tempRS.getString(1) + " " + tempRS.getString(2));
                            }

                            tempRS = d.getResultSet("SELECT EVENT_NAME FROM EVENT WHERE EVENTID = '" + rs.getString(2) + "';");
                            while (tempRS.next()) {
                                eventNameField.setText(tempRS.getString(1));
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });

        getInvitationData(getAllDataQuery);
    }

    public void clearSelected() {
        btnDelete.setVisible(false);
        btnUpdate.setVisible(false);
        invitationNoteField.setDisable(true);
        selectedId = "";
        invitationIdField.setText("");
        eventIdField.setText("");
        eventNameField.setText("");
        guestAccessCodeField.setText("");
        guestNameField.setText("");
        expiredDateField.setText("");
        creatorIdField.setText("");
        creatorNameField.setText("");
        invitationNoteField.setText("");
    }

    private void getInvitationData(String query) {
        ObservableList<InvitationInformation> dataList = FXCollections.observableArrayList();

        invitationId.setCellValueFactory(new PropertyValueFactory<InvitationInformation, String>("InvitationId"));
        guestName.setCellValueFactory(new PropertyValueFactory<InvitationInformation, String>("GuestName"));
        eventName.setCellValueFactory(new PropertyValueFactory<InvitationInformation, String>("EventName"));

        try {
            ResultSet rs = d.getResultSet(query);
            while (rs.next()) {
                InvitationInformation ii = new InvitationInformation();
                String tempGuest = rs.getString(3);
                String tempEvent = rs.getString(2);
                ii.setInvitationId(rs.getLong(1));

                ResultSet tempRS = d.getResultSet("SELECT FIRSTNAME, LASTNAME FROM GUEST_USER WHERE GUESTID = '" + tempGuest + "';");
                while (tempRS.next()) {
                    ii.setGuestName(tempRS.getString(1) + " " + tempRS.getString(2));
                }

                tempRS = d.getResultSet("SELECT EVENT_NAME FROM EVENT WHERE EVENTID = '" + tempEvent + "';");
                while (tempRS.next()) {
                    ii.setEventName(tempRS.getString(1));
                }

                dataList.add(ii);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (dataList.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No Invitation Found!", "Invitation Search", JOptionPane.INFORMATION_MESSAGE);
        } else {
            invitationId.setSortType(TableColumn.SortType.DESCENDING);
            invitationDataDisplay.setItems(dataList);
            invitationDataDisplay.getSortOrder().add(invitationId);
        }
    }

    public class InvitationInformation {

        public SimpleLongProperty invitationId = new SimpleLongProperty();
        public SimpleStringProperty eventName = new SimpleStringProperty();
        public SimpleStringProperty guestName = new SimpleStringProperty();

        public long getInvitationId() {
            return invitationId.get();
        }

        public void setInvitationId(long newInvitationId) {
            invitationId.set(newInvitationId);
        }

        public String getGuestName() {
            return guestName.get();
        }

        public void setGuestName(String newGuestName) {
            guestName.set(newGuestName);
        }

        public String getEventName() {
            return eventName.get();
        }

        public void setEventName(String newEventName) {
            eventName.set(newEventName);
        }
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.regex.Pattern;
import javafx.beans.property.SimpleLongProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;

/**
 * FXML Controller class
 *
 * @author poh_y
 */
public class ManageGuestScreenController implements Initializable {

    @FXML Button btnSearch;
    @FXML Button benReset;
    @FXML Button btnUpdate;
    @FXML Button btnBack;
    @FXML Button btnDelete;
    @FXML Button btnUnselect;
    
    @FXML ComboBox searchType;
    @FXML TextField searchText;
    
    @FXML Text guestIdField;
    @FXML TextField accessCodeField;
    @FXML Button btnPasswordReset;
    @FXML TextField firstNameField;
    @FXML TextField lastNameField;
    @FXML TextField emailField;
    @FXML TextField mobileNumberField;
    @FXML ComboBox genderField;
    @FXML DatePicker dobField;
    @FXML Text createdByField;
    @FXML Text createdDateField;
    
    @FXML
    private TableView<GuestInformation> guestDataDisplay;
    @FXML
    private TableColumn guestId;
    @FXML
    private TableColumn createdDate;
    @FXML
    private TableColumn guestName;
    @FXML
    private TableColumn guestEmail;
    
    Database d = new Database();
    
    public static long adminHomeSelected = -1;
    private long selectedId = -1;
    private String getAllDataQuery = "SELECT * FROM GUEST_USER;";
    
    @FXML
    private void handleSearchButtonAction(ActionEvent event) throws IOException {
        String searchTypeInput = searchType.getValue().toString();
        String keyword = searchText.getText().trim();
        String query = getAllDataQuery;
        
        if(keyword != null && !keyword.equals("")){
            if (searchTypeInput.equals("Id")) {
                query = "SELECT * FROM GUEST_USER WHERE GUESTID LIKE '%" + keyword + "%';";
            } else if (searchTypeInput.equals("Name")) {
                query = "SELECT * FROM GUEST_USER WHERE FIRSTNAME LIKE '%" + keyword + "%' OR LASTNAME LIKE '%" + keyword +"%';";
            } else if (searchTypeInput.equals("Email")) {       
                query = "SELECT * FROM GUEST_USER WHERE EMAIL LIKE '%" + keyword + "%';";
            } else if (searchTypeInput.equals("Mobile")) {
                query = "SELECT * FROM GUEST_USER WHERE MOBILENUMBER LIKE '%" + keyword + "%';";
            }
        }
        
        getGuestData(query);

    }

    @FXML
    private void handleResetButtonAction(ActionEvent event) throws IOException {
        clearSelected();
        clearHighlight();
        getGuestData(getAllDataQuery);
    }

    @FXML
    private void handleUpdateButtonAction(ActionEvent event) throws IOException {
        clearHighlight();
        if (checkInput() == null || checkInput().equals("")) {

            String fname = firstNameField.getText().trim();
            String lname = lastNameField.getText().trim();;
            String gender = genderField.getValue().toString();
            String mobile = mobileNumberField.getText().trim();
            String email = emailField.getText().trim();
            LocalDate dob = dobField.getValue();
            
            Random random = new Random();
            String randomNumber = String.format("%04d", random.nextInt(10000));
            String accessCode = fname.replaceAll("[^a-zA-Z0-9]", "") + lname.replaceAll("[^a-zA-Z0-9]", "") + randomNumber;

            String query = "";

            if (selectedId == -1) {
                try {
                    ResultSet rs = d.getResultSet("SELECT * FROM GUEST_USER WHERE "
                            + "ACCESS_CODE = '" + accessCode + "';");
                    
                    while (rs.next()) {
                        randomNumber = String.format("%04d", random.nextInt(10000));

                        accessCode = fname.replaceAll("[^a-zA-Z0-9]", "") + lname.replaceAll("[^a-zA-Z0-9]", "") + randomNumber;

                        rs = d.getResultSet("SELECT * FROM GUEST_USER WHERE "
                                + "ACCESS_CODE = '" + accessCode + "';");
                    }

                    if (!rs.next()) {
                        if (!rs.next()) {
                            rs = d.getResultSet("SELECT * FROM GUEST_USER WHERE "
                                    + "EMAIL = '" + email + "';");
                            if (!rs.next()) {
                                rs = d.getResultSet("SELECT * FROM GUEST_USER WHERE "
                                        + "MOBILENUMBER = '" + mobile + "';");
                                if (!rs.next()) {
                                    int click = JOptionPane.showConfirmDialog(null, "Comfirm to create new Guest?", "Create new Guest", JOptionPane.YES_NO_OPTION);

                                    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                                    Date date = new Date();
                                    String currentDateTime = dateFormat.format(date);

                                    if (click == JOptionPane.YES_OPTION) {
                                        String insertAccount = "INSERT INTO GUEST_USER(ACCESS_CODE, PASSWORD, FIRSTNAME, LASTNAME, GENDER, DATEOFBIRTH, MOBILENUMBER, EMAIL, CREATED_DATE, CREATED_BY) "
                                                + "VALUES ('" + accessCode + "', 'password', '" + fname + "', '" + lname + "', '" + gender + "', DATE('" + dob + "'), '" + mobile + "', '" + email + "', DATE('" + currentDateTime + "'), " + StaticResource.currentUserId + ");";

                                        JOptionPane.showMessageDialog(null, "Guest created!\nDeafault password: \"password\"", "Guest Created Successful", JOptionPane.INFORMATION_MESSAGE);
                                        Database.insertStatement(insertAccount);
                                    }
                                } else {
                                    JOptionPane.showMessageDialog(null, "*Mobile Number used! Please use other Mobile Number!", "Invalid Mobile Number", JOptionPane.INFORMATION_MESSAGE);
                                    mobileNumberField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
                                }
                            } else {
                                JOptionPane.showMessageDialog(null, "*Email used! Please use other email!", "Invalid Email", JOptionPane.INFORMATION_MESSAGE);
                                emailField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
                            }
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }            
            } else {

                int click = JOptionPane.showConfirmDialog(null, "Comfirm to update this Guest?",
                        "Update Guest", JOptionPane.YES_NO_OPTION);
                if (click == JOptionPane.YES_OPTION) {
                    try {
                        query = "UPDATE GUEST_USER SET "
                                + "FIRSTNAME = '" + fname + "', "
                                + "LASTNAME = '" + lname + "', "
                                + "DATEOFBIRTH = DATE('" + dob + "'), "
                                + "MOBILENUMBER = '" + mobile + "', "
                                + "GENDER = '" + gender + "', "
                                + "EMAIL = '" + email + "'"
                                + "WHERE GUSETID = " + selectedId + ";";
                        JOptionPane.showMessageDialog(null, "Guest updated!", "Successful Updated", JOptionPane.INFORMATION_MESSAGE);
                        Database.insertStatement(query);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
            
            clearSelected();
            getGuestData(getAllDataQuery);
        } else {
            JOptionPane.showMessageDialog(null, checkInput(), "Invalid Input", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    private String checkInput(){
        String errorMessage = "";
        
        String fname = firstNameField.getText().trim();
        String lname = lastNameField.getText().trim();;
        String mobile = mobileNumberField.getText().trim();
        String email = emailField.getText().trim();
        LocalDate dob = dobField.getValue();
        
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."
                + "[a-zA-Z0-9_+&*-]+)*@"
                + "(?:[a-zA-Z0-9-]+\\.)+[a-z"
                + "A-Z]{2,7}$";

        Pattern pat = Pattern.compile(emailRegex);
        
        LocalDate today = LocalDate.now();
        if (dob.isAfter(today)) {
            errorMessage += "*Invalid Date of Birth.Don't lie to me, you are not from future.\n\n";
            dobField.setStyle("-fx-border-color: red;");
        }
        
        if(email == null || email.equals("")){
            errorMessage += "*Email is Empty!\n\n";
            emailField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        } else if (!pat.matcher(email).matches()) {
            errorMessage += "*Invalid Email! Check your email format!\n\n";
            emailField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        }

        if(fname == null || fname.equals("")){
            errorMessage += "*First Name is Empty!\n\n";
            firstNameField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        } else if (fname.length() > 20) {
            errorMessage += "*Maximum 20 characters for First Name!!\n\n";
            firstNameField.setStyle("-fx-border-color: red; -fx-border-width:2px;");;
        }

        if(lname == null || lname.equals("")){
            errorMessage += "*Last Name is Empty!\n\n";
            lastNameField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        } else if (lname.length() > 20) {
            errorMessage += "*Maximum 20 characters for Last Name!!\n\n";
            lastNameField.setStyle("-fx-border-color: red; -fx-border-width:2px;");;
        }

        if(mobile == null || mobile.equals("")){
            errorMessage += "*Mobile Number is Empty!\n\n";
            mobileNumberField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        } else if (!mobile.matches("[0-9]+") || mobile.length() < 10 || mobile.length() > 10 || !mobile.substring(0, 2).equals("04")) {
            errorMessage += "*Invalid mobile number! Please insert Australia mobile number!!\n\n";
            mobileNumberField.setStyle("-fx-border-color: red; -fx-border-width:2px;");;
        }
        
        return errorMessage;
    }

    @FXML
    private void handleBackButtonAction(ActionEvent event) throws IOException {
        App.setRoot(StaticResource.currentPage);
    }

    @FXML
    private void handleDeleteButtonAction(ActionEvent event) throws IOException {
        if(StaticResource.currentUserId.equals(String.valueOf(selectedId))){
            JOptionPane.showMessageDialog(null, "You can't delete Your Account!!", "Error", JOptionPane.INFORMATION_MESSAGE);
        } else {
            int confirmDelete = JOptionPane.showConfirmDialog(null, "Comfirm to delete user?", "Delete User", JOptionPane.YES_NO_OPTION);
            
            if (confirmDelete == JOptionPane.YES_OPTION) {
                try {
                    String deleteRecord = "DELETE FROM GUEST_USER WHERE GUESTID = " + selectedId + ";";
                    JOptionPane.showMessageDialog(null, "User deleted!", "Successful Deleted", JOptionPane.INFORMATION_MESSAGE);
                    Database.insertStatement(deleteRecord);
                    getGuestData(getAllDataQuery);
                    clearSelected();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @FXML
    private void handleUnselectButtonAction(ActionEvent event) throws IOException {
        clearSelected();
        clearHighlight();
    }

    @FXML
    private void handlePasswordResetButtonAction(ActionEvent event) throws IOException {
        JPasswordField adminPassword = new JPasswordField();
        JPasswordField newPassword = new JPasswordField();
        JPasswordField reEnterNewPassword = new JPasswordField();

        Object[] passwordFields = {
            "Your Password", adminPassword,
            "Reset Password", newPassword,
            "Re-enter Reset Password", reEnterNewPassword
        };

        int confirmation = JOptionPane.showConfirmDialog(null, passwordFields, "Reset Password", JOptionPane.OK_CANCEL_OPTION);

        if (confirmation == JOptionPane.YES_OPTION) {
            String aPass = adminPassword.getText();
            String nPass = newPassword.getText();
            String rnPass = reEnterNewPassword.getText();

            if (!aPass.equals(StaticResource.currentUserPassword)) {
                JOptionPane.showMessageDialog(null, "Password Incorrect", "Invalid Password", JOptionPane.OK_CANCEL_OPTION);
            } else {
                String errorMessage = "";
                errorMessage = StaticResource.passwordCheck(nPass, rnPass);

                if (errorMessage.equals("")) {
                    
                    String updateDetail = "UPDATE GUEST_USER SET PASSWORD = '" + nPass + "' WHERE GUESTID = " + selectedId + ";";

                    try {
                        Database.insertStatement(updateDetail);
                        JOptionPane.showMessageDialog(null, "Password Reset Successful !!", "Update Success", JOptionPane.OK_CANCEL_OPTION);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, errorMessage, "Invalid Password", JOptionPane.OK_CANCEL_OPTION);
                }
            }
        }
    }

    private void clearHighlight() {
        accessCodeField.setStyle("-fx-border-color: transparent;");
        firstNameField.setStyle("-fx-border-color: transparent;");
        lastNameField.setStyle("-fx-border-color: transparent;");
        emailField.setStyle("-fx-border-color: transparent;");
        mobileNumberField.setStyle("-fx-border-color: transparent;");
        dobField.setStyle("-fx-border-color: transparent;");
    }
    
    public void clearSelected(){
        btnDelete.setVisible(false);
        btnPasswordReset.setDisable(true);
        clearHighlight();
        selectedId = -1;
        btnUpdate.setText("SUBMIT");
        guestIdField.setText("");
        createdDateField.setText("");
        createdByField.setText("");
        accessCodeField.clear();
        firstNameField.clear();
        lastNameField.clear();
        genderField.setValue("Male");
        dobField.setValue(LocalDate.now());
        mobileNumberField.clear();
        emailField.clear();
        accessCodeField.setEditable(true);
        accessCodeField.setMouseTransparent(false);
    }
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        clearSelected();
        
        searchType.getItems().addAll(
                "Id", "Name", "Email", "Mobile"
        );
        searchType.setValue("Id");
        
        genderField.getItems().addAll(
                "Male", "Female", "Not Specified"
        );
        genderField.setValue("Male");
        
        if(adminHomeSelected != -1){
            getGuestData("SELECT * FROM GUEST_USER WHERE GUESTID = '" + adminHomeSelected + "';");
        } else {
            getGuestData(getAllDataQuery);
        }
        
        guestDataDisplay.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {

                if (event.isPrimaryButtonDown() && event.getClickCount() == 1) {
                    if (!guestDataDisplay.getSelectionModel().isEmpty()) {
                        clearSelected();

                        btnDelete.setVisible(true);
                        btnUpdate.setText("UPDATE");
                        btnPasswordReset.setDisable(false);
                        btnUpdate.setText("UPDATE");
                        accessCodeField.setEditable(false);
                        accessCodeField.setMouseTransparent(true);

                        selectedId = guestDataDisplay.getSelectionModel().getSelectedItem().getGuestId();

                        try {
                            ResultSet rs = d.getResultSet("SELECT * FROM GUEST_USER  "
                                    + "WHERE GUESTID = " + selectedId + ";");

                            guestIdField.setText(rs.getString(1));
                            accessCodeField.setText(rs.getString(2));
                            firstNameField.setText(rs.getString(4));
                            lastNameField.setText(rs.getString(5));
                            genderField.setValue(rs.getString(6));
                            dobField.setValue(LocalDate.parse(rs.getString(7)));
                            mobileNumberField.setText(rs.getString(8));
                            emailField.setText(rs.getString(9));
                            createdDateField.setText(rs.getString(10));
                            if (!rs.getString(11).equals("-1")) {
                                createdByField.setText(rs.getString(11));
                            } else {
                                createdByField.setText("Self-Created");
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });
    }    
    
    public void getGuestData(String query) {
        ObservableList<GuestInformation> dataList = FXCollections.observableArrayList();

        guestId.setCellValueFactory(new PropertyValueFactory<GuestInformation, String>("GuestId"));
        guestName.setCellValueFactory(new PropertyValueFactory<GuestInformation, String>("GuestName"));
        guestEmail.setCellValueFactory(new PropertyValueFactory<GuestInformation, String>("GuestEmail"));
        createdDate.setCellValueFactory(new PropertyValueFactory<GuestInformation, String>("CreatedDate"));

        try {
            ResultSet rs = d.getResultSet(query);
            while (rs.next()) {
                GuestInformation gi = new GuestInformation();
                gi.setGuestId(rs.getLong(1));
                gi.setCreatedDate(rs.getString(10));
                gi.setGuestName(rs.getString(4) + " " + rs.getString(5));
                gi.setGuestEmail(rs.getString(9));

                dataList.add(gi);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (dataList.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No Guest Found!", "Guest Search", JOptionPane.INFORMATION_MESSAGE);
        } else {
            guestId.setSortType(TableColumn.SortType.DESCENDING);
            guestDataDisplay.setItems(dataList);
            guestDataDisplay.getSortOrder().add(guestId);
        }
        
        if (adminHomeSelected != -1) {
            guestDataDisplay.getSelectionModel().selectFirst();

            clearSelected();

            btnDelete.setVisible(true);
            btnUpdate.setText("UPDATE");
            btnPasswordReset.setDisable(false);
            btnUpdate.setText("UPDATE");
            accessCodeField.setEditable(false);
            accessCodeField.setMouseTransparent(true);

            selectedId = guestDataDisplay.getSelectionModel().getSelectedItem().getGuestId();

            try {
                ResultSet rs = d.getResultSet("SELECT * FROM GUEST_USER  "
                        + "WHERE GUESTID = " + selectedId + ";");

                guestIdField.setText(rs.getString(1));
                accessCodeField.setText(rs.getString(2));
                firstNameField.setText(rs.getString(4));
                lastNameField.setText(rs.getString(5));
                genderField.setValue(rs.getString(6));
                dobField.setValue(LocalDate.parse(rs.getString(7)));
                mobileNumberField.setText(rs.getString(8));
                emailField.setText(rs.getString(9));
                createdDateField.setText(rs.getString(10));
                if (!rs.getString(11).equals("-1")) {
                    createdByField.setText(rs.getString(11));
                } else {
                    createdByField.setText("Self-Created");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        
            adminHomeSelected = -1;
        }
    }
    
    public class GuestInformation {

        public SimpleLongProperty guestId = new SimpleLongProperty();
        public SimpleStringProperty guestName = new SimpleStringProperty();
        public SimpleStringProperty guestEmail = new SimpleStringProperty();
        public SimpleStringProperty createdDate = new SimpleStringProperty();

        public long getGuestId() {
            return guestId.get();
        }

        public void setGuestId(long newGuestId) {
            guestId.set(newGuestId);
        }

        public String getGuestName() {
            return guestName.get();
        }

        public void setGuestName(String newGuestName) {
            guestName.set(newGuestName);
        }
        
        public String getGuestEmail() {
            return guestEmail.get();
        }

        public void setGuestEmail(String newGuestEmail) {
            guestEmail.set(newGuestEmail);
        }
        
        public String getCreatedDate() {
            return createdDate.get();
        }

        public void setCreatedDate(String newCreatedDate) {
            createdDate.set(newCreatedDate);
        }
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.regex.Pattern;
import javafx.beans.property.SimpleLongProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.scene.control.DatePicker;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * FXML Controller class
 *
 * @author poh_y
 */
public class ManageAdminScreenController implements Initializable {

    @FXML private Button btnSearch;
    @FXML private Button benReset;
    @FXML private Button btnUpdate;
    @FXML private Button btnBack;
    @FXML private Button btnDelete;
    @FXML private Button btnUnselect;
    
    @FXML private ComboBox searchType;
    @FXML private TextField searchText;
    
    @FXML private Text adminIdField;
    @FXML private TextField usernameField;
    @FXML private Button btnPasswordReset;
    @FXML private TextField firstNameField;
    @FXML private TextField lastNameField;
    @FXML private TextField emailField;
    @FXML private TextField mobileNumberField;
    @FXML private ComboBox genderField;
    @FXML private DatePicker dobField;
    @FXML Text createdByField;
    @FXML Text createdDateField;
    
    @FXML
    private TableView<AdminInformation> adminDataDisplay;
    @FXML
    private TableColumn adminId;
    @FXML
    private TableColumn adminUsername;
    @FXML
    private TableColumn adminName;
    @FXML
    private TableColumn adminEmail;
    
    Database d = new Database();
    
    private long selectedId = -1;
    private String getAllDataQuery = "SELECT * FROM ADMIN_USER;";
    
    @FXML
    private void handleSearchButtonAction(ActionEvent event) throws IOException {
        
        String searchTypeInput = searchType.getValue().toString();
        String keyword = searchText.getText().trim();
        String query = getAllDataQuery;
        
        if(keyword != null && !keyword.equals("")){
            if (searchTypeInput.equals("Id")) {
                query = "SELECT * FROM ADMIN_USER WHERE ADMINID LIKE '%" + keyword + "%';";
            } else if (searchTypeInput.equals("Username")) {
                query = "SELECT * FROM ADMIN_USER WHERE USERNAME LIKE '%" + keyword + "%';";
            } else if (searchTypeInput.equals("Name")) {
                query = "SELECT * FROM ADMIN_USER WHERE FIRSTNAME LIKE '%" + keyword + "%' OR LASTNAME LIKE '%" + keyword +"%';";
            } else if (searchTypeInput.equals("Email")) {       
                query = "SELECT * FROM ADMIN_USER WHERE EMAIL LIKE '%" + keyword + "%';";
            } else if (searchTypeInput.equals("Mobile")) {
                query = "SELECT * FROM ADMIN_USER WHERE MOBILENUMBER LIKE '%" + keyword + "%';";
            }
        }
        
        getAdminData(query);
    }

    @FXML
    private void handleResetButtonAction(ActionEvent event) throws IOException {
        clearSelected();
        clearHighlight();
        getAdminData(getAllDataQuery);
    }

    @FXML
    private void handleUpdateButtonAction(ActionEvent event) throws IOException {
        clearHighlight();
        if (checkInput() == null || checkInput().equals("")) {
            
            String username = usernameField.getText().trim();
            String fname = firstNameField.getText().trim();
            String lname = lastNameField.getText().trim();;
            String gender = genderField.getValue().toString();
            String mobile = mobileNumberField.getText().trim();
            String email = emailField.getText().trim();
            LocalDate dob = dobField.getValue();
            
            String query = "";

            if (selectedId == -1) {
                boolean validCheck = true;

                try {
                    ResultSet rs = d.getResultSet("SELECT * FROM ADMIN_USER WHERE "
                            + "USERNAME = '" + username + "';");

                    if (!rs.next()) {
                        if (!rs.next()) {
                            rs = d.getResultSet("SELECT * FROM ADMIN_USER WHERE "
                                    + "EMAIL = '" + email + "';");
                            if (!rs.next()) {
                                rs = d.getResultSet("SELECT * FROM ADMIN_USER WHERE "
                                        + "MOBILENUMBER = '" + mobile + "';");
                                if (!rs.next()) {
                                    int click = JOptionPane.showConfirmDialog(null, "Comfirm to create new Admin?", "Create new Admin", JOptionPane.YES_NO_OPTION);

                                    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                                    Date date = new Date();
                                    String currentDateTime = dateFormat.format(date);

                                    if (click == JOptionPane.YES_OPTION) {
                                        String insertAccount = "INSERT INTO ADMIN_USER(USERNAME, PASSWORD, FIRSTNAME, LASTNAME, GENDER, DATEOFBIRTH, MOBILENUMBER, EMAIL, CREATED_DATE, CREATED_BY) "
                                                + "VALUES ('" + username + "', 'admin', '" + fname + "', '" + lname + "', '" + gender + "', DATE('" + dob + "'), '" + mobile + "', '" + email + "', DATE('" + currentDateTime + "'), " + StaticResource.currentUserId + ");";

                                        JOptionPane.showMessageDialog(null, "Admin created!\nDeafault password: \"admin\"", "Admin Created Successful", JOptionPane.INFORMATION_MESSAGE);
                                        Database.insertStatement(insertAccount);
                                    }
                                } else {
                                    JOptionPane.showMessageDialog(null, "*Mobile Number used! Please use other Mobile Number!", "Invalid Mobile Number", JOptionPane.INFORMATION_MESSAGE);
                                    mobileNumberField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
                                }
                            } else {
                                JOptionPane.showMessageDialog(null, "*Email used! Please use other email!", "Invalid Email", JOptionPane.INFORMATION_MESSAGE);
                                emailField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
                            }
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "*Username used! Please use other Username!", "Invalid Username", JOptionPane.INFORMATION_MESSAGE);
                        usernameField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }            
            } else {

                int click = JOptionPane.showConfirmDialog(null, "Comfirm to update this Admin?",
                        "Update Admin", JOptionPane.YES_NO_OPTION);
                if (click == JOptionPane.YES_OPTION) {
                    try {
                        query = "UPDATE ADMIN_USER SET "
                                + "FIRSTNAME = '" + fname + "', "
                                + "LASTNAME = '" + lname + "', "
                                + "DATEOFBIRTH = DATE('" + dob + "'), "
                                + "MOBILENUMBER = '" + mobile + "', "
                                + "GENDER = '" + gender + "', "
                                + "EMAIL = '" + email + "'"
                                + "WHERE ADMINID = " + selectedId + ";";
                        JOptionPane.showMessageDialog(null, "Admin updated!", "Successful Updated", JOptionPane.INFORMATION_MESSAGE);
                        Database.insertStatement(query);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
            
            clearSelected();
            getAdminData(getAllDataQuery);
        } else {
            JOptionPane.showMessageDialog(null, checkInput(), "Invalid Input", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    private String checkInput(){
        String errorMessage = "";
        
        String username = usernameField.getText();
        String fname = firstNameField.getText().trim();
        String lname = lastNameField.getText().trim();;
        String mobile = mobileNumberField.getText().trim();
        String email = emailField.getText().trim();
        LocalDate dob = dobField.getValue();
        
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."
                + "[a-zA-Z0-9_+&*-]+)*@"
                + "(?:[a-zA-Z0-9-]+\\.)+[a-z"
                + "A-Z]{2,7}$";

        Pattern pat = Pattern.compile(emailRegex);
        
        LocalDate today = LocalDate.now();
        if (dob.isAfter(today)) {
            errorMessage += "*Invalid Date of Birth.Don't lie to me, you are not from future.\n\n";
            dobField.setStyle("-fx-border-color: red;");
        }

        if(username == null || username.equals("")){
            errorMessage += "*Username is Empty!\n\n";
            usernameField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        } else if (username.length() < 5) {
            errorMessage += "*Invalid Username! Minimum 5 Characters required!\n\n";
            usernameField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        }
        
        if(email == null || email.equals("")){
            errorMessage += "*Email is Empty!\n\n";
            emailField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        } else if (!pat.matcher(email).matches()) {
            errorMessage += "*Invalid Email! Check your email format!\n\n";
            emailField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        }

        if(fname == null || fname.equals("")){
            errorMessage += "*First Name is Empty!\n\n";
            firstNameField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        } else if (fname.length() > 20) {
            errorMessage += "*Maximum 20 characters for First Name!!\n\n";
            firstNameField.setStyle("-fx-border-color: red; -fx-border-width:2px;");;
        }

        if(lname == null || lname.equals("")){
            errorMessage += "*Last Name is Empty!\n\n";
            lastNameField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        } else if (lname.length() > 20) {
            errorMessage += "*Maximum 20 characters for Last Name!!\n\n";
            lastNameField.setStyle("-fx-border-color: red; -fx-border-width:2px;");;
        }

        if(mobile == null || mobile.equals("")){
            errorMessage += "*Mobile Number is Empty!\n\n";
            mobileNumberField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        } else if (!mobile.matches("[0-9]+") || mobile.length() < 10 || mobile.length() > 10 || !mobile.substring(0, 2).equals("04")) {
            errorMessage += "*Invalid mobile number! Please insert Australia mobile number!!\n\n";
            mobileNumberField.setStyle("-fx-border-color: red; -fx-border-width:2px;");;
        }
        
        return errorMessage;
    }
    
    private void clearHighlight() {
        usernameField.setStyle("-fx-border-color: transparent;");
        firstNameField.setStyle("-fx-border-color: transparent;");
        lastNameField.setStyle("-fx-border-color: transparent;");
        emailField.setStyle("-fx-border-color: transparent;");
        mobileNumberField.setStyle("-fx-border-color: transparent;");
        dobField.setStyle("-fx-border-color: transparent;");
    }

    @FXML
    private void handleBackButtonAction(ActionEvent event) throws IOException {
        App.setRoot(StaticResource.currentPage);
    }

    @FXML
    private void handleDeleteButtonAction(ActionEvent event) throws IOException {
        if(StaticResource.currentUserId.equals(String.valueOf(selectedId))){
            JOptionPane.showMessageDialog(null, "You can't delete Your Account!!", "Error", JOptionPane.INFORMATION_MESSAGE);
        } else {
            int confirmDelete = JOptionPane.showConfirmDialog(null, "Comfirm to delete user?", "Delete User", JOptionPane.YES_NO_OPTION);
            
            if (confirmDelete == JOptionPane.YES_OPTION) {
                try {
                    String deleteRecord = "DELETE FROM ADMIN_USER WHERE ADMINID = " + selectedId + ";";
                    JOptionPane.showMessageDialog(null, "User deleted!", "Successful Deleted", JOptionPane.INFORMATION_MESSAGE);
                    Database.insertStatement(deleteRecord);
                    getAdminData(getAllDataQuery);
                    clearSelected();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @FXML
    private void handleUnselectButtonAction(ActionEvent event) throws IOException {
        clearSelected();
        clearHighlight();
    }

    @FXML
    private void handlePasswordResetButtonAction(ActionEvent event) throws IOException {
        JPasswordField adminPassword = new JPasswordField();
        JPasswordField newPassword = new JPasswordField();
        JPasswordField reEnterNewPassword = new JPasswordField();

        Object[] passwordFields = {
            "Your Password", adminPassword,
            "Reset Password", newPassword,
            "Re-enter Reset Password", reEnterNewPassword
        };

        int confirmation = JOptionPane.showConfirmDialog(null, passwordFields, "Reset Password", JOptionPane.OK_CANCEL_OPTION);

        if (confirmation == JOptionPane.YES_OPTION) {
            String aPass = adminPassword.getText();
            String nPass = newPassword.getText();
            String rnPass = reEnterNewPassword.getText();

            if (!aPass.equals(StaticResource.currentUserPassword)) {
                JOptionPane.showMessageDialog(null, "Password Incorrect", "Invalid Password", JOptionPane.OK_CANCEL_OPTION);
            } else {
                String errorMessage = "";
                errorMessage = StaticResource.passwordCheck(nPass, rnPass);

                if (errorMessage.equals("")) {
                    
                    String updateDetail = "UPDATE ADMIN_USER SET PASSWORD = '" + nPass + "' WHERE ADMINID = " + selectedId + ";";

                    try {
                        Database.insertStatement(updateDetail);
                        JOptionPane.showMessageDialog(null, "Password Reset Successful !!", "Update Success", JOptionPane.OK_CANCEL_OPTION);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, errorMessage, "Invalid Password", JOptionPane.OK_CANCEL_OPTION);
                }
            }
        }
    }
    
    public void clearSelected(){
        btnDelete.setVisible(false);
        btnPasswordReset.setDisable(true);
        clearHighlight();
        selectedId = -1;
        btnUpdate.setText("SUBMIT");
        adminIdField.setText("");
        createdDateField.setText("");
        createdByField.setText("");
        usernameField.clear();
        firstNameField.clear();
        lastNameField.clear();
        genderField.setValue("Male");
        dobField.setValue(LocalDate.now());
        mobileNumberField.clear();
        emailField.clear();
        usernameField.setEditable(true);
        usernameField.setMouseTransparent(false);
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        clearSelected();
        
        searchType.getItems().addAll(
                "Id", "Username","Name", "Email", "Mobile"
        );
        searchType.setValue("Id");
        
        genderField.getItems().addAll(
                "Male", "Female", "Not Specified"
        );
        genderField.setValue("Male");
        
        getAdminData(getAllDataQuery);
    
        adminDataDisplay.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {

                if (event.isPrimaryButtonDown() && event.getClickCount() == 1) {
                    if (!adminDataDisplay.getSelectionModel().isEmpty()) {
                        clearSelected();

                        btnDelete.setVisible(true);
                        btnUpdate.setText("UPDATE");
                        btnPasswordReset.setDisable(false);
                        btnUpdate.setText("UPDATE");
                        usernameField.setEditable(false);
                        usernameField.setMouseTransparent(true);

                        selectedId = adminDataDisplay.getSelectionModel().getSelectedItem().getAdminId();

                        try {
                            ResultSet rs = d.getResultSet("SELECT * FROM ADMIN_USER  "
                                    + "WHERE ADMINID = " + selectedId + ";");

                            adminIdField.setText(rs.getString(1));
                            usernameField.setText(rs.getString(2));
                            firstNameField.setText(rs.getString(4));
                            lastNameField.setText(rs.getString(5));
                            genderField.setValue(rs.getString(6));
                            dobField.setValue(LocalDate.parse(rs.getString(7)));
                            mobileNumberField.setText(rs.getString(8));
                            emailField.setText(rs.getString(9));
                            createdDateField.setText(rs.getString(10));
                            createdByField.setText(rs.getString(11));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });
    }

    public void getAdminData(String query) {
        ObservableList<AdminInformation> dataList = FXCollections.observableArrayList();

        adminId.setCellValueFactory(new PropertyValueFactory<AdminInformation, String>("AdminId"));
        adminName.setCellValueFactory(new PropertyValueFactory<AdminInformation, String>("AdminName"));
        adminUsername.setCellValueFactory(new PropertyValueFactory<AdminInformation, String>("AdminUsername"));
        adminEmail.setCellValueFactory(new PropertyValueFactory<AdminInformation, String>("AdminEmail"));

        try {
            ResultSet rs = d.getResultSet(query);
            while (rs.next()) {
                AdminInformation ai = new AdminInformation();
                ai.setAdminId(rs.getLong(1));
                ai.setAdminUsername(rs.getString(2));
                ai.setAdminName(rs.getString(4) + " " + rs.getString(5));
                ai.setAdminEmail(rs.getString(9));

                dataList.add(ai);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (dataList.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No Admin Found!", "Admin Search", JOptionPane.INFORMATION_MESSAGE);
        } else {
            adminId.setSortType(TableColumn.SortType.DESCENDING);
            adminDataDisplay.setItems(dataList);
            adminDataDisplay.getSortOrder().add(adminId);
        }
    }
    
    public class AdminInformation {

        public SimpleLongProperty adminId = new SimpleLongProperty();
        public SimpleStringProperty adminName = new SimpleStringProperty();
        public SimpleStringProperty adminUsername = new SimpleStringProperty();
        public SimpleStringProperty adminEmail = new SimpleStringProperty();

        public long getAdminId() {
            return adminId.get();
        }

        public void setAdminId(long newAdminId) {
            adminId.set(newAdminId);
        }

        public String getAdminName() {
            return adminName.get();
        }

        public void setAdminName(String newAdminName) {
            adminName.set(newAdminName);
        }

        public String getAdminUsername() {
            return adminUsername.get();
        }

        public void setAdminUsername(String newAdminUsername) {
            adminUsername.set(newAdminUsername);
        }
        
        public String getAdminEmail() {
            return adminEmail.get();
        }

        public void setAdminEmail(String newAdminEmail) {
            adminEmail.set(newAdminEmail);
        }
    }
}

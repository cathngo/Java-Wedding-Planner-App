/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.text.Text;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author luluZ
 */
public class LoginScreenController {

    @FXML
    private TextField inputUsername;

    @FXML
    private PasswordField inputPassword;
    
    @FXML private Text usernameLabel;
    
    @FXML
    private Button btnLogin;
    
    @FXML
    private Button btnRegister;
    
    @FXML
    private RadioButton btnAdmin;
    
    @FXML
    private RadioButton btnGuest;
    
    @FXML
    private ToggleGroup userType;
    
    @FXML private Text textMonth;
    @FXML private Text textDay;
    @FXML private Text textDate;
    
    Calendar cal = Calendar.getInstance();
    
    Database d = new Database();
    

    @FXML
    private void handleLoginButtonAction(ActionEvent event) throws SQLException, IOException {
        String user = inputUsername.getText().trim();
        String password = inputPassword.getText();
        
        RadioButton selectedUserType = (RadioButton) userType.getSelectedToggle();
        String toggleGroupValue = selectedUserType.getText();
        
        String pageToSwitch = "";
        ResultSet rs = null;
        
        if(toggleGroupValue.equals("Admin")){
            pageToSwitch = "AdminHomeScreen";
            rs = d.getResultSet("SELECT * FROM ADMIN_USER WHERE "
                    + "USERNAME = '" + user + "' "
                    + "AND PASSWORD = '" + password + "'");
        } else {
            pageToSwitch = "GuestHomeScreen";
            rs = d.getResultSet("SELECT * FROM GUEST_USER WHERE "
                    + "ACCESS_CODE = '" + user + "' "
                    + "AND PASSWORD = '" + password + "'");
        }
        
        if (!rs.next()) {
            JOptionPane.showMessageDialog(null, "Invalid Username or Password.", "Login Failed", JOptionPane.INFORMATION_MESSAGE);
        } else {
            StaticResource.currentUserId = rs.getString(1);
            StaticResource.currentUserPassword = rs.getString(3);
            StaticResource.currentUsername = rs.getString(4) + " " + rs.getString(5);
            StaticResource.currentUserType = toggleGroupValue;
            JOptionPane.showMessageDialog(null, "Hi, " + rs.getString(4) + ", Welcome back!", "Login Successful", JOptionPane.INFORMATION_MESSAGE);
            App.setRoot(pageToSwitch);
        }
        rs.close();
    }
    
    @FXML
    private void handleRegisterButtonAction(ActionEvent event) throws IOException {
        App.setRoot("RegisterScreen");        
    }
    
    @FXML
    private void handleAboutUsAction(ActionEvent event) throws IOException {
        App.setRoot("AboutUsScreen");
    }
    
    @FXML
    private void handleAdminRadioAction(ActionEvent event) throws IOException {
        usernameLabel.setText("Username");
    }
    
    @FXML
    private void handleGuestRadioAction(ActionEvent event) throws IOException {
        usernameLabel.setText("Access Code");
    }
    
    @FXML
    public void initialize() {
       textMonth.setText(new SimpleDateFormat("MMMMM").format(cal.getTime()));
       textDay.setText(new SimpleDateFormat("EEEEE").format(cal.getTime()));
       textDate.setText(new SimpleDateFormat("dd").format(cal.getTime()));
       StaticResource.currentPage = "LoginScreen";
    }
}

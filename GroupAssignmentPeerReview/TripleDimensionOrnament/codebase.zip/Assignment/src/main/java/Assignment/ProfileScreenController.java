/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment;

import static Assignment.StaticResource.currentUsername;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import java.util.regex.Pattern;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 * FXML Controller class
 *
 * @author luluZ
 */
public class ProfileScreenController implements Initializable {

    @FXML
    Text accesscodeLabel;
    @FXML Text idField;
    
    @FXML
    Text greetingField;
    @FXML
    Text accessCodeField;
    @FXML
    Text userTypeField;
    @FXML
    Text dateOfBirthField;
    @FXML
    Text createdByField;
    @FXML
    Text createdDateField;

    @FXML
    TextField firstNameField;
    @FXML
    TextField lastNameField;
    @FXML
    TextField emailField;
    @FXML
    TextField mobileNumberField;

    @FXML
    ComboBox genderField;

    @FXML
    Button btnUpdate;
    @FXML
    Button btnBack;
    @FXML Button btnLogout;

    @FXML
    Button btnPasswordChange;

    Database d = new Database();

    private String userPassword = "";
    private String userType = StaticResource.currentUserType;
    private String userID = StaticResource.currentUserId;

    @FXML
    private void handleUpdateButtonAction(ActionEvent event) throws IOException {

        // String pword = passwordField.getText();
        String fname = firstNameField.getText().trim();
        String lname = lastNameField.getText().trim();
        String gder = genderField.getValue().toString();
        String mobile = mobileNumberField.getText().trim();
        String email = emailField.getText().trim();

        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."
                + "[a-zA-Z0-9_+&*-]+)*@"
                + "(?:[a-zA-Z0-9-]+\\.)+[a-z"
                + "A-Z]{2,7}$";

        Pattern pat = Pattern.compile(emailRegex);

        String errorMessage = "";

        if(fname == null || fname.equals("")){
            errorMessage += "*First Name is Empty!\n\n";
            firstNameField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        } else if (fname.length() > 20) {
            errorMessage += "*Maximum 20 characters for First Name!!\n\n";
            firstNameField.setStyle("-fx-border-color: red; -fx-border-width:2px;");;
        }
        
        if(email == null || email.equals("")){
            errorMessage += "*Email is Empty!\n\n";
            emailField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        } else if (!pat.matcher(email).matches()) {
            errorMessage += "*Invalid Email! Check your email format!\n\n";
            emailField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        }

        if(lname == null || lname.equals("")){
            errorMessage += "*Last Name is Empty!\n\n";
            lastNameField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        } else if (lname.length() > 20) {
            errorMessage += "*Maximum 20 characters for Last Name!!\n\n";
            lastNameField.setStyle("-fx-border-color: red; -fx-border-width:2px;");;
        }

        if(mobile == null || mobile.equals("")){
            errorMessage += "*Mobile Number is Empty!\n\n";
            mobileNumberField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        } else if (!mobile.matches("[0-9]+") || mobile.length() < 10 || mobile.length() > 10 || !mobile.substring(0, 2).equals("04")) {
            errorMessage += "*Invalid mobile number! Please insert Australia mobile number!!\n\n";
            mobileNumberField.setStyle("-fx-border-color: red; -fx-border-width:2px;");;
        }

        if (errorMessage.equals("")) {

            String updateDetail = "FIRSTNAME = '" + fname + "', "
                    + "LASTNAME = '" + lname + "', "
                    + "GENDER = '" + gder + "', "
                    + "MOBILENUMBER = '" + mobile + "', "
                    + "EMAIL = '" + email + "' ";

            int confirmUpdate = JOptionPane.showConfirmDialog(null, "Comfirm to update record?", "Update record", JOptionPane.YES_NO_OPTION);

            if (confirmUpdate == JOptionPane.YES_OPTION) {
                if (userType.equals("Admin")) {
                    updateDetail = "UPDATE ADMIN_USER SET " + updateDetail + "WHERE ADMINID = " + userID + ";";
                } else if (userType.equals("Guest")) {
                    updateDetail = "UPDATE GUEST_USER SET " + updateDetail + "WHERE GUESTID = " + userID + ";";

                }

                currentUsername = fname + " " + lname;
                greetingField.setText("Hi, " + currentUsername + ", Welcome to TLEvent.");
                try {
                    Database.insertStatement(updateDetail);
                    JOptionPane.showMessageDialog(null, "Profile Updated!!", "Update Successful", JOptionPane.INFORMATION_MESSAGE);
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        } else {
            JOptionPane.showMessageDialog(null, errorMessage, "Invalid Input", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    @FXML
    private void handlePasswordChangeButtonAction(ActionEvent event) throws IOException {
        JPasswordField oldPassword = new JPasswordField();
        JPasswordField newPassword = new JPasswordField();
        JPasswordField reEnterNewPassword = new JPasswordField();

        Object[] passwordFields = {
            "Old Password", oldPassword,
            "New Password", newPassword,
            "Re-enter New Password", reEnterNewPassword
        };

        int confirmation = JOptionPane.showConfirmDialog(null, passwordFields, "Change Password", JOptionPane.OK_CANCEL_OPTION);

        if (confirmation == JOptionPane.YES_OPTION) {
            String oPass = oldPassword.getText();
            String nPass = newPassword.getText();
            String rnPass = reEnterNewPassword.getText();

            if (!oPass.equals(userPassword)) {
                JOptionPane.showMessageDialog(null, "Password Incorrect", "Invalid Password", JOptionPane.OK_CANCEL_OPTION);
            } else {
                String errorMessage = "";
                errorMessage = StaticResource.passwordCheck(nPass, rnPass);

                if (errorMessage.equals("")) {
                    String updateDetail = "PASSWORD = '" + nPass + "'";

                    if (userType.equals("Admin")) {
                        updateDetail = "UPDATE ADMIN_USER SET " + updateDetail + "WHERE ADMINID = " + userID + ";";
                    } else if (userType.equals("Guest")) {
                        updateDetail = "UPDATE GUEST_USER SET " + updateDetail + "WHERE GUESTID = " + userID + ";";
                    }

                    try {
                        Database.insertStatement(updateDetail);
                        JOptionPane.showMessageDialog(null, "Password Updated !!", "Update Success", JOptionPane.OK_CANCEL_OPTION);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, errorMessage, "Invalid Password", JOptionPane.OK_CANCEL_OPTION);
                }
            }
        }
    }

    @FXML
    private void handleBackButtonAction(ActionEvent event) throws IOException {
        App.setRoot(StaticResource.currentPage);
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        genderField.getItems().addAll(
                "Male",
                "Female",
                "Not Specified"
        );

        greetingField.setText("Hi, " + currentUsername + ", Welcome to TLEvent.");
        idField.setText(userID);
        if (userType.equals("Admin")) {
            accesscodeLabel.setText("Username");
            userTypeField.setText("Admin");
            try {
                ResultSet rs = d.getResultSet("SELECT * FROM ADMIN_USER WHERE "
                        + "ADMINID = " + userID + ";");
                accessCodeField.setText(rs.getString(2));
                firstNameField.setText(rs.getString(4));
                lastNameField.setText(rs.getString(5));
                emailField.setText(rs.getString(9));
                mobileNumberField.setText(rs.getString(8));
                genderField.setValue(rs.getString(6));
                dateOfBirthField.setText(rs.getString(7));
                userPassword = rs.getString(3);
                createdDateField.setText(rs.getString(10));
                if(rs.getString(11).equals("-1")){
                    createdByField.setText("Self-Created");
                } else {
                    createdByField.setText(rs.getString(11));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else if (userType.equals("Guest")) {
            accesscodeLabel.setText("Access Code");
            userTypeField.setText("Guest");

            try {
                ResultSet rs = d.getResultSet("SELECT * FROM GUEST_USER WHERE "
                        + "GUESTID = " + userID + ";");
                accessCodeField.setText(rs.getString(2));
                firstNameField.setText(rs.getString(4));
                lastNameField.setText(rs.getString(5));
                emailField.setText(rs.getString(9));
                mobileNumberField.setText(rs.getString(8));
                genderField.setValue(rs.getString(6));
                dateOfBirthField.setText(rs.getString(7));
                userPassword = rs.getString(3);
                if(rs.getString(11).equals("-1")){
                    createdByField.setText("Self-Created");
                } else {
                    createdByField.setText(rs.getString(11));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    private void handleLogoutButtonAction(ActionEvent event) throws IOException {
        int logoutConfirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
        if (logoutConfirm == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(null, StaticResource.logoutMessage, "Logout Successful", JOptionPane.INFORMATION_MESSAGE);
            StaticResource.logoutClear();
            App.setRoot("LoginScreen");
        } 
    }
    
}

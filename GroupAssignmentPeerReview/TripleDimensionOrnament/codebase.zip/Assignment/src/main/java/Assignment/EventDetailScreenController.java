/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleLongProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import com.itextpdf.text.Image;
import com.itextpdf.text.List;
import com.itextpdf.text.ListItem;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.ZapfDingbatsList;
import com.itextpdf.text.pdf.CMYKColor;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import javafx.scene.chart.PieChart;

/**
 * FXML Controller class
 *
 * @author luluZ
 */
public class EventDetailScreenController implements Initializable {

    @FXML private Text totalInvite;
    @FXML private Text totalYes;
    @FXML private Text totalNo;
    @FXML private Text totalNoResponse;
    
    @FXML private Text eventIdField;
    @FXML private TextField eventNameField;
    @FXML private DatePicker eventDateField;
    
    @FXML private ComboBox startTimeHourField;
    @FXML private ComboBox endTimeHourField;
    @FXML private ComboBox startTimeMinuteField;
    @FXML private ComboBox endTimeMinuteField;
    
    @FXML private TextArea eventIntroductionField;
    @FXML private Text createdByField;
    @FXML private Text updatedByField;
    @FXML private Text createdAtField;
    @FXML private Text updatedAtField;
    
    @FXML private Button btnUpdate;
    @FXML private Button btnBack;
    @FXML private Button btnDeleteEvent;
    @FXML private Button btnPDF;
    @FXML private Button btnUnselect;
    @FXML private Button btnSubmit;
    @FXML private Button btnRemoveSlot;
    
    @FXML private ComboBox timeSlotHour;
    @FXML private ComboBox timeSlotMinute;
    @FXML private TextArea timeSlotDetailField;
    
    @FXML
    private TableView<EventDetail> dataDisplay;
    @FXML private TableColumn timeSlot;
    @FXML private TableColumn timeSlotDetail;
    
    @FXML private PieChart pieChart;
    
    public static long selectedEventId = -1;
    private ArrayList<String> tempEventDetailData = new ArrayList<String>();
    private String selectedTimeSlot = "";
    private int eventStartTime = -1;
    private int eventEndTime = -1;

    Database d = new Database();
    
    @FXML
    private void handleUpdateButtonAction(ActionEvent event) throws IOException {
        if (checkEventInput() == null || checkEventInput().equals("")) {
            
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date date = new Date();
            String currentDateTime = dateFormat.format(date);
            
            int click = JOptionPane.showConfirmDialog(null, "Comfirm to update this event?",
                    "Update Event", JOptionPane.YES_NO_OPTION);
            if (click == JOptionPane.YES_OPTION) {
                try {
                    String getStartTime = startTimeHourField.getValue().toString() + startTimeMinuteField.getValue().toString();
                    String getEndTime = endTimeHourField.getValue().toString() + endTimeMinuteField.getValue().toString();
                    
                    String query = "UPDATE EVENT SET "
                            + "EVENT_NAME = '" + eventNameField.getText().trim() + "', "
                            + "INTRODUCTION = '" + eventIntroductionField.getText().trim() + "', "
                            + "UPDATED_DATE = DATETIME('" + currentDateTime + "'), "
                            + "EVENT_DATE = DATE('" + eventDateField.getValue() + "'), "
                            + "START_TIME = '" + getStartTime + "', "
                            + "END_TIME = '" + getEndTime + "', "
                            + "UPDATED_BY = '" + StaticResource.currentUserId + "'"
                            + "WHERE EVENTID = " + selectedEventId + ";";
                    JOptionPane.showMessageDialog(null, "Event updated!", "Successful Updated", JOptionPane.INFORMATION_MESSAGE);
                    Database.insertStatement(query);
                    
                    eventStartTime = Integer.parseInt(getStartTime);
                    eventEndTime = Integer.parseInt(getEndTime);
                    
                    updatedByField.setText(StaticResource.currentUserId + ", " + StaticResource.currentUsername);
                    updatedAtField.setText(currentDateTime);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, checkEventInput(), "Invalid Event Input", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    @FXML
    private void handleBackButtonAction(ActionEvent event) throws IOException {
        App.setRoot(StaticResource.currentPage);
    }
    
    @FXML
    private void handleDeleteEventButtonAction(ActionEvent event) throws IOException {
        int confirmDelete = JOptionPane.showConfirmDialog(null, "Comfirm to delete event?", "Delete record", JOptionPane.YES_NO_OPTION);

        if (confirmDelete == JOptionPane.YES_OPTION) {
            try {
                String deleteRecord = "DELETE FROM EVENT WHERE EVENTID = " + selectedEventId + ";";
                JOptionPane.showMessageDialog(null, "Event deleted!", "Successful Deleted", JOptionPane.INFORMATION_MESSAGE);
                Database.insertStatement(deleteRecord);
                App.setRoot(StaticResource.currentPage);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public class Background extends PdfPageEventHelper {

        @Override
        public void onEndPage(PdfWriter writer, Document document) {
            int pagenumber = writer.getPageNumber();
            if (pagenumber % 2 == 1 && pagenumber != 1) {
                return;
            }
            PdfContentByte canvas = writer.getDirectContentUnder();
            Rectangle rect = document.getPageSize();
            canvas.setColorFill(pagenumber < 3 ? BaseColor.BLACK : BaseColor.BLACK);
            canvas.rectangle(rect.getLeft(), rect.getBottom(), rect.getWidth(), rect.getHeight());
            canvas.fill();
        }
    }
    
    @FXML
    private void handlePDFButtonAction(ActionEvent event) throws IOException, SQLException {
        String pdfName = "Event_Id" + selectedEventId + "Runsheet";
        int versionTracker = 0;

        Document document = new Document();
        try{
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Select Folder");
            fileChooser.setCurrentDirectory(new File(System.getProperty("user.home") + "Documents"));
            fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            fileChooser.setAcceptAllFileFilterUsed(false);

            int userSelection = fileChooser.showSaveDialog(null);

            if (userSelection == JFileChooser.APPROVE_OPTION) {
                File fileToSave = fileChooser.getSelectedFile();
                String path = fileToSave.getAbsolutePath() + "/" + pdfName + ".pdf";
                System.out.println(path);
                for(int i = 1; ; i++){
                    File tmpDir = new File(path);
                    if(!tmpDir.exists()) {
                        break;
                    } else {
                        path = fileToSave.getAbsolutePath() + "/" + pdfName + "(" + i + ").pdf";
                        versionTracker = i;
                    }
                }

                PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(path));
                Background bg = new Background();
                writer.setPageEvent(bg);
                document.open();
                
                Image logo = Image.getInstance(getClass().getResource("/image/tlevent_logo.png").toExternalForm());
                logo.scaleAbsolute(150, 150);
                logo.setAlignment(Image.ALIGN_CENTER);
                
                document.add(logo);

                Font whiteFont = FontFactory.getFont(FontFactory.HELVETICA, 12, Font.NORMAL, new CMYKColor(0, 0, 0, 0));
                Font whiteFont2 = FontFactory.getFont(FontFactory.HELVETICA, 15, Font.BOLD, new CMYKColor(0, 0, 0, 0));
                ZapfDingbatsList zapfDingbatsList = new ZapfDingbatsList(43, 30, BaseColor.WHITE);

                
                Paragraph p = new Paragraph();
                p = new Paragraph("\n", whiteFont);
                document.add(p);
                p = new Paragraph("\n", whiteFont);
                document.add(p);
                p = new Paragraph("PDF was generated by " + StaticResource.currentUsername + " from TLEvent", whiteFont2);
                p.setAlignment(Paragraph.ALIGN_CENTER);
                document.add(p);
                
                p = new Paragraph("\n", whiteFont);
                document.add(p);
                
                List unorderedList = new List(List.UNORDERED);
                p = new Paragraph("Event Details: ", whiteFont2);
                p.setAlignment(Paragraph.ALIGN_CENTER);
                document.add(p);
                p = new Paragraph("Event Id: " + selectedEventId, whiteFont);
                p.setAlignment(Paragraph.ALIGN_CENTER);
                unorderedList.add(new ListItem(p));
                ResultSet rs = d.getResultSet("SELECT * FROM EVENT  "
                        + "WHERE EVENTID = " + selectedEventId + ";");
                p = new Paragraph("Event Name: " + rs.getString(2), whiteFont);
                p.setAlignment(Paragraph.ALIGN_CENTER);
                unorderedList.add(new ListItem(p));
                p = new Paragraph("Event Introduction: " + rs.getString(3), whiteFont);
                p.setAlignment(Paragraph.ALIGN_CENTER);
                unorderedList.add(new ListItem(p));
                p = new Paragraph("Event Date: " + rs.getString(6), whiteFont);
                p.setAlignment(Paragraph.ALIGN_CENTER);
                unorderedList.add(new ListItem(p));
                p = new Paragraph("Event Start Time: " 
                        + String.valueOf(eventStartTime).substring(0,2)
                        + ":"
                        + String.valueOf(eventStartTime).substring(2), whiteFont);
                p.setAlignment(Paragraph.ALIGN_CENTER);
                unorderedList.add(new ListItem(p));
                p = new Paragraph("Event End Time: " 
                        + String.valueOf(eventEndTime).substring(0,2)
                        + ":"
                        + String.valueOf(eventEndTime).substring(2), whiteFont);
                p.setAlignment(Paragraph.ALIGN_CENTER);
                unorderedList.add(new ListItem(p));
                document.add(unorderedList);
                
                p = new Paragraph("\n", whiteFont);
                document.add(p);
                
                p = new Paragraph("Event RunSheet: ", whiteFont2);
                p.setAlignment(Paragraph.ALIGN_CENTER);
                document.add(p);
                if(tempEventDetailData.size() < 1){
                    p = new Paragraph("No Runsheet Found", whiteFont);
                    zapfDingbatsList.add(new ListItem(p));
                } else {
                    for (String s : tempEventDetailData) {
                        String time = s.substring(0, 2) + ":" + s.substring(2, 4);
                        String detail = "\t" + s.substring(4);
                        p = new Paragraph(time + "       " + detail, whiteFont);
                        p.setAlignment(Paragraph.ALIGN_CENTER);
                        zapfDingbatsList.add(new ListItem(p));
                    }
                }
                zapfDingbatsList.setDingbatColor(BaseColor.WHITE);
                document.add(zapfDingbatsList);

                document.addAuthor(StaticResource.currentUsername);
                document.addCreationDate();
                document.addCreator("TLEvent - First Class Planner");
                document.addSubject("BLablabla");
                document.close();
                writer.close();
                
                
                
                if(versionTracker != 0){
                    pdfName += "(" + versionTracker + ").pdf";
                } else {
                    pdfName += ".pdf";
                }
                
                JOptionPane.showMessageDialog(null, "PDF Generated.\nFile Name: " + pdfName, "PDF Generated", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (DocumentException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    
    @FXML
    private void handleUnselectButtonAction(ActionEvent event) throws IOException {
        clearSelectTimeslot();
    }
    
    @FXML
    private void handleSubmitButtonAction(ActionEvent event) throws IOException, SQLException {
        int timeInput = Integer.parseInt(timeSlotHour.getValue().toString() + timeSlotMinute.getValue().toString());
        String inputData = String.format("%04d", timeInput) + timeSlotDetailField.getText().trim();
        
        if(timeInput < eventStartTime || timeInput > eventEndTime){
            JOptionPane.showMessageDialog(null, "Invalid Timeslot! Time must be between Event Start and End Time!", "Invalid Timeslot", JOptionPane.INFORMATION_MESSAGE);
        } else if(timeSlotDetailField.getText().trim() == null || timeSlotDetailField.getText().trim().equals("")){
            JOptionPane.showMessageDialog(null, "Timeslot not saved! Detail is empty!", "Invalid Detail", JOptionPane.INFORMATION_MESSAGE);
        } else {
            boolean update = true;
            
            if(selectedTimeSlot != null || !selectedTimeSlot.equals("")){
                boolean duplicateReplaceTracker = false;
                for(int i = 0; i < tempEventDetailData.size(); i++){
                    System.out.println(String.valueOf(timeInput));
                    System.out.println(tempEventDetailData.get(i).substring(0,4));
                    if(String.format("%04d", timeInput).equals(tempEventDetailData.get(i).substring(0,4))){
                        int confirmReplace = JOptionPane.showConfirmDialog(null, "Same timeslot found, confirm to replace?", "Duplicate Timeslot", JOptionPane.YES_NO_OPTION);

                        if (confirmReplace == JOptionPane.YES_OPTION) {
                            tempEventDetailData.set(i, inputData);
                            duplicateReplaceTracker = true;
                        } else {
                            update = false;
                        }
                        break;
                    }
                }
                
                if(update && !duplicateReplaceTracker){
                    tempEventDetailData.add(inputData);
                }
            } else {
                for(int i = 0; i < tempEventDetailData.size(); i++){
                    if(String.valueOf(timeInput).equals(tempEventDetailData.get(i).substring(0,4))){
                        int confirmReplace = JOptionPane.showConfirmDialog(null, "Same timeslot found, confirm to replace?", "Duplicate Timeslot", JOptionPane.YES_NO_OPTION);

                        if (confirmReplace == JOptionPane.YES_OPTION) {
                            tempEventDetailData.set(i, inputData);
                        } else {
                            update = false;
                        }
                        break;
                    }
                }
            }
            
            if(update){
                Collections.sort(tempEventDetailData);
                String finalInput = "";
                for(String s: tempEventDetailData){
                    finalInput = finalInput + s + ";;;";
                }

                String query = "UPDATE EVENT_TIMELINE SET "
                            + "EVENTDETAIL = '" + finalInput + "' "
                            + "WHERE EVENTID = '" + selectedEventId + "';";
                
                JOptionPane.showMessageDialog(null, "Timeslot updated!", "Successful Updated", JOptionPane.INFORMATION_MESSAGE);
                Database.insertStatement(query);
                renewUpdatedTime();
                getData();
                
                clearSelectTimeslot();
            }
        }
    }
    
    public void clearSelectTimeslot(){
        timeSlotHour.setValue("00");
        timeSlotMinute.setValue("00");;
        timeSlotDetailField.clear();
        btnUnselect.setVisible(false);
        dataDisplay.getSelectionModel().select(null);
        btnRemoveSlot.setVisible(false);
    }
    
    public void setupPieChart(){
        int totalInvitation = 0;
        int acceptCounter = 0;
        int declineCounter = 0;
        int noResponseCounter = 0;
                
        try{
            ResultSet counter = d.getResultSet("SELECT INVITATIONID FROM INVITATION "
                        + "WHERE EVENTID = '" + selectedEventId + "';");
            
            while(counter.next()){
                totalInvitation++;
                ResultSet getRSVP = d.getResultSet("SELECT DECISION FROM RSVP "
                        + "WHERE INVITATIONID = '" + counter.getString(1) + "';");
                if(getRSVP.next()){
                    if(getRSVP.getString(1).equals("Accept")){
                        acceptCounter++;
                    } else if(getRSVP.getString(1).equals("Decline")){
                        declineCounter++;
                    } else {
                        noResponseCounter++;
                    }
                } else {
                    noResponseCounter++;
                }
            }
        } catch(Exception e){
            e.printStackTrace();
        }
        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList(
                new PieChart.Data("Yes", acceptCounter),
                new PieChart.Data("No", declineCounter),
                new PieChart.Data("No Response", noResponseCounter)
        );
        pieChart.setData(pieChartData);
        pieChart.setStartAngle(90);
        
        totalInvite.setText(String.valueOf(totalInvitation));
        totalYes.setText(String.valueOf(acceptCounter));
        totalNo.setText(String.valueOf(declineCounter));
        totalNoResponse.setText(String.valueOf(noResponseCounter));    
    }
    
    @FXML
    private void handleRemoveSlotButtonAction(ActionEvent event) throws IOException, SQLException {
        String timeInput = timeSlotHour.getValue().toString() + timeSlotMinute.getValue().toString();

        int confirmDelete = JOptionPane.showConfirmDialog(null, "Are you sure want to delete this Timeshlt?", "Duplicate Timeslot", JOptionPane.YES_NO_OPTION);

        if (confirmDelete == JOptionPane.YES_OPTION) {
            for (int i = 0; i < tempEventDetailData.size(); i++) {
                System.out.println(tempEventDetailData.get(i).substring(0, 4));
                if (timeInput.equals(tempEventDetailData.get(i).substring(0, 4))) {

                    tempEventDetailData.remove(i);

                    Collections.sort(tempEventDetailData);
                    String finalInput = "";
                    for (String s : tempEventDetailData) {
                        finalInput = finalInput + s + ";;;";
                    }
                    String query = "UPDATE EVENT_TIMELINE SET "
                            + "EVENTDETAIL = '" + finalInput + "' "
                            + "WHERE EVENTID = '" + selectedEventId + "';";

                    JOptionPane.showMessageDialog(null, "Timeslot updated!", "Successful Updated", JOptionPane.INFORMATION_MESSAGE);
                    Database.insertStatement(query);
                    renewUpdatedTime();
                    clearSelectTimeslot();
                    getData();

                    break;
                }
            }
        }
    }
    
    private void renewUpdatedTime() throws SQLException{
        
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        String currentDateTime = dateFormat.format(date);
        
        String query = "UPDATE EVENT SET "
                + "UPDATED_DATE = DATETIME('" + currentDateTime + "'), "
                + "UPDATED_BY = '" + StaticResource.currentUserId + "'"
                + "WHERE EVENTID = " + selectedEventId + ";";

        Database.insertStatement(query);

        updatedByField.setText(StaticResource.currentUserId + ", " + StaticResource.currentUsername);
        updatedAtField.setText(currentDateTime);
    }
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        clearSelectTimeslot();
        setupPieChart();
        ArrayList<String> hours = new ArrayList<String>();
        ArrayList<String> minutes = new ArrayList<String>();
        for (int i = 0; i < 24; i++) {
            hours.add(String.format("%02d", i));
        }

        for (int i = 0; i < 60; i += 15) {
            minutes.add(String.format("%02d", i));
        }
        
        startTimeHourField.getItems().addAll(hours);
        endTimeHourField.getItems().addAll(hours);
        startTimeMinuteField.getItems().addAll(minutes);
        endTimeMinuteField.getItems().addAll(minutes);
        timeSlotHour.getItems().addAll(hours);
        timeSlotMinute.getItems().addAll(minutes);
        
        startTimeHourField.setValue("00");
        endTimeHourField.setValue("00");
        startTimeMinuteField.setValue("00");
        endTimeMinuteField.setValue("00");
        timeSlotHour.setValue("00");
        timeSlotMinute.setValue("00");
        
        try {
            ResultSet rs = d.getResultSet("SELECT * FROM EVENT  "
                    + "WHERE EVENTID = " + selectedEventId + ";");

            eventIdField.setText(rs.getString(1));
            eventNameField.setText(rs.getString(2));
            eventIntroductionField.setText(rs.getString(3));
            eventDateField.setValue(LocalDate.parse(rs.getString(6)));
            startTimeHourField.setValue(rs.getString(7).substring(0, 2));
            startTimeMinuteField.setValue(rs.getString(7).substring(2));
            endTimeHourField.setValue(rs.getString(8).substring(0, 2));
            endTimeMinuteField.setValue(rs.getString(8).substring(2));
            createdAtField.setText(rs.getString(4));

            eventStartTime = Integer.parseInt(rs.getString(7));
            eventEndTime = Integer.parseInt(rs.getString(8));

            ResultSet tempRS = d.getResultSet("SELECT * FROM ADMIN_USER  "
                    + "WHERE ADMINID = " + rs.getString(9) + ";");
            if (tempRS.next()) {
                createdByField.setText(rs.getString(9) + ", " + tempRS.getString(4) + " " + tempRS.getString(5) + "");
            } else {
                createdByField.setText(rs.getString(9));
            }

            if (rs.getString(5) != null && !rs.getString(5).equals("")) {
                updatedAtField.setText(rs.getString(5));

                tempRS = d.getResultSet("SELECT * FROM ADMIN_USER  "
                        + "WHERE ADMINID = " + rs.getString(10) + ";");
                updatedByField.setText(rs.getString(10) + ", " + tempRS.getString(4) + " " + tempRS.getString(5));

            } else {
                updatedAtField.setText("");
                updatedByField.setText("");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        getData();

        dataDisplay.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (event.isPrimaryButtonDown() && event.getClickCount() == 1) {
                    if (!dataDisplay.getSelectionModel().isEmpty()) {
                        selectedTimeSlot = dataDisplay.getSelectionModel().getSelectedItem().getTimeSlot().replaceAll(":", "");

                        btnRemoveSlot.setVisible(true);
                        btnUnselect.setVisible(true);

                        String dataGetter = "";

                        for (String s : tempEventDetailData) {
                            if (selectedTimeSlot.equals(s.substring(0, 4))) {
                                dataGetter = s;
                                break;
                            }
                        }

                        timeSlotHour.setValue(dataGetter.substring(0, 2));
                        timeSlotMinute.setValue(dataGetter.substring(2, 4));
                        timeSlotDetailField.setText(dataGetter.substring(4));
                    }
                }
            }
        });
    }    
    
    public void getData(){
        ObservableList<EventDetail> dataList = FXCollections.observableArrayList();

        timeSlot.setCellValueFactory(new PropertyValueFactory<EventDetail, String>("timeSlot"));
        timeSlotDetail.setCellValueFactory(new PropertyValueFactory<EventDetail, String>("timeSlotDetail"));
        
        try {
            ResultSet rs = d.getResultSet("SELECT EVENTDETAIL FROM EVENT_TIMELINE  "
                    + "WHERE EVENTID = '" + selectedEventId + "';");
            if(rs.next()){
                if (rs.getString(1) != null && !rs.getString(1).equals("")) {
                    String rawDetail = rs.getString(1);
                    String[] detailArray = rawDetail.split(";;;");

                    for (String s : detailArray) {
                        EventDetail ed = new EventDetail();
                        ed.setTimeSlot(s.substring(0, 2) + ":" + s.substring(2, 4));
                        ed.setTimeSlotDetail(s.substring(4));
                        dataList.add(ed);
                    }
                    
                    if(tempEventDetailData.size() != detailArray.length){
                        tempEventDetailData.clear();
                        for (String s : detailArray) {
                            tempEventDetailData.add(s);
                        }
                    }
                }
            } else {
                Database.insertStatement("INSERT INTO EVENT_TIMELINE(EVENTID) VALUES ('" + selectedEventId + "');");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        if (dataList.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No Runsheet Found on this Event!", "Runsheet Search", JOptionPane.INFORMATION_MESSAGE);
        } else {
            timeSlot.setSortType(TableColumn.SortType.ASCENDING);
            dataDisplay.setItems(dataList);
            dataDisplay.getSortOrder().add(timeSlot);
        }
    }
    
    public class EventDetail{
        public SimpleStringProperty timeSlot = new SimpleStringProperty();
        public SimpleStringProperty timeSlotDetail = new SimpleStringProperty();

        public String getTimeSlot() {
            return timeSlot.get();
        }

        public void setTimeSlot(String newTimeSlot) {
            timeSlot.set(newTimeSlot);
        }

        public String getTimeSlotDetail() {
            return timeSlotDetail.get();
        }

        public void setTimeSlotDetail(String newTimeSlotDetail) {
            timeSlotDetail.set(newTimeSlotDetail);
        }
    }
    
    private String checkEventInput() {

        eventNameField.setStyle("-fx-border-color: transparent;");
        eventDateField.setStyle("-fx-border-color: transparent;");
        startTimeHourField.setStyle("-fx-border-color: transparent;");
        startTimeMinuteField.setStyle("-fx-border-color: transparent;");
        endTimeHourField.setStyle("-fx-border-color: transparent;");
        endTimeMinuteField.setStyle("-fx-border-color: transparent;");

        String errorMessage = "";

        if (eventNameField.getText().trim() == null || eventNameField.getText().trim().equals("")) {
            errorMessage += "*Event Name is Empty!!\n\n";
            eventNameField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        } else if (eventNameField.getText().trim().length() > 255) {
            errorMessage += "*Event Name is too Long!!\n\n";
            eventNameField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        } else if (eventNameField.getText().trim().length() < 5) {
            eventNameField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
            errorMessage += "*Minimum 5 characters for Event Name!!\n\n";
        }

        if (eventDateField.getValue() == null || eventDateField.getValue().equals("")) {
            errorMessage += "**Event Date is empty!!\n\n";
            eventDateField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        }

        String startHour = "";
        String startMinute = "";
        String endHour = "";
        String endMinute = "";

        if (startTimeHourField.getValue() == null || startTimeHourField.getValue().toString().equals("")) {
            errorMessage += "**Invalid Start Hour!!\n";
            startTimeHourField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        } else {
            startHour = startTimeHourField.getValue().toString();
        }

        if (startTimeMinuteField.getValue() == null || startTimeMinuteField.getValue().toString().equals("")) {
            errorMessage += "**Invalid Start Minute!!\n";
            startTimeMinuteField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        } else {
            startMinute = startTimeMinuteField.getValue().toString();
        }

        if (endTimeHourField.getValue() == null || endTimeHourField.getValue().toString().equals("")) {
            errorMessage += "**Invalid End Hour!!\n";
            endTimeHourField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        } else {
            endHour = endTimeHourField.getValue().toString();
        }

        if (endTimeMinuteField.getValue() == null || endTimeMinuteField.getValue().toString().equals("")) {
            errorMessage += "**Invalid End Minute!!\n";
            endTimeMinuteField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        } else {
            endMinute = endTimeMinuteField.getValue().toString();
        }

        if (startHour != null && !startHour.equals("") && startMinute != null && !startMinute.equals("")
                && endHour != null && !endHour.equals("") && endMinute != null && !endMinute.equals("")) {
            if (startHour.equals(endHour)) {
                if (Integer.parseInt(endMinute) < Integer.parseInt(startMinute)) {
                    errorMessage += "**End Time should be equal or later than start time!!\n";
                    endTimeMinuteField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
                    endTimeHourField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
                }
            } else if (Integer.parseInt(endHour) < Integer.parseInt(startHour)) {
                errorMessage += "**End Time should be equal or later than start time!!\n";
                endTimeMinuteField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
                endTimeHourField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
            }
        }

        return errorMessage;
    }
}

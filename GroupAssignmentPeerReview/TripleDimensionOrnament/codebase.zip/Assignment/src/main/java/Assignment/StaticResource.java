/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment;

import java.io.IOException;
import java.util.regex.Pattern;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javax.swing.JOptionPane;

/**
 * Static Variable and Method
 * @author luluZ
 */
public class StaticResource {
    public static String currentUserId = null;
    public static String currentUsername = null;
    public static String currentUserType = null;
    public static String currentPage = null;
    public static String currentUserPassword = null;
    
    public static String logoutMessage = "Thanks for using TLEvent.\nGoodbye and see you again. :)";
    
    public static void logoutClear(){
        currentUserId = null;
        currentUserPassword = null;
        currentUsername = null;
        currentUserType = null;
        currentPage = null;
    }
    
    public static String passwordCheck(String password, String reEnterPassword){
        Pattern specailCharPatten = Pattern.compile("[^a-z0-9 ]", Pattern.CASE_INSENSITIVE);
        Pattern UpperCasePatten = Pattern.compile("[A-Z ]");
        Pattern lowerCasePatten = Pattern.compile("[a-z ]");
        Pattern digitCasePatten = Pattern.compile("[0-9 ]");
        
        String error = "";
        
        if(!password.equals(reEnterPassword)){
            error +=  ("* Password didn't match!\n");
        } else {
        
            if(password.length() < 8){
                error +=  ("* Password minimum 8 characters!\n");
            }

            if (!specailCharPatten.matcher(password).find()) {
                error +=  ("* Password must have at least one specail character !!\n");
            }

            if (!UpperCasePatten.matcher(password).find()) {
                error +=  ("* Password must have at least one uppercase character !!\n");
            }

            if (!lowerCasePatten.matcher(password).find()) {
                error +=  ("* Password must have at least one lowercase character !!\n");
            }

            if (!digitCasePatten.matcher(password).find()) {
                error +=  ("* Password must have at least one digit character !!\n");
            }
        }
        
        return error;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleLongProperty;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author luluZ
 */
public class EventScreenController implements Initializable {

    @FXML private ComboBox searchType;
    
    @FXML
    private Button btnLogout;
    @FXML
    private Button btnProfile;

    @FXML
    private Button btnHome;
    @FXML
    private Button btnEvent;
    @FXML
    private Button btnInvitation;
    @FXML
    private Button btnAboutUs;

    @FXML
    private Button btnUpdate;
    @FXML
    private Button btnSearch;
    @FXML
    private Button btnUnselect;
    @FXML
    private Button btnDelete;
    @FXML
    private Button btnReset;

    @FXML
    private Button btnDetail;

    @FXML
    private Button btnInvite;

    @FXML
    private Text eventIdField;
    @FXML
    private Text createdByField;
    @FXML
    private Text updatedByField;
    @FXML
    private Text createdAtField;
    @FXML
    private Text updatedAtField;

    @FXML
    private Text updatedByLabel;
    @FXML
    private Text updatedAtLabel;

    @FXML
    private TextField eventNameField;
    @FXML
    private TextField searchEventNameField;

    @FXML
    private TextArea eventIntroductionField;

    @FXML
    private DatePicker eventDateField;

    @FXML
    private ComboBox startTimeHourField;
    @FXML
    private ComboBox endTimeHourField;
    @FXML
    private ComboBox startTimeMinuteField;
    @FXML
    private ComboBox endTimeMinuteField;

    @FXML
    private TableView<EventInformation> dataDisplay;
    @FXML
    private TableColumn eventId;
    @FXML
    private TableColumn eventName;
    @FXML
    private TableColumn eventUpdatedDate;

    Database d = new Database();
    
    private String getAllEventQuery = "SELECT * FROM EVENT;";

    public static long selectedEventId = -1;
    public static String selectedEventName = null;
    public static String selectedEventDate = null;

    @FXML
    private void handleDeleteButtonAction(ActionEvent event) throws IOException {
        int confirmDelete = JOptionPane.showConfirmDialog(null, "Comfirm to delete event?", "Delete record", JOptionPane.YES_NO_OPTION);

        if (confirmDelete == JOptionPane.YES_OPTION) {
            try {
                String deleteRecord = "DELETE FROM EVENT WHERE EVENTID = " + selectedEventId + ";";
                JOptionPane.showMessageDialog(null, "Event deleted!", "Successful Deleted", JOptionPane.INFORMATION_MESSAGE);
                Database.insertStatement(deleteRecord);
                getEventData(getAllEventQuery);
                clearSelected();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    private void handleUnselectButtonAction(ActionEvent event) throws IOException {
        clearSelected();
    }
    
    @FXML
    private void handleInviteButtonAction(ActionEvent event) throws IOException {
        App.setRoot("CreateInvitationScreen");
    }
    
    @FXML
    private void handleDetailButtonAction(ActionEvent event) throws IOException {
        EventDetailScreenController.selectedEventId = selectedEventId;
        App.setRoot("EventDetailScreen");
    }

    @FXML
    private void handleUpdateButtonAction(ActionEvent event) throws IOException {
        clearHighlight();
        if (checkEventInput() == null || checkEventInput().equals("")) {
            String query = "";

            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date date = new Date();
            String currentDateTime = dateFormat.format(date);

            String getStartTime = startTimeHourField.getValue().toString() + startTimeMinuteField.getValue().toString();
            String getEndTime = endTimeHourField.getValue().toString() + endTimeMinuteField.getValue().toString();

            if (selectedEventId == -1) {
                boolean validCheck = true;

                try {
                    ResultSet rs = d.getResultSet("SELECT * FROM EVENT  "
                            + "WHERE EVENT_NAME = '" + eventNameField.getText().trim() + "';");

                    if (rs.next()) {
                        int nameConfirm = JOptionPane.showConfirmDialog(null, "Same Event Name Found.\nConfirm Name?",
                                "Name Confirmation", JOptionPane.YES_NO_OPTION);
                        if (nameConfirm != JOptionPane.YES_OPTION) {
                            validCheck = false;
                            eventNameField.setStyle("-fx-border-color:red; -fx-border-width: 2px;");
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

                LocalDate today = LocalDate.now();
                if (eventDateField.getValue().isBefore(today)) {
                    int dateConfirm = JOptionPane.showConfirmDialog(null, "Event Date was before today.\nConfirm Date?",
                            "Date Confirmation", JOptionPane.YES_NO_OPTION);
                    if (dateConfirm != JOptionPane.YES_OPTION) {
                        validCheck = false;
                        eventDateField.setStyle("-fx-border-color:red; -fx-border-width: 2px;");
                    }
                }

                if(validCheck){
                    int click = JOptionPane.showConfirmDialog(null, "Comfirm to create this event?",
                            "Create Event", JOptionPane.YES_NO_OPTION);
                    if (click == JOptionPane.YES_OPTION) {
                        try {
                            System.out.print(currentDateTime);
                            query = "INSERT INTO EVENT(EVENT_NAME, INTRODUCTION, CREATED_DATE, CREATED_BY, START_TIME, END_TIME, EVENT_DATE) VALUES "
                                    + "('" + eventNameField.getText().trim() + "', "
                                    + "'" + eventIntroductionField.getText().trim() + "', "
                                    + "DATETIME('" + currentDateTime + "'), "
                                    + "'" + StaticResource.currentUserId + "', "
                                    + "'" + getStartTime + "', "
                                    + "'" + getEndTime + "', "
                                    + "DATE('" + eventDateField.getValue() + "')"
                                    + ");";
                            JOptionPane.showMessageDialog(null, "Event created!", "Successful Created", JOptionPane.INFORMATION_MESSAGE);
                            Database.insertStatement(query);
                            clearSelected();
                            getEventData(getAllEventQuery);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                }
            } else {

                int click = JOptionPane.showConfirmDialog(null, "Comfirm to update this event?",
                        "Update Event", JOptionPane.YES_NO_OPTION);
                if (click == JOptionPane.YES_OPTION) {
                    try {
                        query = "UPDATE EVENT SET "
                                + "EVENT_NAME = '" + eventNameField.getText().trim() + "', "
                                + "INTRODUCTION = '" + eventIntroductionField.getText().trim() + "', "
                                + "UPDATED_DATE = DATETIME('" + currentDateTime + "'), "
                                + "EVENT_DATE = DATE('" + eventDateField.getValue() + "'), "
                                + "START_TIME = '" + getStartTime + "', "
                                + "END_TIME = '" + getEndTime + "', "
                                + "UPDATED_BY = '" + StaticResource.currentUserId + "'"
                                + "WHERE EVENTID = " + selectedEventId + ";";
                        JOptionPane.showMessageDialog(null, "Event updated!", "Successful Updated", JOptionPane.INFORMATION_MESSAGE);
                        Database.insertStatement(query);
                        clearSelected();
                        getEventData(getAllEventQuery);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, checkEventInput(), "Invalid Input", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    @FXML
    private void handleSearchButtonAction(ActionEvent event) throws IOException {
        clearSelected();
        String keyword = searchEventNameField.getText();
        
        String query = "";
        if(searchType.getValue().toString().equals("Id")){
            query = "SELECT * FROM EVENT WHERE EVENTID LIKE '%" + keyword + "%';";
        } else if(searchType.getValue().toString().equals("Event Name")) {
            query = "SELECT * FROM EVENT WHERE EVENT_NAME LIKE '%" + keyword + "%';";
        }

        if (keyword != null && !keyword.equals("")) {
            getEventData(query);
        } else {
            getEventData(getAllEventQuery);
        }
    }

    @FXML
    private void handleResetSearchButtonAction(ActionEvent event) throws IOException {
        clearSelected();
        dataDisplay.getItems().clear();
        searchEventNameField.clear();
        getEventData(getAllEventQuery);
    }

    @FXML
    private void handleHomeButtonAction(ActionEvent event) throws IOException {
        App.setRoot("AdminHomeScreen");
    }

    @FXML
    private void handleEventButtonAction(ActionEvent event) throws IOException {
        App.setRoot("EventScreen");
    }

    @FXML
    private void handleInvitationButtonAction(ActionEvent event) throws IOException {
        App.setRoot("InvitationScreen");
    }

    @FXML
    private void handleAboutUsButtonAction(ActionEvent event) throws IOException {
        App.setRoot("AboutUsScreen");
    }

    @FXML
    private void handleProfileButtonAction(ActionEvent event) throws IOException {
        App.setRoot("ProfileScreen");
    }

    @FXML
    private void handleLogoutButtonAction(ActionEvent event) throws IOException {
        int logoutConfirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
        if (logoutConfirm == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(null, StaticResource.logoutMessage, "Logout Successful", JOptionPane.INFORMATION_MESSAGE);
            StaticResource.logoutClear();
            App.setRoot("LoginScreen");
        }
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btnProfile.setText(StaticResource.currentUsername);
        StaticResource.currentPage = "EventScreen";

        searchType.getItems().addAll(
                "Id", "Event Name"
        );
        searchType.setValue("Id");
        
        btnDelete.setVisible(false);
        btnInvite.setVisible(false);
        btnDetail.setVisible(false);
        btnUnselect.setText("Reset Form");

        ArrayList<String> hourList = new ArrayList<String>();
        ArrayList<String> minuteList = new ArrayList<String>();
        for (int i = 0; i < 24; i++) {
            hourList.add(String.format("%02d", i));
        }

        for (int i = 0; i < 60; i += 15) {
            minuteList.add(String.format("%02d", i));
        }

        startTimeHourField.getItems().addAll(hourList);
        startTimeMinuteField.getItems().addAll(minuteList);
        endTimeHourField.getItems().addAll(hourList);
        endTimeMinuteField.getItems().addAll(minuteList);

        startTimeHourField.setValue("00");
        startTimeMinuteField.setValue("00");
        endTimeHourField.setValue("00");
        endTimeMinuteField.setValue("00");
        
        getEventData(getAllEventQuery);

        dataDisplay.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (event.isPrimaryButtonDown() && event.getClickCount() == 1) {
                    if (!dataDisplay.getSelectionModel().isEmpty()) {
                        btnDelete.setVisible(true);
                        btnInvite.setVisible(false);
                        btnDetail.setVisible(true);
                        btnUnselect.setText("Unselect Event");

                        clearHighlight();

                        btnUpdate.setText("UPDATE");

                        selectedEventId = dataDisplay.getSelectionModel().getSelectedItem().getEventId();

                        try {
                            ResultSet rs = d.getResultSet("SELECT * FROM EVENT  "
                                    + "WHERE EVENTID = " + selectedEventId + ";");

                            selectedEventName = rs.getString(2);
                            selectedEventDate = rs.getString(6);
                            eventIdField.setText(rs.getString(1));
                            eventNameField.setText(rs.getString(2));
                            eventIntroductionField.setText(rs.getString(3));
                            eventDateField.setValue(LocalDate.parse(rs.getString(6)));
                            startTimeHourField.setValue(rs.getString(7).substring(0, 2));
                            startTimeMinuteField.setValue(rs.getString(7).substring(2));
                            endTimeHourField.setValue(rs.getString(8).substring(0, 2));
                            endTimeMinuteField.setValue(rs.getString(8).substring(2));
                            createdAtField.setText(rs.getString(4));

                            if (!LocalDate.parse(rs.getString(6)).isBefore(LocalDate.now())) {
                                btnInvite.setVisible(true);
                            }

                            ResultSet tempRS = d.getResultSet("SELECT * FROM ADMIN_USER  "
                                    + "WHERE ADMINID = " + rs.getString(9) + ";");
                            if(tempRS.next()){
                                createdByField.setText(rs.getString(9) + ", " + tempRS.getString(4) + " " + tempRS.getString(5) + "");
                            } else {
                                createdByField.setText(rs.getString(9));
                            }

                            if (rs.getString(5) != null && !rs.getString(5).equals("")) {
                                updatedAtField.setText(rs.getString(5));

                                tempRS = d.getResultSet("SELECT * FROM ADMIN_USER  "
                                        + "WHERE ADMINID = " + rs.getString(10) + ";");
                                updatedByField.setText(rs.getString(10) + ", " + tempRS.getString(4) + " " + tempRS.getString(5));

                            } else {
                                updatedAtField.setText("");
                                updatedByField.setText("");
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                } else if (event.isPrimaryButtonDown() && event.getClickCount() == 2) {
                    if (!dataDisplay.getSelectionModel().isEmpty()) {
                        selectedEventId = dataDisplay.getSelectionModel().getSelectedItem().getEventId();
                        EventDetailScreenController.selectedEventId = selectedEventId;
                        try {
                            App.setRoot("EventDetailScreen");
                        } catch (IOException ex) {
                            Logger.getLogger(EventScreenController.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
            }
        });

        btnEvent.setStyle("-fx-text-fill: #FFFFFF;");
    }

    public void getEventData(String query) {
        ObservableList<EventInformation> dataList = FXCollections.observableArrayList();

        eventId.setCellValueFactory(new PropertyValueFactory<EventInformation, String>("EventId"));
        eventName.setCellValueFactory(new PropertyValueFactory<EventInformation, String>("EventName"));
        eventUpdatedDate.setCellValueFactory(new PropertyValueFactory<EventInformation, String>("EventUpdatedDate"));

        try {
            ResultSet rs = d.getResultSet(query);
            while (rs.next()) {
                EventInformation ei = new EventInformation();
                ei.setEventId(rs.getLong(1));
                ei.setEventName(rs.getString(2));
                if (rs.getString(5) == null || rs.getString(5).equals("")) {
                    ei.setEventUpdatedDate(rs.getString(4));
                } else {
                    ei.setEventUpdatedDate(rs.getString(5));
                }

                dataList.add(ei);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (dataList.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No Event Found!", "Event Search", JOptionPane.INFORMATION_MESSAGE);
        } else {
            eventUpdatedDate.setSortType(TableColumn.SortType.DESCENDING);
            dataDisplay.setItems(dataList);
            dataDisplay.getSortOrder().add(eventUpdatedDate);
        }
    }

    public void clearHighlight() {
        eventNameField.setStyle("-fx-border-color: transparent;");
        eventDateField.setStyle("-fx-border-color: transparent;");
        startTimeHourField.setStyle("-fx-border-color: transparent;");
        startTimeMinuteField.setStyle("-fx-border-color: transparent;");
        endTimeHourField.setStyle("-fx-border-color: transparent;");
        endTimeMinuteField.setStyle("-fx-border-color: transparent;");
    }

    public void clearSelected() {
        clearHighlight();

        selectedEventId = -1;
        eventIdField.setText("");
        eventNameField.setText("");
        eventIntroductionField.setText("");
        eventDateField.setValue(null);
        startTimeHourField.setValue(null);
        startTimeMinuteField.setValue(null);
        endTimeHourField.setValue(null);
        endTimeMinuteField.setValue(null);
        createdAtField.setText("");
        createdByField.setText("");
        updatedAtField.setText("");
        updatedByField.setText("");

        btnUnselect.setText("Reset Form");
        btnDelete.setVisible(false);
        btnUpdate.setText("CREATE");
        btnInvite.setVisible(false);
        btnDetail.setVisible(false);

        dataDisplay.getSelectionModel().clearSelection();
    }

    private String checkEventInput() {

        clearHighlight();

        String errorMessage = "";

        if (eventNameField.getText().trim() == null || eventNameField.getText().trim().equals("")) {
            errorMessage += "*Event Name is Empty!!\n\n";
            eventNameField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        } else if (eventNameField.getText().trim().length() > 255) {
            errorMessage += "*Event Name is too Long!!\n\n";
            eventNameField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        } else if (eventNameField.getText().trim().length() < 5) {
            eventNameField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
            errorMessage += "*Minimum 5 characters for Event Name!!\n\n";
        }

        if (eventDateField.getValue() == null || eventDateField.getValue().equals("")) {
            errorMessage += "**Event Date is empty!!\n\n";
            eventDateField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        }

        String startHour = "";
        String startMinute = "";
        String endHour = "";
        String endMinute = "";

        if (startTimeHourField.getValue() == null || startTimeHourField.getValue().toString().equals("")) {
            errorMessage += "**Invalid Start Hour!!\n";
            startTimeHourField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        } else {
            startHour = startTimeHourField.getValue().toString();
        }

        if (startTimeMinuteField.getValue() == null || startTimeMinuteField.getValue().toString().equals("")) {
            errorMessage += "**Invalid Start Minute!!\n";
            startTimeMinuteField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        } else {
            startMinute = startTimeMinuteField.getValue().toString();
        }

        if (endTimeHourField.getValue() == null || endTimeHourField.getValue().toString().equals("")) {
            errorMessage += "**Invalid End Hour!!\n";
            endTimeHourField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        } else {
            endHour = endTimeHourField.getValue().toString();
        }

        if (endTimeMinuteField.getValue() == null || endTimeMinuteField.getValue().toString().equals("")) {
            errorMessage += "**Invalid End Minute!!\n";
            endTimeMinuteField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
        } else {
            endMinute = endTimeMinuteField.getValue().toString();
        }

        if (startHour != null && !startHour.equals("") && startMinute != null && !startMinute.equals("")
                && endHour != null && !endHour.equals("") && endMinute != null && !endMinute.equals("")) {
            if (startHour.equals(endHour)) {
                if (Integer.parseInt(endMinute) < Integer.parseInt(startMinute)) {
                    errorMessage += "**End Time should be equal or later than start time!!\n";
                    endTimeMinuteField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
                    endTimeHourField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
                }
            } else if (Integer.parseInt(endHour) < Integer.parseInt(startHour)) {
                errorMessage += "**End Time should be equal or later than start time!!\n";
                endTimeMinuteField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
                endTimeHourField.setStyle("-fx-border-color: red; -fx-border-width:2px;");
            }
        }

        return errorMessage;
    }

    public class EventInformation {

        public SimpleLongProperty eventId = new SimpleLongProperty();
        public SimpleStringProperty eventName = new SimpleStringProperty();
        public SimpleStringProperty eventUpdatedDate = new SimpleStringProperty();

        public long getEventId() {
            return eventId.get();
        }

        public void setEventId(long newEventId) {
            eventId.set(newEventId);
        }

        public String getEventName() {
            return eventName.get();
        }

        public void setEventName(String newEventName) {
            eventName.set(newEventName);
        }

        public String getEventUpdatedDate() {
            return eventUpdatedDate.get();
        }

        public void setEventUpdatedDate(String newEventUpdatedDate) {
            eventUpdatedDate.set(newEventUpdatedDate);
        }
    }
    
}

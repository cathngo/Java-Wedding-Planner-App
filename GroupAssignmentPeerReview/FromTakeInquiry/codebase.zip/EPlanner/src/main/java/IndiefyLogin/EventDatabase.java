package IndiefyLogin;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class EventDatabase {
    
    private static final String TABLE_NAME_FOR_EPLANNER = "event";
    public static Connection sharedConnection;
    
    private static boolean openConnection() {
        boolean wasThisMethodSuccessful = false;
        try {
            EventDatabase.sharedConnection = DriverManager.getConnection("jdbc:sqlite:Event.db");
            wasThisMethodSuccessful = true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    }
    
    private static boolean closeConnection() {
        boolean wasThisMethodSuccessful = false;
        try {
            sharedConnection.close();
            wasThisMethodSuccessful = true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    }
    
    private static boolean createEventTable() {
        boolean wasThisMethodSuccessful = false;
        try {
            EventDatabase.openConnection();
            String createTableSql = "CREATE TABLE " + EventDatabase.TABLE_NAME_FOR_EPLANNER + " ("
                    + "event_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + "name TEXT, "
                    + "location TEXT, "
                    + "date TEXT) ";
            Statement smt = sharedConnection.createStatement();
            wasThisMethodSuccessful = smt.execute(createTableSql);
            EventDatabase.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    }
    
    public static boolean setupEventDatabaseOnFirstRun() {
        boolean wasThisMethodSuccessful = false;
        try {
            EventDatabase.openConnection();
            DatabaseMetaData dbmd = EventDatabase.sharedConnection.getMetaData();
            ResultSet rs = dbmd.getTables(null, null, EventDatabase.TABLE_NAME_FOR_EPLANNER, null);
            boolean needToSetupDatabase = false;
            if (!rs.next()) {
                needToSetupDatabase = true;
            }
            EventDatabase.closeConnection();
            if (needToSetupDatabase) {
                boolean createdTableSuccessfully = EventDatabase.createEventTable();
                wasThisMethodSuccessful = (createdTableSuccessfully);
            } else {
                wasThisMethodSuccessful = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    }
        
    public static Event fetchEvent() {
        Event preparedReturn = null;
        try {
            EventDatabase.openConnection();
            String sqlString = "SELECT * FROM " + EventDatabase.TABLE_NAME_FOR_EPLANNER;
            PreparedStatement psmt = sharedConnection.prepareStatement(sqlString);
            ResultSet rs = psmt.executeQuery();
            while (rs.next()) {
                preparedReturn = new Event(rs.getString("name"), 
                        rs.getString("location"), rs.getString("date"));
            }
            EventDatabase.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return preparedReturn;
        }
    }
    
    public static void addData(String name, String location, String date) {
        try {
            EventDatabase.openConnection();
            String sqlString = "INSERT INTO " + EventDatabase.TABLE_NAME_FOR_EPLANNER
                    + " (name, location, date)"
                    + " VALUES (?, ?, ?)";
            PreparedStatement psmt = sharedConnection.prepareStatement(sqlString);
            psmt.setString(1, name);
            psmt.setString(2, location);
            psmt.setString(3, date);
            psmt.execute();
            EventDatabase.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
        }
    }
    
    public static void deleteData(String name, String location, String date) {
        try{
            EventDatabase.openConnection();
            String sqlString = "DELETE FROM " + EventDatabase.TABLE_NAME_FOR_EPLANNER
                    + " WHERE name = ? AND location = ? AND date = ?";
            PreparedStatement psmt = sharedConnection.prepareStatement(sqlString);
            psmt.setString(1, name);
            psmt.setString(2, location);
            psmt.setString(3, date);
            psmt.execute();
            EventDatabase.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public static void editData(String name, String location, String date) {
        try{
            EventDatabase.openConnection();
            String sqlString = "UPDATE " + EventDatabase.TABLE_NAME_FOR_EPLANNER
                    + " SET name = ?, location = ?, date = ?"
                    + " WHERE name = ? AND location = ? AND date = ?";
            PreparedStatement psmt = sharedConnection.prepareStatement(sqlString);
            psmt.setString(1, name);
            psmt.setString(2, location);
            psmt.setString(3, date);
            psmt.setString(4, EventPageController.selectedEvent.get(0));
            psmt.setString(5, EventPageController.selectedEvent.get(1));
            psmt.setString(6, EventPageController.selectedEvent.get(2));
            psmt.execute();
            EventDatabase.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
        
}

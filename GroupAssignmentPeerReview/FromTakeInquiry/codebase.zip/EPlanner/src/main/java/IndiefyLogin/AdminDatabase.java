package IndiefyLogin;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;

public class AdminDatabase {
    
    private static final String TABLE_NAME_FOR_EPLANNER = "admin";
    public static Connection sharedConnection;
    
    private static boolean openConnection() {
        boolean wasThisMethodSuccessful = false;
        try {
            AdminDatabase.sharedConnection = DriverManager.getConnection("jdbc:sqlite:Admin.db");
            wasThisMethodSuccessful = true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    }
    
    private static boolean closeConnection() {
        boolean wasThisMethodSuccessful = false;
        try {
            sharedConnection.close();
            wasThisMethodSuccessful = true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    }
    
    private static boolean createAdminTable() {
        boolean wasThisMethodSuccessful = false;
        try {
            AdminDatabase.openConnection();
            String createTableSql = "CREATE TABLE " + AdminDatabase.TABLE_NAME_FOR_EPLANNER + " ("
                    + "admin_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + "first_name TEXT, "
                    + "last_name TEXT, "
                    + "username TEXT, "
                    + "password TEXT) ";
            Statement smt = sharedConnection.createStatement();
            wasThisMethodSuccessful = smt.execute(createTableSql);
            AdminDatabase.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    }
    
    private static boolean setupAdminDummyData() {
        boolean wasThisMethodSuccessful = false;
        try {
            AdminDatabase.openConnection();
            String sqlString = "INSERT INTO " + AdminDatabase.TABLE_NAME_FOR_EPLANNER
                    + " (first_name, last_name, username, password)"
                    + " VALUES (?, ?, ?, ?)";
            PreparedStatement psmt = sharedConnection.prepareStatement(sqlString);
            String[] firstNames = {"Jean", "Patrick", "Blair"};
            String[] lastNames = {"Valjean", "O’Connor", "Wang"};
            String[] usernames = {"jean.v", "patrick.oc", "blair.wang"};
            String[] passwords = {"admin", "admin", "admin"};
            for (int i = 0; i < usernames.length; i++) {
                psmt.setString(1, firstNames[i]);
                psmt.setString(2, lastNames[i]);
                psmt.setString(3, usernames[i]);
                psmt.setString(4, passwords[i]);
                boolean wasThisRoundSuccessful = psmt.execute();
                wasThisMethodSuccessful = (wasThisMethodSuccessful && wasThisRoundSuccessful);
            }
            AdminDatabase.closeConnection();
            wasThisMethodSuccessful = true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    }
    
    public static boolean setupAdminDatabaseOnFirstRun() {
        boolean wasThisMethodSuccessful = false;
        try {
            AdminDatabase.openConnection();
            DatabaseMetaData dbmd = AdminDatabase.sharedConnection.getMetaData();
            ResultSet rs = dbmd.getTables(null, null, AdminDatabase.TABLE_NAME_FOR_EPLANNER, null);
            boolean needToSetupDatabase = false;
            if (!rs.next()) {
                needToSetupDatabase = true;
            }
            AdminDatabase.closeConnection();
            if (needToSetupDatabase) {
                boolean createdTableSuccessfully = AdminDatabase.createAdminTable();
                boolean createdDataSuccessfully = AdminDatabase.setupAdminDummyData();
                wasThisMethodSuccessful = (createdTableSuccessfully && createdDataSuccessfully);
            } else {
                wasThisMethodSuccessful = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            
        } finally {
            return wasThisMethodSuccessful;
        }
    }
        
    public static Admin fetchAdmin(String username, String password) {
        Admin preparedReturn = null;
        try {
            AdminDatabase.openConnection();
            String sqlString = "SELECT * FROM " + AdminDatabase.TABLE_NAME_FOR_EPLANNER
                    + " WHERE username = ? AND password = ?";
            PreparedStatement psmt = sharedConnection.prepareStatement(sqlString);
            psmt.setString(1, username);
            psmt.setString(2, password);
            ResultSet rs = psmt.executeQuery();
            while (rs.next()) {
                preparedReturn = new Admin(rs.getString("first_name"), rs.getString("last_name"),
                        rs.getString("username"), rs.getString("password"));
            }
            AdminDatabase.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return preparedReturn;
        }
    }
        
}

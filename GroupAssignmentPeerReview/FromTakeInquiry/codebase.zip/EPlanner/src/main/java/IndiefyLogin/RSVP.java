package IndiefyLogin;

import java.util.Date;

public class RSVP {
    
    private String guestAccessCode;
    private String eventName;
    private String eventLocation;
    private String eventDate;
    private String decision;
    private String dietaryRequirements;

    public RSVP(String guestAccessCode, String eventName, String eventLocation, String eventDate, String decision, String dietaryRequirements) {
        this.guestAccessCode = guestAccessCode;
        this.eventName = eventName;
        this.eventLocation = eventLocation;
        this.eventDate = eventDate;
        this.decision = decision;
        this.dietaryRequirements = dietaryRequirements;
    }

    public void setGuestAccessCode(String guestAccessCode) {
        this.guestAccessCode = guestAccessCode;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public void setEventLocation(String eventLocation) {
        this.eventLocation = eventLocation;
    }

    public void setEventDate(String eventDate) {
        this.eventDate = eventDate;
    }

    public void setDecision(String decision) {
        this.decision = decision;
    }

    public void setDietaryRequirements(String dietaryRequirements) {
        this.dietaryRequirements = dietaryRequirements;
    }

    public String getGuestAccessCode() {
        return guestAccessCode;
    }

    public String getEventName() {
        return eventName;
    }

    public String getEventLocation() {
        return eventLocation;
    }

    public String getEventDate() {
        return eventDate;
    }

    public String getDecision() {
        return decision;
    }

    public String getDietaryRequirements() {
        return dietaryRequirements;
    }
    
}

package IndiefyLogin;

import static IndiefyLogin.InvitationPageController.selectedGuestEvent;
import java.io.IOException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class RespondToEventController {
    
    ObservableList<String> decisionMade = FXCollections.observableArrayList("Yes","No");
    
    @FXML
    private Button cancel;

    @FXML
    private Button logout;

    @FXML
    private Button about;
    
    @FXML
    private Button confirm;
    
    @FXML
    private ComboBox<String> decision;
    
    @FXML
    private TextField dietaryRequirements;
    
    @FXML
    private void handleLogoutButton(ActionEvent event) throws IOException {
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("LoginPage.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    private void handleAboutUsButton(ActionEvent event) throws IOException {
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("AboutUsGuest.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    private void handleCancelButton(ActionEvent event) throws IOException {
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("InvitationPage.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    private void handleConfirmButton(ActionEvent event) throws IOException {
        //RSVPDatabase.addDecision(GuestLoginController.accessCode.getText(),
                //selectedGuestEvent.get(0), selectedGuestEvent.get(1), selectedGuestEvent.get(2), 
                //decision.getValue(), dietaryRequirements.getText());
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("InvitationPage.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }

    @FXML
    public void initialize() {
        decision.setItems(decisionMade);
    }

}

package IndiefyLogin;

import static IndiefyLogin.EventPageController.selectedEvent;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class CreateEventController {
    
    @FXML
    private TextField eventLocation;

    @FXML
    private TextField eventName;

    @FXML
    private TableView<Guest> guestLists;

    @FXML
    private TableColumn<Guest, String> firstname;

    @FXML
    private TableColumn<Guest, String> lastname;

    @FXML
    private TableColumn<Guest, String> accessCode;

    @FXML
    private TableColumn<Guest, String> email;

    @FXML
    private TableColumn<Guest, String> phoneNumber;

    @FXML
    private Button cancel;

    @FXML
    private TextField eventDate;

    @FXML
    private Button guestsButton;

    @FXML
    private Button logout;

    @FXML
    private Button about;

    @FXML
    private Button create;
    
    @FXML
    private Button addGuest;
    
    @FXML
    private TableView<Guest> invitedGuestTable;
    
    @FXML
    private TableColumn<Guest, String> invitedGuest;
    
    @FXML
    ObservableList<Guest> guestListToReturn = FXCollections.observableArrayList();
    
    @FXML
    private void handleAddGuestButton(ActionEvent event) throws IOException {
        guestListToReturn.add(guestLists.getSelectionModel().getSelectedItem());
    }

    @FXML
    private void handleAboutUsButton(ActionEvent event) throws IOException {
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("AboutUs.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    private void handleLogoutButton(ActionEvent event) throws IOException {
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("LoginPage.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    private void handleGuestsButton(ActionEvent event) throws IOException {
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("GuestListPage.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    private void handleCancelButton(ActionEvent event) throws IOException {
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("EventPage.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    private void handleCreateButton(ActionEvent event) throws IOException {
        EventDatabase.addData(eventName.getText(), eventLocation.getText(), eventDate.getText());
        ArrayList<String> invitedGuestList = new ArrayList<String>();
        for (Guest guest : invitedGuestTable.getItems()) {
            invitedGuestList.add(guest.getAccessCode());
        }
        for (int i = 0; i < guestListToReturn.size(); i++) {
            RSVPDatabase.addData(invitedGuestList.get(i), eventName.getText(), eventLocation.getText(), eventDate.getText());
        }
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("EventPage.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }

    @FXML
    public void initialize() {
        firstname.setCellValueFactory(new PropertyValueFactory<Guest, String>("firstName"));
        lastname.setCellValueFactory(new PropertyValueFactory<Guest, String>("lastName"));
        accessCode.setCellValueFactory(new PropertyValueFactory<Guest, String>("accessCode"));
        email.setCellValueFactory(new PropertyValueFactory<Guest, String>("email"));
        phoneNumber.setCellValueFactory(new PropertyValueFactory<Guest, String>("phoneNumber"));
        guestLists.setItems(getGuestListData());
        invitedGuest.setCellValueFactory(new PropertyValueFactory<Guest, String>("accessCode"));
        invitedGuestTable.setItems(guestListToReturn);
    }
    
    @FXML
    private ObservableList<Guest> getGuestListData() {
        List<Guest> guestListToReturn = new ArrayList<>();
        try {
            Connection con = DriverManager.getConnection("jdbc:sqlite:Guest.db");
            ResultSet rs = con.createStatement().executeQuery("SELECT * FROM GUEST");
            
            while(rs.next()) {
                guestListToReturn.add(new Guest(rs.getString("firstName"), rs.getString("lastName"), 
                        rs.getString("accessCode"), rs.getString("email"), rs.getString("phoneNumber")));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
       return FXCollections.observableArrayList(guestListToReturn);
    }

}

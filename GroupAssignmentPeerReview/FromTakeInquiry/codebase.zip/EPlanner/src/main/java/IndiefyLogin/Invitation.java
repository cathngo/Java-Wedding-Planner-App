package IndiefyLogin;

public class Invitation {
    private String start;
    private String instructions;
    private String colour;
    
    public Invitation() {
    }

    public Invitation(String start, String instructions, String colour) {
        this.start = start;
        this.instructions = instructions;
        this.colour = colour;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public void setInstructions(String instructions) {
        this.instructions = instructions;
    }
    
    public void setColour(String colour) {
        this.colour = colour;
    }

    public String getStart() {
        return start;
    }

    public String getInstructions() {
        return instructions;
    }
    
    public String getColour() {
        return colour;
    }
}

package IndiefyLogin;

import static IndiefyLogin.EventDatabase.sharedConnection;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;

public class GuestDatabase {
   
    private static final String TABLE_NAME_FOR_EPLANNER = "guest";
    public static Connection sharedConnection;
    
    private static boolean openConnection() {
        boolean wasThisMethodSuccessful = false;
        try {
            GuestDatabase.sharedConnection = DriverManager.getConnection("jdbc:sqlite:Guest.db");
            wasThisMethodSuccessful = true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    }
    
    private static boolean closeConnection() {
        boolean wasThisMethodSuccessful = false;
        try {
            sharedConnection.close();
            wasThisMethodSuccessful = true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    }
    
    private static boolean createGuestTable() {
        boolean wasThisMethodSuccessful = false;
        try {
            GuestDatabase.openConnection();
            String createTableSql = "CREATE TABLE " + GuestDatabase.TABLE_NAME_FOR_EPLANNER + " ("
                    + "guest_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + "firstName TEXT, "
                    + "lastName TEXT, "
                    + "accessCode TEXT, "
                    + "email TEXT, "
                    + "phoneNumber TEXT) ";
            Statement smt = sharedConnection.createStatement();
            wasThisMethodSuccessful = smt.execute(createTableSql);
            GuestDatabase.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    }
    
    public static boolean setupGuestDatabaseOnFirstRun() {
        boolean wasThisMethodSuccessful = false;
        try {
            GuestDatabase.openConnection();
            DatabaseMetaData dbmd = GuestDatabase.sharedConnection.getMetaData();
            ResultSet rs = dbmd.getTables(null, null, GuestDatabase.TABLE_NAME_FOR_EPLANNER, null);
            boolean needToSetupDatabase = false;
            if (!rs.next()) {
                needToSetupDatabase = true;
            }
            GuestDatabase.closeConnection();
            if (needToSetupDatabase) {
                boolean createdTableSuccessfully = GuestDatabase.createGuestTable();
                wasThisMethodSuccessful = (createdTableSuccessfully);
            } else {
                wasThisMethodSuccessful = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            
        } finally {
            return wasThisMethodSuccessful;
        }
    }
    
    public static Guest fetchGuest(String accessCode) {
        Guest preparedReturn = null;
        try {
            GuestDatabase.openConnection();
            String sqlString = "SELECT * FROM " + GuestDatabase.TABLE_NAME_FOR_EPLANNER
                    + " WHERE accessCode = ?";
            PreparedStatement psmt = sharedConnection.prepareStatement(sqlString);
            psmt.setString(1, accessCode);
            ResultSet rs = psmt.executeQuery();
            while (rs.next()) {
                preparedReturn = new Guest(rs.getString("firstName"), rs.getString("lastName"), 
                        rs.getString("accessCode"), rs.getString("email"), rs.getString("phoneNumber"));
            }
            GuestDatabase.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return preparedReturn;
        }
    }
    
    public static void addData(String firstName, String lastName, String accessCode, String email, String phoneNumber) {
        try {
            GuestDatabase.openConnection();
            String sqlString = "INSERT INTO " + GuestDatabase.TABLE_NAME_FOR_EPLANNER
                    + " (firstName, lastName, accessCode, email, phoneNumber)"
                    + " VALUES (?, ?, ?, ?, ?)";
            PreparedStatement psmt = sharedConnection.prepareStatement(sqlString);
            psmt.setString(1, firstName);
            psmt.setString(2, lastName);
            psmt.setString(3, accessCode);
            psmt.setString(4, email);
            psmt.setString(5, phoneNumber);
            psmt.execute();
            GuestDatabase.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public static void deleteData(String firstName, String lastName, String accessCode, String email, String phoneNumber) {
        try{
            GuestDatabase.openConnection();
            String sqlString = "DELETE FROM " + GuestDatabase.TABLE_NAME_FOR_EPLANNER
                    + " WHERE firstName = ? AND lastName = ? AND accessCode = ? AND email = ? AND phoneNumber = ?";
            PreparedStatement psmt = sharedConnection.prepareStatement(sqlString);
            psmt.setString(1, firstName);
            psmt.setString(2, lastName);
            psmt.setString(3, accessCode);
            psmt.setString(4, email);
            psmt.setString(5, phoneNumber);
            psmt.execute();
            GuestDatabase.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public static void editData(String firstName, String lastName, String accessCode, String email, String phoneNumber) {
        try{
            GuestDatabase.openConnection();
            String sqlString = "UPDATE " + GuestDatabase.TABLE_NAME_FOR_EPLANNER
                    + " SET firstName = ?, lastName = ?, accessCode = ?, email = ?, phoneNumber = ?"
                    + " WHERE firstName = ? AND lastName = ? AND accessCode = ? AND email = ? AND phoneNumber = ?";
            PreparedStatement psmt = sharedConnection.prepareStatement(sqlString);
            psmt.setString(1, firstName);
            psmt.setString(2, lastName);
            psmt.setString(3, accessCode);
            psmt.setString(4, email);
            psmt.setString(5, phoneNumber);
            psmt.setString(6, GuestListPageController.selectedGuest.get(0));
            psmt.setString(7, GuestListPageController.selectedGuest.get(1));
            psmt.setString(8, GuestListPageController.selectedGuest.get(2));
            psmt.setString(9, GuestListPageController.selectedGuest.get(3));
            psmt.setString(10, GuestListPageController.selectedGuest.get(4));
            psmt.execute();
            GuestDatabase.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
        
}

package IndiefyLogin;

import java.io.IOException;
import java.util.Random;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class CreateGuestController {

    @FXML
    private TextField lastname1;

    @FXML
    private TextField firstname1;

    @FXML
    private Button cancel;

    @FXML
    private TextField phoneNumber1;

    @FXML
    private TextField email1;
    
    @FXML
    private TextField lastname2;

    @FXML
    private TextField firstname2;
    
    @FXML
    private TextField phoneNumber2;

    @FXML
    private TextField email2;
    
    @FXML
    private TextField lastname3;

    @FXML
    private TextField firstname3;
    
    @FXML
    private TextField phoneNumber3;

    @FXML
    private TextField email3;
    
    @FXML
    private TextField lastname4;

    @FXML
    private TextField firstname4;
    
    @FXML
    private TextField phoneNumber4;

    @FXML
    private TextField email4;
    
    @FXML
    private TextField lastname5;

    @FXML
    private TextField firstname5;
    
    @FXML
    private TextField phoneNumber5;

    @FXML
    private TextField email5;
    
    @FXML
    private TextField lastname6;

    @FXML
    private TextField firstname6;
    
    @FXML
    private TextField phoneNumber6;

    @FXML
    private TextField email6;
    
    @FXML
    private TextField lastname7;

    @FXML
    private TextField firstname7;
    
    @FXML
    private TextField phoneNumber7;

    @FXML
    private TextField email7;
    
    @FXML
    private TextField lastname8;

    @FXML
    private TextField firstname8;
    
    @FXML
    private TextField phoneNumber8;

    @FXML
    private TextField email8;
    
    @FXML
    private TextField lastname9;

    @FXML
    private TextField firstname9;
    
    @FXML
    private TextField phoneNumber9;

    @FXML
    private TextField email9;
    
    @FXML
    private TextField lastname10;

    @FXML
    private TextField firstname10;
    
    @FXML
    private TextField phoneNumber10;

    @FXML
    private TextField email10;

    @FXML
    private Button addButton;

    @FXML
    private Button eventButton;

    @FXML
    private Button logout;
    
    @FXML
    private Button about;
    
    @FXML
    private void handleAboutUsButton(ActionEvent event) throws IOException {
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("AboutUs.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    private void handleEventButton(ActionEvent event) throws IOException {
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("EventPage.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    private void handleLogoutButton(ActionEvent event) throws IOException {
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("LoginPage.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    private void handleCancelButton(ActionEvent event) throws IOException {
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("GuestListPage.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    Random r = new Random();
    
    @FXML
    private void handleAddButton(ActionEvent event) throws IOException {
        GuestDatabase.addData(firstname1.getText(), lastname1.getText(), 
                (((firstname1.getText().concat(lastname1.getText())).replace(" ", "")).replace("'", "")).concat(String.format("%04d", r.nextInt(10000))), 
                        email1.getText(), phoneNumber1.getText());
        if(firstname2.getText() == null || firstname2.getText().trim().isEmpty()) {
        } else {
        GuestDatabase.addData(firstname2.getText(), lastname2.getText(), 
                (((firstname2.getText().concat(lastname2.getText())).replace(" ", "")).replace("'", "")).concat(String.format("%04d", r.nextInt(10000))), 
                        email2.getText(), phoneNumber2.getText());   
        }
        if(firstname3.getText() == null || firstname3.getText().trim().isEmpty()) {
        } else {
        GuestDatabase.addData(firstname3.getText(), lastname3.getText(), 
                (((firstname3.getText().concat(lastname3.getText())).replace(" ", "")).replace("'", "")).concat(String.format("%04d", r.nextInt(10000))), 
                        email3.getText(), phoneNumber3.getText());
        }
        if(firstname4.getText() == null || firstname4.getText().trim().isEmpty()) {
        } else {
        GuestDatabase.addData(firstname4.getText(), lastname4.getText(), 
                (((firstname4.getText().concat(lastname4.getText())).replace(" ", "")).replace("'", "")).concat(String.format("%04d", r.nextInt(10000))), 
                        email4.getText(), phoneNumber4.getText());
        }
        if(firstname5.getText() == null || firstname5.getText().trim().isEmpty()) {
        } else {
        GuestDatabase.addData(firstname5.getText(), lastname5.getText(), 
                (((firstname5.getText().concat(lastname5.getText())).replace(" ", "")).replace("'", "")).concat(String.format("%04d", r.nextInt(10000))), 
                        email5.getText(), phoneNumber5.getText());
        }
        if(firstname6.getText() == null || firstname6.getText().trim().isEmpty()) {
        } else {
        GuestDatabase.addData(firstname6.getText(), lastname6.getText(), 
                (((firstname6.getText().concat(lastname6.getText())).replace(" ", "")).replace("'", "")).concat(String.format("%04d", r.nextInt(10000))), 
                        email6.getText(), phoneNumber6.getText());
        }
        if(firstname7.getText() == null || firstname7.getText().trim().isEmpty()) {
        } else {
        GuestDatabase.addData(firstname7.getText(), lastname7.getText(), 
                (((firstname7.getText().concat(lastname7.getText())).replace(" ", "")).replace("'", "")).concat(String.format("%04d", r.nextInt(10000))), 
                        email7.getText(), phoneNumber7.getText());
        }
        if(firstname8.getText() == null || firstname8.getText().trim().isEmpty()) {
        } else {
        GuestDatabase.addData(firstname8.getText(), lastname8.getText(), 
                (((firstname8.getText().concat(lastname8.getText())).replace(" ", "")).replace("'", "")).concat(String.format("%04d", r.nextInt(10000))), 
                        email8.getText(), phoneNumber8.getText());
        }
        if(firstname9.getText() == null || firstname9.getText().trim().isEmpty()) {
        } else {
        GuestDatabase.addData(firstname9.getText(), lastname9.getText(), 
                (((firstname9.getText().concat(lastname9.getText())).replace(" ", "")).replace("'", "")).concat(String.format("%04d", r.nextInt(10000))), 
                        email9.getText(), phoneNumber9.getText());
        }
        if(firstname10.getText() == null || firstname10.getText().trim().isEmpty()) {
        } else {
        GuestDatabase.addData(firstname10.getText(), lastname10.getText(), 
                (((firstname10.getText().concat(lastname10.getText())).replace(" ", "")).replace("'", "")).concat(String.format("%04d", r.nextInt(10000))), 
                        email10.getText(), phoneNumber10.getText());
        }
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("GuestListPage.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }

    @FXML
    public void initialize() {
    }

}
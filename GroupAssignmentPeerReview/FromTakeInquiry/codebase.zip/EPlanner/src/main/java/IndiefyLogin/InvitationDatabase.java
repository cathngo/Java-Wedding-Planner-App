package IndiefyLogin;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class InvitationDatabase {
    private static final String TABLE_NAME_FOR_EPLANNER = "invitation";
    public static Connection sharedConnection;
    
    private static boolean openConnection() {
        boolean wasThisMethodSuccessful = false;
        try {
            EventDatabase.sharedConnection = DriverManager.getConnection("jdbc:sqlite:Invitation.db");
            wasThisMethodSuccessful = true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    }
    
    private static boolean closeConnection() {
        boolean wasThisMethodSuccessful = false;
        try {
            sharedConnection.close();
            wasThisMethodSuccessful = true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    }
    
    private static boolean createInvitationTable() {
        boolean wasThisMethodSuccessful = false;
        try {
            InvitationDatabase.openConnection();
            String createTableSql = "CREATE TABLE " + InvitationDatabase.TABLE_NAME_FOR_EPLANNER + " ("
                    + "invitation_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + "event_id INTEGER, "
                    + "guest_id INTEGER, "
                    + "admin_id INTEGER, "
                    + "start TEXT, "
                    + "instructions TEXT, "
                    + "colour TEXT, "
                    + "CONSTRAINT fk_invitation_event FOREIGN KEY (event_id) " 
                    + "REFERENCES event(event_id), "
                    + "CONSTRAINT fk_invitation_guest FOREIGN KEY (guest_id) " 
                    + "REFERENCES guest(guest_id), "
                    + "CONSTRAINT fk_invitation_admin FOREIGN KEY (admin_id) " 
                    + "REFERENCES admin(admin_id))";
            Statement smt = sharedConnection.createStatement();
            wasThisMethodSuccessful = smt.execute(createTableSql);
            InvitationDatabase.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    }
    
        
    public static boolean setupInvitationDatabaseOnFirstRun() {
        boolean wasThisMethodSuccessful = false;
        try {
            InvitationDatabase.openConnection();
            DatabaseMetaData dbmd = InvitationDatabase.sharedConnection.getMetaData();
            ResultSet rs = dbmd.getTables(null, null, InvitationDatabase.TABLE_NAME_FOR_EPLANNER, null);
            boolean needToSetupDatabase = false;
            if (!rs.next()) {
                needToSetupDatabase = true;
            }
            InvitationDatabase.closeConnection();
            if (needToSetupDatabase) {
                boolean createdTableSuccessfully = InvitationDatabase.createInvitationTable();
                wasThisMethodSuccessful = (createdTableSuccessfully);
            } else {
                wasThisMethodSuccessful = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    }
        
    public static Invitation fetchInvitation() {
        Invitation preparedReturn = null;
        try {
            InvitationDatabase.openConnection();
            String sqlString = "SELECT * FROM " + InvitationDatabase.TABLE_NAME_FOR_EPLANNER;
            PreparedStatement psmt = sharedConnection.prepareStatement(sqlString);
            ResultSet rs = psmt.executeQuery();
            while (rs.next()) {
                preparedReturn = new Invitation(rs.getString("start"), 
                        rs.getString("instructions"), rs.getString("colour"));
            }
            InvitationDatabase.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return preparedReturn;
        }
    }
    
    public static void addData(String start, String instructions, String colour) {
        try {
            InvitationDatabase.openConnection();
            String sqlString = "INSERT INTO " + InvitationDatabase.TABLE_NAME_FOR_EPLANNER
                    + " (start, instructions, colour)"
                    + " VALUES (?, ?, ?)";
            PreparedStatement psmt = sharedConnection.prepareStatement(sqlString);
            psmt.setString(1, start);
            psmt.setString(2, instructions);
            psmt.setString(3, colour);
            psmt.execute();
            InvitationDatabase.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
        }
    }
    
    public static void deleteData(String start, String instructions, String colour) {
        try{
            InvitationDatabase.openConnection();
            String sqlString = "DELETE FROM " + InvitationDatabase.TABLE_NAME_FOR_EPLANNER
                    + " WHERE start = ? AND instructions = ? AND colour = ?";
            PreparedStatement psmt = sharedConnection.prepareStatement(sqlString);
            psmt.setString(1, start);
            psmt.setString(2, instructions);
            psmt.setString(3, colour);
            psmt.execute();
            InvitationDatabase.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public static void editData(String start, String instructions, String colour) {
        try{
            InvitationDatabase.openConnection();
            String sqlString = "UPDATE " + InvitationDatabase.TABLE_NAME_FOR_EPLANNER
                    + " SET start = ?, instructions = ?, colour = ?"
                    + " WHERE start = ? AND instructions = ? AND colour = ?";
            PreparedStatement psmt = sharedConnection.prepareStatement(sqlString);
            psmt.setString(1, start);
            psmt.setString(2, instructions);
            psmt.setString(3, colour);
            //psmt.setString(4, EventPageController.selectedEvent.get(0));
            //psmt.setString(5, EventPageController.selectedEvent.get(1));
            //psmt.setString(6, EventPageController.selectedEvent.get(2));
            psmt.execute();
            InvitationDatabase.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }    
}

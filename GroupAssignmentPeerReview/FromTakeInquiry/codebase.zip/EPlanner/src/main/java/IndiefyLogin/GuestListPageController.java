package IndiefyLogin;

import static IndiefyLogin.EventPageController.selectedEvent;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class GuestListPageController {
    
    @FXML
    private Button logout;
    
    @FXML
    private Button add;
    
    @FXML
    private Button eventsButton;
    
    @FXML
    private Button about;
    
    @FXML
    private Button deleteGuest;

    @FXML
    private Button editGuest;
    
    @FXML
    private TableView<Guest> guestList;

    @FXML
    private TableColumn<Guest, String> accessCode;

    @FXML
    private TableColumn<Guest, String> phoneNumber;

    @FXML
    private TableColumn<Guest, String> email;
    
    @FXML
    private TableColumn<Guest, String> firstname;

    @FXML
    private TableColumn<Guest, String> lastname;
    
    @FXML
    private void handleAboutUsButton(ActionEvent event) throws IOException {
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("AboutUs.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    private void handleLogoutButton(ActionEvent event) throws IOException {
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("LoginPage.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    private void handleEventPageButton(ActionEvent event) throws IOException {
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("EventPage.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    private void handleAddButton(ActionEvent event) throws IOException {
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("CreateGuest.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    public static ArrayList<String> selectedGuest = new ArrayList<String>();
    
    @FXML
    public void mouseEvent(MouseEvent event) {
        editGuest.setDisable(false);
        deleteGuest.setDisable(false);
    }
    
    @FXML
    private void handleEditButton(ActionEvent event) throws IOException {
        selectedGuest.add(guestList.getSelectionModel().getSelectedItem().getFirstName());
        selectedGuest.add(guestList.getSelectionModel().getSelectedItem().getLastName());
        selectedGuest.add(guestList.getSelectionModel().getSelectedItem().getAccessCode());
        selectedGuest.add(guestList.getSelectionModel().getSelectedItem().getEmail());
        selectedGuest.add(guestList.getSelectionModel().getSelectedItem().getPhoneNumber());
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("EditGuest.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    private void handleDeleteButton(ActionEvent event) throws IOException {
        selectedGuest.add(guestList.getSelectionModel().getSelectedItem().getFirstName());
        selectedGuest.add(guestList.getSelectionModel().getSelectedItem().getLastName());
        selectedGuest.add(guestList.getSelectionModel().getSelectedItem().getAccessCode());
        selectedGuest.add(guestList.getSelectionModel().getSelectedItem().getEmail());
        selectedGuest.add(guestList.getSelectionModel().getSelectedItem().getPhoneNumber());
        GuestDatabase.deleteData(selectedGuest.get(0), selectedGuest.get(1), selectedGuest.get(2), selectedGuest.get(3), selectedGuest.get(4));
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("GuestListPage.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
        selectedGuest.clear();
    }
    
    @FXML
    public void initialize() {
        firstname.setCellValueFactory(new PropertyValueFactory<Guest, String>("firstName"));
        lastname.setCellValueFactory(new PropertyValueFactory<Guest, String>("lastName"));
        accessCode.setCellValueFactory(new PropertyValueFactory<Guest, String>("accessCode"));
        email.setCellValueFactory(new PropertyValueFactory<Guest, String>("email"));
        phoneNumber.setCellValueFactory(new PropertyValueFactory<Guest, String>("phoneNumber"));
        guestList.setItems(getGuestListData());
        editGuest.setDisable(true);
        deleteGuest.setDisable(true);
    }
    
    @FXML
    private ObservableList<Guest> getGuestListData() {
        List<Guest> guestListToReturn = new ArrayList<>();
        try {
            Connection con = DriverManager.getConnection("jdbc:sqlite:Guest.db");
            ResultSet rs = con.createStatement().executeQuery("SELECT * FROM GUEST");
            
            while(rs.next()) {
                guestListToReturn.add(new Guest(rs.getString("firstName"), rs.getString("lastName"), 
                        rs.getString("accessCode"), rs.getString("email"), rs.getString("phoneNumber")));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
       return FXCollections.observableArrayList(guestListToReturn);
    }

}

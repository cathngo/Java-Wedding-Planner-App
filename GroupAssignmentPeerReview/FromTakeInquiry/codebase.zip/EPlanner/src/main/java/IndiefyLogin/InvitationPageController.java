package IndiefyLogin;

import static IndiefyLogin.EventPageController.selectedEvent;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class InvitationPageController {
    
    @FXML
    private Button logout;
    
    @FXML
    private Button about;
    
    @FXML
    private Button respondToEvent;
    
    @FXML
    public TableView<Event> eventLists;

    @FXML
    private TableColumn<Event, String> eventName;

    @FXML
    private TableColumn<Event, String> eventLocation;

    @FXML
    private TableColumn<Event, String> eventDate;
    
    @FXML
    public static ArrayList<String> selectedGuestEvent = new ArrayList<String>();
    
    @FXML
    private void handleAboutUsButton(ActionEvent event) throws IOException {
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("AboutUsGuest.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    private void handleRespondToEventButton(ActionEvent event) throws IOException {
        selectedGuestEvent.add(eventLists.getSelectionModel().getSelectedItem().getName());
        selectedGuestEvent.add(eventLists.getSelectionModel().getSelectedItem().getLocation());
        selectedGuestEvent.add(eventLists.getSelectionModel().getSelectedItem().getDate());
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("RespondToEvent.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    private void handleLogoutButton(ActionEvent event) throws IOException {
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("LoginPage.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    public void mouseEvent(MouseEvent event) {
        respondToEvent.setDisable(false);
    }

    @FXML
    public void initialize() {
        eventName.setCellValueFactory(new PropertyValueFactory<Event, String>("name"));
        eventLocation.setCellValueFactory(new PropertyValueFactory<Event, String>("location"));
        eventDate.setCellValueFactory(new PropertyValueFactory<Event, String>("date"));
        eventLists.setItems(getEventListData());
        respondToEvent.setDisable(true);
    }
    
    @FXML
    private ObservableList<Event> getEventListData() {
        List<Event> eventListToReturn = new ArrayList<>();
        try {
            Connection con = DriverManager.getConnection("jdbc:sqlite:Event.db");
            ResultSet rs = con.createStatement().executeQuery("SELECT * FROM EVENT");
            while(rs.next()) {
                eventListToReturn.add(new Event(rs.getString("name"), rs.getString("location"), rs.getString("date")));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
       return FXCollections.observableArrayList(eventListToReturn);
    }

}

package IndiefyLogin;

import static IndiefyLogin.EventDatabase.sharedConnection;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class RSVPDatabase {
    
    private static final String TABLE_NAME_FOR_EPLANNER = "RSVP";
    public static Connection sharedConnection;
    
    private static boolean openConnection() {
        boolean wasThisMethodSuccessful = false;
        try {
            RSVPDatabase.sharedConnection = DriverManager.getConnection("jdbc:sqlite:RSVP.db");
            wasThisMethodSuccessful = true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    }
    
    private static boolean closeConnection() {
        boolean wasThisMethodSuccessful = false;
        try {
            sharedConnection.close();
            wasThisMethodSuccessful = true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    }
    
    private static boolean createRSVPTable() {
        boolean wasThisMethodSuccessful = false;
        try {
            RSVPDatabase.openConnection();
            String createTableSql = "CREATE TABLE " + RSVPDatabase.TABLE_NAME_FOR_EPLANNER + " ("
                    + "RSVP_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + "guest_access_code TEXT, "
                    + "event_name TEXT, "
                    + "event_location TEXT, "
                    + "event_date TEXT, "
                    + "decision TEXT, "
                    + "dietary_requirements TEXT) ";
            Statement smt = sharedConnection.createStatement();
            wasThisMethodSuccessful = smt.execute(createTableSql);
            RSVPDatabase.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    }
    
    public static boolean setupRSVPDatabaseOnFirstRun() {
        boolean wasThisMethodSuccessful = false;
        try {
            RSVPDatabase.openConnection();
            DatabaseMetaData dbmd = RSVPDatabase.sharedConnection.getMetaData();
            ResultSet rs = dbmd.getTables(null, null, RSVPDatabase.TABLE_NAME_FOR_EPLANNER, null);
            boolean needToSetupDatabase = false;
            if (!rs.next()) {
                needToSetupDatabase = true;
            }
            RSVPDatabase.closeConnection();
            if (needToSetupDatabase) {
                boolean createdTableSuccessfully = RSVPDatabase.createRSVPTable();
                wasThisMethodSuccessful = (createdTableSuccessfully);
            } else {
                wasThisMethodSuccessful = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    }
        
    public static RSVP fetchRSVP() {
        RSVP preparedReturn = null;
        try {
            RSVPDatabase.openConnection();
            String sqlString = "SELECT * FROM " + RSVPDatabase.TABLE_NAME_FOR_EPLANNER;
            PreparedStatement psmt = sharedConnection.prepareStatement(sqlString);
            ResultSet rs = psmt.executeQuery();
            while (rs.next()) {
                preparedReturn = new RSVP(rs.getString("guest_access_code"), 
                        rs.getString("event_name"), rs.getString("event_location"), rs.getString("event_date"), 
                        rs.getString("decision"), rs.getString("dietary_requirements"));
            }
            RSVPDatabase.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return preparedReturn;
        }
    }
    
    public static void addData(String guestAccessCode, String eventName, String eventLocation, String eventDate) {
        try {
            RSVPDatabase.openConnection();
            String sqlString = "INSERT INTO " + RSVPDatabase.TABLE_NAME_FOR_EPLANNER
                    + " (guest_access_code, event_name, event_location, event_date)"
                    + " VALUES (?, ?, ?, ?)";
            PreparedStatement psmt = sharedConnection.prepareStatement(sqlString);
            psmt.setString(1, guestAccessCode);
            psmt.setString(2, eventName);
            psmt.setString(3, eventLocation);
            psmt.setString(4, eventDate);
            psmt.execute();
            RSVPDatabase.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
        }
    }
    
    public static void addDecision(String guestAccessCode, String eventName, String eventLocation, String eventDate, 
            String decision, String dietaryRequirements) {
        try {
            String sqlString = "UPDATE " + RSVPDatabase.TABLE_NAME_FOR_EPLANNER
                    + " SET decision = ?, dietary_requirements = ?"
                    + " WHERE guest_access_code = ? AND event_name = ? AND event_location = ? AND event_date";
            PreparedStatement psmt = sharedConnection.prepareStatement(sqlString);
            psmt.setString(1, decision);
            psmt.setString(2, dietaryRequirements);
            psmt.setString(3, guestAccessCode);
            psmt.setString(4, eventName);
            psmt.setString(5, eventLocation);
            psmt.setString(6, eventDate);
            psmt.execute();
            RSVPDatabase.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
        }
    }
   
}

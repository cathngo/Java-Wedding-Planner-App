package IndiefyLogin;

import static IndiefyLogin.EventPageController.selectedEvent;
import java.io.IOException;
import java.util.Random;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class EditGuestController {

    @FXML
    private TextField lastname;

    @FXML
    private TextField firstname;

    @FXML
    private Button cancel;

    @FXML
    private TextField phoneNumber;

    @FXML
    private TextField email;

    @FXML
    private Button addButton;

    @FXML
    private Button eventButton;

    @FXML
    private Button logout;
    
    @FXML
    private Button about;
    
    @FXML
    private void handleAboutUsButton(ActionEvent event) throws IOException {
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("AboutUs.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    private void handleEventButton(ActionEvent event) throws IOException {
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("EventPage.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    private void handleLogoutButton(ActionEvent event) throws IOException {
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("LoginPage.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    private void handleCancelButton(ActionEvent event) throws IOException {
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("GuestListPage.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
        GuestListPageController.selectedGuest.clear();
    }
    
    @FXML
    Random r = new Random();
    
    @FXML
    private void handleEditButton(ActionEvent event) throws IOException {
        GuestDatabase.editData(firstname.getText(), lastname.getText(), 
                (((firstname.getText().concat(lastname.getText())).replace(" ", "")).replace("'", "")).concat(String.format("%04d", r.nextInt(10000))),
                email.getText(), phoneNumber.getText());
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("GuestListPage.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
        GuestListPageController.selectedGuest.clear();
    }

    @FXML
    public void initialize() {
        firstname.setText(GuestListPageController.selectedGuest.get(0));
        lastname.setText(GuestListPageController.selectedGuest.get(1));
        email.setText(GuestListPageController.selectedGuest.get(3));
        phoneNumber.setText(GuestListPageController.selectedGuest.get(4));
    }

}

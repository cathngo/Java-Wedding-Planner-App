package IndiefyLogin;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class EventPageController {
    
    @FXML
    private Button createButton;
    
    @FXML
    private Button logout;
    
    @FXML
    private Button guestsButton;
    
    @FXML
    private Button about;
    
    @FXML
    private Button editEvent;
    
    @FXML
    private Button deleteEvent;
    
    @FXML
    private Button pdf;
    
    @FXML
    public TableView<Event> eventLists;

    @FXML
    private TableColumn<Event, String> eventName;

    @FXML
    private TableColumn<Event, String> eventLocation;

    @FXML
    private TableColumn<Event, String> eventDate;
    
    @FXML
    private void handleAboutUsButton(ActionEvent event) throws IOException {
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("AboutUs.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    private void handleLogoutButton(ActionEvent event) throws IOException {
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("LoginPage.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    private void handleGuestsButton(ActionEvent event) throws IOException {
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("GuestListPage.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    private void handleCreateButton(ActionEvent event) throws IOException {
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("CreateEvent.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    public static ArrayList<String> selectedEvent = new ArrayList<String>();
    
    @FXML
    private void handleEditButton(ActionEvent event) throws IOException {
        selectedEvent.add(eventLists.getSelectionModel().getSelectedItem().getName());
        selectedEvent.add(eventLists.getSelectionModel().getSelectedItem().getLocation());
        selectedEvent.add(eventLists.getSelectionModel().getSelectedItem().getDate());
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("EditEvent.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    private void handleDeleteButton(ActionEvent event) throws IOException {
        selectedEvent.add(eventLists.getSelectionModel().getSelectedItem().getName());
        selectedEvent.add(eventLists.getSelectionModel().getSelectedItem().getLocation());
        selectedEvent.add(eventLists.getSelectionModel().getSelectedItem().getDate());
        EventDatabase.deleteData(selectedEvent.get(0), selectedEvent.get(1), selectedEvent.get(2));
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("EventPage.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
        selectedEvent.clear();
    }
    
    /*@FXML
    private void handlePDFButton(ActionEvent event) throws IOException {
        PDDocument document = new PDDocument();
        PDPage page = new PDPage();
        document.addPage(page);
        document.save("C:/EPlanner/Invitation.pdf");
        document.close();
    }*/
    
    @FXML
    public void mouseEvent(MouseEvent event) {
        editEvent.setDisable(false);
        deleteEvent.setDisable(false);
        pdf.setDisable(false);
    }

    @FXML
    public void initialize() {
        eventName.setCellValueFactory(new PropertyValueFactory<Event, String>("name"));
        eventLocation.setCellValueFactory(new PropertyValueFactory<Event, String>("location"));
        eventDate.setCellValueFactory(new PropertyValueFactory<Event, String>("date"));
        eventLists.setItems(getEventListData());
        editEvent.setDisable(true);
        deleteEvent.setDisable(true);
        pdf.setDisable(true);
    }
    
    @FXML
    private ObservableList<Event> getEventListData() {
        List<Event> eventListToReturn = new ArrayList<>();
        try {
            Connection con = DriverManager.getConnection("jdbc:sqlite:Event.db");
            ResultSet rs = con.createStatement().executeQuery("SELECT * FROM EVENT");
            while(rs.next()) {
                eventListToReturn.add(new Event(rs.getString("name"), rs.getString("location"), rs.getString("date")));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
       return FXCollections.observableArrayList(eventListToReturn);
    }

}

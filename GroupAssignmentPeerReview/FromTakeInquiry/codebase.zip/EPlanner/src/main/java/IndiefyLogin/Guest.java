package IndiefyLogin;

import java.util.Random;

public class Guest extends User {
    
    private String accessCode;
    private String email;
    private String phoneNumber;

    public Guest(String firstName, String lastName, String accessCode, String email, String phoneNumber) {
        super(firstName, lastName);
        this.accessCode = accessCode;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }

    public void setAccessCode(String accessCode) {
        this.accessCode = accessCode;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getAccessCode() {
        return accessCode;
    }

    public String getEmail() {
        return email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }
    
}
package IndiefyLogin;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class EventRunsheetDatabase {
    private static final String TABLE_NAME_FOR_EPLANNER = "eventrunsheet";
    public static Connection sharedConnection;
    
    private static boolean openConnection() {
        boolean wasThisMethodSuccessful = false;
        try {
            EventDatabase.sharedConnection = DriverManager.getConnection("jdbc:sqlite:EventRunsheet.db");
            wasThisMethodSuccessful = true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    }
    
    private static boolean closeConnection() {
        boolean wasThisMethodSuccessful = false;
        try {
            sharedConnection.close();
            wasThisMethodSuccessful = true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    }
    
        private static boolean createEventRunsheetTable() {
        boolean wasThisMethodSuccessful = false;
        try {
            EventRunsheetDatabase.openConnection();
            String createTableSql = "CREATE TABLE " + EventRunsheetDatabase.TABLE_NAME_FOR_EPLANNER + " ("
                    + "runsheet_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + "event_id TEXT, "
                    + "item_time TEXT, "
                    + "item TEXT, "
                    + "CONSTRAINT fk_event FOREIGN KEY (event_id) " 
                    + "REFERENCES event(event_id)) ";
            Statement smt = sharedConnection.createStatement();
            wasThisMethodSuccessful = smt.execute(createTableSql);
            EventRunsheetDatabase.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    }
    
    public static boolean setupEventRunsheetDatabaseOnFirstRun() {
        boolean wasThisMethodSuccessful = false;
        try {
            EventRunsheetDatabase.openConnection();
            DatabaseMetaData dbmd = EventRunsheetDatabase.sharedConnection.getMetaData();
            ResultSet rs = dbmd.getTables(null, null, EventRunsheetDatabase.TABLE_NAME_FOR_EPLANNER, null);
            boolean needToSetupDatabase = false;
            if (!rs.next()) {
                needToSetupDatabase = true;
            }
            EventRunsheetDatabase.closeConnection();
            if (needToSetupDatabase) {
                boolean createdTableSuccessfully = EventRunsheetDatabase.createEventRunsheetTable();
                wasThisMethodSuccessful = (createdTableSuccessfully);
            } else {
                wasThisMethodSuccessful = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    }
    
    /*public static EventRunsheet fetchEventRunsheet() {
        EventRunsheet preparedReturn = null;
        try {
            EventRunsheetDatabase.openConnection();
            String sqlString = "SELECT * FROM " + EventRunsheetDatabase.TABLE_NAME_FOR_EPLANNER;
            PreparedStatement psmt = sharedConnection.prepareStatement(sqlString);
            ResultSet rs = psmt.executeQuery();
            while (rs.next()) {
                preparedReturn = new EventRunsheet(rs.getString("item_time"), 
                        rs.getString("item"));
            }
            EventRunsheetDatabase.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return preparedReturn;
        }
    }*/
    
    public static void addData(String itemTime, String item) {
        try {
            EventRunsheetDatabase.openConnection();
            String sqlString = "INSERT INTO " + EventRunsheetDatabase.TABLE_NAME_FOR_EPLANNER
                    + " (item_time, item)"
                    + " VALUES (?, ?)";
            PreparedStatement psmt = sharedConnection.prepareStatement(sqlString);
            psmt.setString(1, itemTime);
            psmt.setString(2, item);
            psmt.execute();
            EventRunsheetDatabase.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
        }
    }
    
    public static void deleteData(String itemTime, String item) {
        try{
            EventRunsheetDatabase.openConnection();
            String sqlString = "DELETE FROM " + EventRunsheetDatabase.TABLE_NAME_FOR_EPLANNER
                    + " WHERE item_time = ? AND item = ?";
            PreparedStatement psmt = sharedConnection.prepareStatement(sqlString);
            psmt.setString(1, itemTime);
            psmt.setString(2, item);
            psmt.execute();
            EventRunsheetDatabase.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public static void editData(String itemTime, String item) {
        try{
            EventRunsheetDatabase.openConnection();
            String sqlString = "UPDATE " + EventRunsheetDatabase.TABLE_NAME_FOR_EPLANNER
                    + " SET item_time = ?, item = ?"
                    + " WHERE item_time = ? AND item = ?";
            PreparedStatement psmt = sharedConnection.prepareStatement(sqlString);
            psmt.setString(1, itemTime);
            psmt.setString(2, item);
            //psmt.setString(3, EventRunsheetController.selectedRunsheet.get(0));
            //psmt.setString(4, EventRunsheetController.selectedRunsheet.get(1));
            psmt.execute();
            EventRunsheetDatabase.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }    
}

package au.edu.unsw.business.infs2605.fxstarterkit;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Music {

    private StringProperty album;
    private StringProperty artist;
    private StringProperty genre;
    private StringProperty year;

    public Music() {
        this("", "", "", "");
    }

    public Music(String album, String artist, String genre, String year) {
        this.album = new SimpleStringProperty(album);
        this.artist = new SimpleStringProperty(artist);
        this.genre = new SimpleStringProperty(genre);
        this.year = new SimpleStringProperty(year);
    }

    public StringProperty getAlbumProperty() {
        return album;
    }

    public void setAlbumProperty(StringProperty album) {
        this.album = album;
    }

    public StringProperty getArtistProperty() {
        return artist;
    }

    public void setArtistProperty(StringProperty artist) {
        this.artist = artist;
    }

    public StringProperty getGenreProperty() {
        return genre;
    }

    public void setGenreProperty(StringProperty genre) {
        this.genre = genre;
    }

    public StringProperty getYearProperty() {
        return year;
    }

    public void setYearProperty(StringProperty year) {
        this.year = year;
    }
}
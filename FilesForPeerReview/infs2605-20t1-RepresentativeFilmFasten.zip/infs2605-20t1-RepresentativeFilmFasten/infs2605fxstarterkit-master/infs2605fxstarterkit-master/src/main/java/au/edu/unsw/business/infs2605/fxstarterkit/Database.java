package au.edu.unsw.business.infs2605.fxstarterkit;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Database {
    
    
    public static Connection conn;
    
    public static void openConnection() {
        if (conn == null) {
            try {
                conn = DriverManager.getConnection("jdbc:sqlite:chinook.db");
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    public boolean tryLogin(String username, String password) {
        boolean loginSuccessful = false;
        
        try {
            Database.openConnection();
            String query = "SELECT * FROM login WHERE username = ? AND password = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                System.out.println("rs next");
                loginSuccessful = true;
            }
            rs.close();
               
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return loginSuccessful;
    }
    
    public static void createLoginTable() {

        PreparedStatement createLoginTable = null;
        PreparedStatement insertDemoData = null;
        ResultSet rs = null;
        openConnection();
        
        try {
            System.out.println("Checking LOGIN table ");
            DatabaseMetaData dbmd = conn.getMetaData();
            rs = dbmd.getTables(null, null, "LOGIN", null);
            
            if (!rs.next()) {
                createLoginTable = conn.prepareStatement("CREATE TABLE LOGIN (USERNAME VARCHAR(100), PASSWORD VARCHAR(100))");
                createLoginTable.execute();
                System.out.println("LOGIN table created");
                insertDemoData = conn.prepareStatement("INSERT INTO LOGIN(USERNAME,PASSWORD) "
                        + "VALUES ('Pretentious','Hipster')");
                insertDemoData.execute();

            } else {
                System.out.println("LOGIN table exists");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public ResultSet getResultSet(String sqlstatement) throws SQLException {
        openConnection();
        java.sql.Statement statement = conn.createStatement();
        ResultSet RS = statement.executeQuery(sqlstatement);
        return RS;
    }

    public static void createMusicTable() throws SQLException {
        openConnection();
        Statement st = conn.createStatement();
        String dropQuery = "DROP TABLE IF EXISTS musicList;";
        st.execute(dropQuery);
        String createQuery = "CREATE TABLE IF NOT EXISTS musicList"
                + "(album TEXT NOT NULL"
                + ", artist TEXT NOT NULL"
                + ", genre TEXT NOT NULL"
                + ", year TEXT NOT NULL"
                + ");";
        st.execute(createQuery);

        ArrayList<String> musicList = new ArrayList<>();
        musicList.add(
                "INSERT INTO musicList (album, artist, genre, year) "
                + "VALUES ('Feels', 'Animal Collective', 'Experimental Pop', '2005');"
        );

        musicList.add(
                "INSERT INTO musicList (album, artist, genre, year) "
                + "VALUES ('The Money Store', 'Death Grips', 'Experimental Hiphop', '2012');"
        );

        musicList.add(
                "INSERT INTO musicList (album, artist, genre, year) "
                + "VALUES ('No Now', 'Clarence Clarity', 'Experimental Pop', '2015');"
        );

        musicList.add(
                "INSERT INTO musicList (album, artist, genre, year) "
                + "VALUES ('Infest The Rats Nest', 'King Gizzard & The Lizard Wizard', 'Thrash Metal', '2019');"
        );

        for (String thisStatement : musicList) {
            st.execute(thisStatement);
        }
        st.close();
    }
}


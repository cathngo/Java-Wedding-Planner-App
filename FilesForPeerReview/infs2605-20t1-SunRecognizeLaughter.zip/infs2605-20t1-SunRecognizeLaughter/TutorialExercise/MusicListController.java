package IndiefyLogin;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.beans.property.StringProperty;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.Initializable;

public class MusicListController implements Initializable {
    
    @FXML
    public TableView<Music> musicTable;
    @FXML
    public TableColumn<Music, SimpleStringProperty> albumColumn;
    @FXML
    public TableColumn<Music, SimpleStringProperty> artistColumn;
    @FXML
    public TableColumn<Music, SimpleStringProperty> genreColumn;
    @FXML
    public TableColumn<Music, SimpleStringProperty> yearColumn;
    
    @FXML
    public Label albumLabel;
    @FXML
    public Label artistLabel;
    @FXML
    public Label genreLabel;
    @FXML
    public Label yearLabel;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Set the items that should be contained in the TableView
        albumColumn.setCellValueFactory(new PropertyValueFactory<>("Album"));
        artistColumn.setCellValueFactory(new PropertyValueFactory<>("Artist"));
        genreColumn.setCellValueFactory(new PropertyValueFactory<>("Genre"));
        yearColumn.setCellValueFactory(new PropertyValueFactory<>("Year"));
                
        //add your data to the table here.
        musicTable.setItems(getMusicListData);
    }

    ObservableList<Music> getMusicListData = FXCollections.observableArrayList(
            new Music("Feels", "Animal Collective", "Experimental Pop", "2005")
    );     
    
    //test
}
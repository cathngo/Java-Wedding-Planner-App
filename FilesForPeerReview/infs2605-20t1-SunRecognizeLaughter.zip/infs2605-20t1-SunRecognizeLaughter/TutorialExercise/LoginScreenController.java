/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IndiefyLogin;


import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;



/**
 *
 * @author jacob
 */
public class LoginScreenController {

    //Initiate JavaFX nodes (visual elements), how do we connect these variables to the FXML view?
    @FXML
    private TextField textFieldName;
    @FXML
    private TextField textFieldPass;
    @FXML
    private Label labelName;
    @FXML
    private Label labelPass;
    @FXML
    private Label titleIndiefy;
    @FXML
    private AnchorPane back;
    @FXML
    private Button loginButton;
    @FXML
    private Label loginStatus;
    @FXML
    private Button nextButton;
    // Initiate the database class

    /* What should happen when you click the login button?
       How do we connect this function to the FXML view? */
    private void handleLoginButtonAction() {
        String inputName = textFieldName.getText();
        String inputPass = textFieldPass.getText();
        Database attempt = new Database();
        
        if (attempt.tryLogin(inputName,inputPass)==true) {
          loginStatus.setText("Login Successful");// What should the user see when the login is successful?
        } else {
          loginStatus.setText("Login Unsuccessful");// What should the user see when the login is unsuccessful?
        }
    }
    @FXML
    private void switchToSecondary() throws IOException {
        App.setRoot("MusicList");
    }

 
    @FXML
    protected void initialize() {
        labelName.setText("Username");
        labelPass.setText("Password");
        loginStatus.setText("");
        
    }

}

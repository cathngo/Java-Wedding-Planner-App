/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IndiefyLogin;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Database {
    
   // private Connection conn;
   // private Statement st;
    private static Connection sharedConnection; 
    private static final String TABLE_NAME_FOR_INDIEFY = "Login";

    private static boolean openConnection() {
        boolean wasThisMethodSuccessful = false;
        try {
            Database.sharedConnection = DriverManager.getConnection("jdbc:sqlite:Login.db");
            wasThisMethodSuccessful = true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    }
    private static boolean closeConnection() {
        boolean wasThisMethodSuccessful = false;
        try {
            sharedConnection.close();
            wasThisMethodSuccessful = true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    }
    private static boolean createTheOnlyTableWeNeed() {
        boolean wasThisMethodSuccessful = false;
        try {
            Database.openConnection();
            String createTableSql = "CREATE TABLE " + Database.TABLE_NAME_FOR_INDIEFY + " ("
                    +  "username TEXT PRIMARY KEY, "
                    + "password TEXT NOT NULL)";
            Statement smt = sharedConnection.createStatement();
            wasThisMethodSuccessful = smt.execute(createTableSql);
            Database.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    } 
    private static boolean setupDummyData() throws SQLException {
        boolean wasThisMethodSuccessful = false;
        try {
            Database.openConnection();
            String sqlString = "INSERT INTO " + Database.TABLE_NAME_FOR_INDIEFY
                    + " (username, password)"
                    + " VALUES (?, ?)";
            PreparedStatement psmt = sharedConnection.prepareStatement(sqlString);
            //String[]  = {"Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"};
           // int[] radiusKmSizes = {2440, 6052, 6371, 3390, 69911, 58232, 25362, 24622};
            //for (int i = 0; i < planetNames.length; i++) {
                psmt.setString(1, "Pretentious");
                psmt.setString(2, "Hipster");
                boolean wasThisRoundSuccessful = psmt.execute();
                wasThisMethodSuccessful = (wasThisMethodSuccessful && wasThisRoundSuccessful);
        
            
            Database.closeConnection();
            wasThisMethodSuccessful = true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
        
    } 
    /* Note that this method is called from the LoginScreen Controller */
   
     public static boolean setupDatabaseOnFirstRun() {
        boolean wasThisMethodSuccessful = false;
        try {
            // check if we need to setup database
            Database.openConnection();
            DatabaseMetaData dbmd = Database.sharedConnection.getMetaData();
            ResultSet rs = dbmd.getTables(null, null, Database.TABLE_NAME_FOR_INDIEFY, null);
            boolean needToSetupDatabase = false;
            if (!rs.next()) {
                needToSetupDatabase = true;
            }
            Database.closeConnection();
            
            // do further stuff if required
            if (needToSetupDatabase) {
                boolean createdTableSuccessfully = Database.createTheOnlyTableWeNeed();
                boolean createdDataSuccessfully = Database.setupDummyData();
                wasThisMethodSuccessful = (createdTableSuccessfully && createdDataSuccessfully);
            } else {
                wasThisMethodSuccessful = true;
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
            
        } finally {
            return wasThisMethodSuccessful;
        }
    }
     
     public boolean tryLogin(String username, String password) {
      
        if(username.equals("Pretentious")&& password.equals("Hipster")) {
            return true;
        } else {
            return false;
        }
        // Assume that the user will enter incorrect credentials
        //boolean loginSuccessful = false;
        
       // try {
         //   Connection conn = DriverManager.getConnection("jdbc:sqlite:Indiefy.db");
            // Open the connection
            
            // Use a Prepared Statement to query the database to check entered credentials
            
            // Check the Result Set to see if the query returned a tuple, what should happen then?
            
            // Close the Result Set
               
       // } catch (Exception e) {
        //  e.printStackTrace();
       // }
        
       // return loginSuccessful;
    } 
     
   // public static void createLoginTable() throws SQLException {
        
        // Initialise your Prepared Statement to create the LOGIN table
       //st = conn.createStatement();
       //String createQuery = "CREATE TABLE loginTable"
             //   +"(username STRING PRIMARY KEY," +
             // "password TEXT NOT NULL)";
      //  st.execute(createQuery);
        //Initialise your Prepared Statement to add data to the LOGIN table
      //  String insertQuery = "INSERT INTO (username,password)"
              //  + "VALUES ('Pretentious','Hipster')";
      //  st.execute(insertQuery);
        // Initialise your Result Set
        
        // Open the connection
       // try {
            //System.out.println("Checking LOGIN table ");
            // Check if the Login Table exists
            
          //  if (!rs.next()) {
                
                // Use the connection to create the Prepared Statement that will create the LOGIN table, and then and execute it
                
                // Use the connection to create the Prepared Statement that will add data to the table, and then and execute it
                
           // } else {
           //     System.out.println("LOGIN table exists");
           // }
       // } catch (Exception e) {
        //    e.printStackTrace();
       // }
   // }
 
}

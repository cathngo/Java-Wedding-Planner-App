package IndiefyLogin;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


public class Music {
    
    private SimpleStringProperty album;
    private SimpleStringProperty artist;
    private SimpleStringProperty genre;
    private SimpleStringProperty year;
    
    //public Music() {
      //  this("","","","");
    //}

    public Music(String album, String artist, String genre, String year) {
        this.album = new SimpleStringProperty(album);
        this.artist = new SimpleStringProperty(artist);
        this.genre = new SimpleStringProperty(genre);
        this.year = new SimpleStringProperty(year);
    }

    public void setAlbum(String album) {
        this.album = new SimpleStringProperty(album);
    }

    public void setArtist(String artist) {
        this.artist = new SimpleStringProperty(artist);
    }

    public void setGenre(String genre) {
        this.genre = new SimpleStringProperty(genre);
    }

    public void setYear(String year) {
        this.year = new SimpleStringProperty(year);
    }

    public String getAlbum() {
        return album.get();
    }

    public String getArtist() {
        return artist.get();
    }
    
    public String getGenre() {
        return genre.get();
    }

    public String getYear() {
        return year.get();
    }    
}
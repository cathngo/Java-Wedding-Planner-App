package IndiefyLogin;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.property.SimpleIntegerProperty;

/**
 *
 * @author LynnL
 */
public class Music {
    
    private StringProperty album;
   // Add the other attributes for the Music List
    private StringProperty artist;
    private StringProperty genre;
    private IntegerProperty year;
    
    
    public Music() {
        this("","","",0);
    }

    public Music(String album, String artist, String genre, int year) {
        this.album = new SimpleStringProperty(album);
        // Complete the constructor
        this.artist = new SimpleStringProperty(artist);
        this.genre = new SimpleStringProperty(genre);
        this.year = new SimpleIntegerProperty(year);
    }
    
   // Add getters for String Properties
    public StringProperty getAlbum() {
        return album;
    }

    public void setAlbum(StringProperty album) {
        this.album = album;
    }
    
    public StringProperty albumProperty() {
        return album;
    }

    public StringProperty getArtist() {
        return artist;
    }

    public void setArtist(StringProperty artist) {
        this.artist = artist;
    }
    
    public StringProperty artistProperty() {
        return artist;
    }

    public StringProperty getGenre() {
        return genre;
    }

    public void setGenre(StringProperty genre) {
        this.genre = genre;
    }
    
    public StringProperty genreProperty(){
        return genre;
    }

    public IntegerProperty getYear() {
        return year;
    }

    public void setYear(IntegerProperty year) {
        this.year = year;
    }
    
    public IntegerProperty yearProperty(){
        return year;
    }
    
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IndiefyLogin;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

/**
 *
 * @author jacob
 */
public class LoginScreenController {
    
    //Initiate JavaFX nodes (visual elements), how do we connect these variables to the FXML view?
    @FXML
    TextField txtUsername;
    
    @FXML
    PasswordField txtPassword;
    
    @FXML
    Button signInButton;
    
    @FXML
    Label lblFeedback;
    
    @FXML
    Button nextButton; 
    
    // Initiate the database class
    Database d = new Database();
    
    @FXML
    public void initialize() {
        lblFeedback.setText("");
        nextButton.setVisible(false);
    } 
    
    /* What should happen when you click the login button?
       How do we connect this function to the FXML view? */
    @FXML
    private void handleLoginButtonAction(ActionEvent event) {
        // Get the user's input from the GUI
        String user = txtUsername.getText();
        String password = txtPassword.getText();
        if (d.tryLogin(user, password)) {
            // What should the user see when the login is successful?
            nextButton.setVisible(true);
            lblFeedback.setText("Login successful");
        } else {
            // What should the user see when the login is unsuccessful?
            lblFeedback.setText("Incorrect username or password");
            nextButton.setVisible(false);
        }
    }
    
    @FXML
    private void handleNextButton(ActionEvent event) throws IOException{
        PageSwitchHelper psh = new PageSwitchHelper();
        psh.switcher(event, "/fxml/MusicList.fxml");
    }

       
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IndiefyLogin;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Database {
    
    private static Connection conn;
    
    public static void setupDatabase(){
            Database.createLoginTable();
            Database.createMusicTable();
            Database.setupLoginData();
            Database.setupMusicData();
    }
    
    private static void openConnection(){
        try{
            Database.conn = DriverManager.getConnection("jdbc:sqlite:Indiefy.db");
        } catch (SQLException e){
            e.printStackTrace();
        } 
    }
    
    private static void closeConnection(){
        try{
            conn.close();
        } catch (SQLException e){
            e.printStackTrace();
        } 
    }
    
    private static void createLoginTable(){
        try{
            Database.openConnection();
            String createTableString = "CREATE TABLE IF NOT EXISTS login"
                    + " (username TEXT PRIMARY KEY,"
                    + "password TEXT NOT NULL)";
            Statement st = conn.createStatement();
            st.execute(createTableString);
            st.close();
            Database.closeConnection();
        } catch (SQLException e){
            e.printStackTrace();
        } 
    }
    
    private static void createMusicTable(){
        try{
            Database.openConnection();
            String createTableString = "CREATE TABLE IF NOT EXISTS music"
                    + "(music_id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "album TEXT NOT NULL,"
                    + "artist TEXT NOT NULL,"
                    + "genre TEXT NOT NULL,"
                    + "year INTEGER NOT NULL)";
            Statement st = conn.createStatement();
            st.execute(createTableString);
            st.close();
            Database.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        } 
    }
    
    private static void setupLoginData(){
        try{
            Database.openConnection();
            String insertString = "INSERT OR IGNORE INTO login" 
                    + " (username, password)"
                    + " VALUES (?, ?)";
            PreparedStatement ps = conn.prepareStatement(insertString);
            ps.setString(1, "Pretentious");
            ps.setString(2, "Hipster");
            ps.execute();
            Database.closeConnection();
        } catch (SQLException e){
            e.printStackTrace();
        } 
    }
    
    private static void setupMusicData(){
        try{
            Database.openConnection();
            String insertString = "INSERT OR IGNORE INTO music"
                    + " (album, artist, genre, year)"
                    + " VALUES (?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(insertString);
            
            String[] album = {"Thriller", "The Bodyguard", "Red", "Manic"};
            String[] artist = {"Michael Jackson", "Whitney Houston", "Taylor Swift", "Halsey"};
            String[] genre = {"Pop", "R&B", "Country", "Electropop"};
            int[] year = {1982, 1992, 2012, 2020};
            
            for (int i = 0; i < album.length; i++){
                ps.setString(1, album[i]);
                ps.setString(2, artist[i]);
                ps.setString(3, genre[i]);
                ps.setInt(4, year[i]);
                ps.execute();
            }
            
            Database.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
        
    public static ObservableList<Music> getMusic(){
        ArrayList<Music> alm = new ArrayList<>();
        try {
            Database.openConnection();
            String sqlString = "SELECT * FROM music;";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(sqlString);
            while(rs.next()){
                Music obj = new Music(rs.getString(2), rs.getString(3), 
                        rs.getString(4), rs.getInt(5));
                alm.add(obj);
            }
            Database.closeConnection();
        } catch (SQLException e){
            e.printStackTrace();
        } 
        return FXCollections.observableArrayList(alm);        
    }
    
    public boolean tryLogin(String username, String password) {
        
        // Assume that the user will enter incorrect credentials
        boolean loginSuccessful = false;
        
        try {
            // Open the connection
            Database.openConnection();
            // Use a Prepared Statement to query the database to check entered credentials
            String sqlString = "SELECT * FROM login "
                    + "WHERE username = ? AND password = ?;";
            PreparedStatement ps = conn.prepareStatement(sqlString);
            ps.setString(1, username);
            ps.setString(2, password);
            // Check the Result Set to see if the query returned a tuple, what should happen then?
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                loginSuccessful = true;
            }
            // Close the Result Set
            rs.close();
            Database.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        } 
            return loginSuccessful;

    }
    
}
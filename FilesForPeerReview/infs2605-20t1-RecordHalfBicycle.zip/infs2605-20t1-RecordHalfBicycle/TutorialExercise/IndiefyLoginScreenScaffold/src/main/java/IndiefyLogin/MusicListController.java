package IndiefyLogin;

import javafx.fxml.FXML;
import javafx.scene.control.*;

/**
 *
 * @author LynnL
 */
public class MusicListController {
    
    // Initialise the TableView as FXML variables
    @FXML 
    private TableView<Music> tblMusic;
    // Initialise the TableColumns as FXML variables
    @FXML
    private TableColumn<Music, String> colAlbum;
    
    @FXML
    private TableColumn<Music, String> colArtist;
    
    @FXML 
    private TableColumn<Music, String> colGenre;
    
    @FXML
    private TableColumn<Music, Integer> colYear;
    // Initialise the database class
    Database d;
    // What annotation do you need here?
    
    public void initialize() {
        tblMusic.setItems(Database.getMusic());
       /* 
        Initialise the TableView by setting the cell value factory
        Read this page for help: https://code.makery.ch/library/javafx-tutorial/part2/
        */
        colAlbum.setCellValueFactory(cellData -> cellData.getValue().albumProperty());
        colArtist.setCellValueFactory(cellData -> cellData.getValue().artistProperty());
        colGenre.setCellValueFactory(cellData -> cellData.getValue().genreProperty());
        colYear.setCellValueFactory(cellData -> cellData.getValue().yearProperty().asObject());
        // Set the items that should be contained in the TableView
    }
    
    
}
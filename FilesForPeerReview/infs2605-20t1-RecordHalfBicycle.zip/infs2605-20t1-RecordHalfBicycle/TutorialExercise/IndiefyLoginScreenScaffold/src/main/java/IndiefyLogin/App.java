package IndiefyLogin;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import static javafx.application.Application.launch;

/**
 * JavaFX App
 */
public class App extends Application {
    
    private static Scene scene;
    
    /* What should happen when you first start the program? */
    @Override
    public void start(Stage stage) throws IOException {
        //Initiate the database
        Database.setupDatabase();
        /* Add the four lines of code to load an FXML into a scene, attach it to a stage, 
        and show the stage */
        Parent root = FXMLLoader.load(App.class.getResource("/fxml/LoginScreen.fxml"));
        scene = new Scene(root,400,550);
        stage.setScene(scene);
        stage.show();
    }
    
    public static void main(String[] args) {
        //What should go in here?
        launch();
    }

}
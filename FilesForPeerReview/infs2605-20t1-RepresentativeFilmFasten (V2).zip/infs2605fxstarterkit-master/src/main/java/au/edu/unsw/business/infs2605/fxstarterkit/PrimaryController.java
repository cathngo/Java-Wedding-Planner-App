package au.edu.unsw.business.infs2605.fxstarterkit;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.event.ActionEvent;
import javafx.scene.control.TextField;

public class PrimaryController {

    @FXML
    private Label title;

    @FXML
    private Button loginButton;

    @FXML
    private TextField username;

    @FXML
    private PasswordField password;

    @FXML
    private Label loginOutput;


    @FXML
    private Button next;
    Database db = new Database();

    PageSwitchHelper psh = new PageSwitchHelper();

    @FXML
    void handleLoginButton(ActionEvent event) {
        String user = username.getText().trim();
        String pword = password.getText();

        if (db.tryLogin(user, pword)) {
            loginOutput.setText("Login successful!");
            loginOutput.setVisible(true);
            next.setVisible(true);
        } else {
            loginOutput.setText("Incorrect username or password. Please try again!");
            loginOutput.setVisible(true);
        }
    }


       
    @FXML
    void handleNextButton(ActionEvent event) throws IOException {
        psh.switcher(event, "secondary.fxml");
    }
    
    
    
    @FXML
    public void initialize() {
        System.out.println("Initialize");
        loginOutput.setVisible(false);
        next.setVisible(false);
    }
    
}




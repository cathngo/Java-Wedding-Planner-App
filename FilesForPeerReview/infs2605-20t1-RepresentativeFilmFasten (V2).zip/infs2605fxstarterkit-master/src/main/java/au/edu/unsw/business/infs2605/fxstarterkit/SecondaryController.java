package au.edu.unsw.business.infs2605.fxstarterkit;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class SecondaryController {

    @FXML
    private Button secondaryButton;

    @FXML
    private TableView<Music> table;

    @FXML
    private TableColumn<Music, String> album;

    @FXML
    private TableColumn<Music, String> artist;

    @FXML
    private TableColumn<Music, String> genre;

    @FXML
    private TableColumn<Music, String> year;
    
    
    Database database = new Database();
    
    @FXML
    public void initialize() {
        artist.setCellValueFactory(
                cellData -> cellData.getValue().getArtistProperty());
        album.setCellValueFactory(
                cellData -> cellData.getValue().getAlbumProperty());
        genre.setCellValueFactory(
                cellData -> cellData.getValue().getGenreProperty());
        year.setCellValueFactory(
                cellData -> cellData.getValue().getYearProperty());

        table.setItems(this.getMusicListData());
    }

    private ObservableList<Music> getMusicListData() {
        List<Music> musicListToReturn = new ArrayList<>();
        try {
            ResultSet rs = database.getResultSet("SELECT * FROM MUSICLIST");
            while(rs.next()) {
                musicListToReturn.add(
                        new Music(rs.getString("ALBUM"),rs.getString("ARTIST"),rs.getString("GENRE"),rs.getString("YEAR"))
                );
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        System.out.println(musicListToReturn);
       return FXCollections.observableArrayList(musicListToReturn);
    }
}